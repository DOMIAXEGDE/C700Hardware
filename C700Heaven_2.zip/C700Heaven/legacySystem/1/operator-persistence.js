/**
 * Operator Persistence System
 * A comprehensive state management and persistence system for the Operator OS
 *
 * This module handles saving and loading the state of all components:
 * - Data Structures (arrays, objects, sets, quadtrees)
 * - Algorithms (recursion, iteration, search, binary operations)
 * - System Operations (file system, memory management, process management)
 * - CRUD Database
 * - Advanced Concepts (serialization, compression, encoding, transactions)
 * - OperatorLang programming environment
 */

(function() {
    'use strict';

    // Configuration
    const CONFIG = {
        metadataKey: 'operatorSessionMetadata',
        chunkPrefix: 'operatorSessionChunk_',
        chunkSize: 1024 * 1024, // 1MB chunks
        version: '1.1',
        encryptionKey: 'OPERATOR_SYSTEM_ENCRYPTION_KEY',
        autoSaveKey: 'operatorAutoSave'
    };

    // State Registry - tracks all persistable components and their save/load handlers
    const stateRegistry = new Map();

    // Initialize when document is ready
    document.addEventListener('DOMContentLoaded', function() {
        // Wait for all components to initialize
        setTimeout(initPersistenceSystem, 500);
    });

    /**
     * Initialize the persistence system
     */
    function initPersistenceSystem() {
        console.log("Initializing Operator Persistence System...");
        
        // Register all state handlers
        registerStateHandlers();
        
        // Create or enhance the persistence controls
        setupPersistenceControls();
        
        // Check for auto-recovery if configured
        checkAutoRecovery();
        
        // Register window unload handler to offer auto-save
        setupUnloadHandler();
		
		// Add this to the initPersistenceSystem function
		// Update workspace info every 30 seconds
		setInterval(updateWorkspaceInfo, 30000);
    }

    /**
     * Register state handlers for all components
     */
    function registerStateHandlers() {
        // Data Structures
        registerComponent('arrays', {
            selector: '#array-operations',
            save: saveArrayState,
            load: loadArrayState
        });
        
        registerComponent('objects', {
            selector: '#object-operations',
            save: saveObjectState,
            load: loadObjectState
        });
        
        registerComponent('sets', {
            selector: '#set-operations',
            save: saveSetState,
            load: loadSetState
        });
        
        registerComponent('quadtree', {
            selector: '#tree-operations',
            save: saveQuadtreeState,
            load: loadQuadtreeState
        });
        
        // CRUD Database
        registerComponent('database', {
            selector: '#create-operations',
            save: saveDatabaseState,
            load: loadDatabaseState,
            priority: 10 // Higher priority components are processed first during load
        });
        
        // System Operations
        registerComponent('fileSystem', {
            selector: '#file-operations',
            save: saveFileSystemState,
            load: loadFileSystemState,
            priority: 20
        });
        
        registerComponent('memoryManagement', {
            selector: '#memory-operations',
            save: saveMemoryState,
            load: loadMemoryState
        });
        
        registerComponent('processManagement', {
            selector: '#process-operations',
            save: saveProcessState,
            load: loadProcessState
        });
        
        // Algorithm States
        registerComponent('recursion', {
            selector: '#recursion-operations',
            save: saveRecursionState,
            load: loadRecursionState
        });
        
        registerComponent('iteration', {
            selector: '#iteration-operations',
            save: saveIterationState,
            load: loadIterationState
        });
        
        registerComponent('search', {
            selector: '#search-operations',
            save: saveSearchState,
            load: loadSearchState
        });
        
        registerComponent('binaryOps', {
            selector: '#binary-operations',
            save: saveBinaryOperationsState,
            load: loadBinaryOperationsState
        });
        
        // Advanced Components
        registerComponent('serialization', {
            selector: '#serialization-operations',
            save: saveSerializationState,
            load: loadSerializationState
        });
        
        registerComponent('compression', {
            selector: '#compression-operations',
            save: saveCompressionState,
            load: loadCompressionState
        });
        
        registerComponent('encoding', {
            selector: '#encoding-operations',
            save: saveEncodingState,
            load: loadEncodingState
        });
        
        registerComponent('transactions', {
            selector: '#transactions-operations',
            save: saveTransactionState,
            load: loadTransactionState
        });
        
        // Programming Language
        registerComponent('operatorLang', {
            selector: '#programming-section',
            save: saveOperatorLangState,
            load: loadOperatorLangState,
            priority: 30
        });
    }

    /**
     * Register a component with the state registry
     */
    function registerComponent(id, config) {
        // Check if component exists in DOM
        const element = document.querySelector(config.selector);
        if (!element) {
            console.log(`Component ${id} not found in DOM, skipping registration`);
            return;
        }
        
        // Set default priority (0) if not specified
        if (config.priority === undefined) {
            config.priority = 0;
        }
        
        // Register component
        stateRegistry.set(id, {
            id: id,
            element: element,
            save: config.save,
            load: config.load,
            priority: config.priority,
            active: true
        });
        
        console.log(`Registered component: ${id}`);
    }

	function setupPersistenceControls() {
		// Check for existing controls in the main navigation
		const mainNav = document.getElementById('main-nav');
		if (mainNav) {
			// Create session section in nav if it doesn't exist
			// This line has the error:
			// let sessionSection = mainNav.querySelector('.nav-section:has(h3:contains("Session"))');
			
			// Find Session section without using :has or :contains
			let sessionSection = null;
			const navSections = mainNav.querySelectorAll('.nav-section');
			for (const section of navSections) {
				const h3 = section.querySelector('h3');
				if (h3 && h3.textContent === 'Session') {
					sessionSection = section;
					break;
				}
			}
			
			if (!sessionSection) {
				sessionSection = document.createElement('div');
				sessionSection.className = 'nav-section';
				sessionSection.innerHTML = `
					<h3>Session</h3>
					<div class="persistence-controls">
						<button id="save-session" title="Save current workspace">Save Workspace</button>
						<button id="load-session" title="Load saved workspace">Load Workspace</button>
						<button id="auto-save-toggle" class="button-secondary" title="Toggle automatic saving">
							Auto Save: <span id="auto-save-status">Off</span>
						</button>
					</div>
				`;
				mainNav.appendChild(sessionSection);
			}
            
            // Set up event listeners
            const saveButton = document.getElementById('save-session');
            const loadButton = document.getElementById('load-session');
            const autoSaveToggle = document.getElementById('auto-save-toggle');
            
            if (saveButton) {
                saveButton.removeEventListener('click', saveAllStates);
                saveButton.addEventListener('click', saveAllStates);
            }
            
            if (loadButton) {
                loadButton.removeEventListener('click', loadWorkspaceFromFile);
                loadButton.addEventListener('click', loadWorkspaceFromFile);
            }
            
            if (autoSaveToggle) {
                const autoSaveStatus = document.getElementById('auto-save-status');
                const autoSaveEnabled = localStorage.getItem(CONFIG.autoSaveKey) === 'true';
                
                // Set initial status
                if (autoSaveStatus) {
                    autoSaveStatus.textContent = autoSaveEnabled ? 'On' : 'Off';
                }
                
                // Toggle auto-save on click
                autoSaveToggle.addEventListener('click', function() {
                    const currentStatus = localStorage.getItem(CONFIG.autoSaveKey) === 'true';
                    const newStatus = !currentStatus;
                    
                    localStorage.setItem(CONFIG.autoSaveKey, newStatus.toString());
                    
                    if (autoSaveStatus) {
                        autoSaveStatus.textContent = newStatus ? 'On' : 'Off';
                    }
                    
                    showNotification(`Auto save ${newStatus ? 'enabled' : 'disabled'}`, 'info');
                });
            }
            
            console.log("Set up persistence controls in main navigation");
        } else {
            // Create floating controls if main nav not found
            createFloatingPersistenceControls();
        }
		
		// Add this to operator-persistence.js inside the setupPersistenceControls function

		function createSessionManagementSection() {
			// Check if the section already exists
			if (document.getElementById('session-management')) {
				return;
			}
			
			// Create a new section
			const section = document.createElement('section');
			section.id = 'session-management';
			section.className = 'operation-section';
			
			// Add the section content
			section.innerHTML = `
				<h2>Session Management</h2>
				<div class="operation-container">
					<div class="operation-controls">
						<h3>Workspace Management</h3>
						<div class="control-group">
							<button id="save-workspace-btn" class="button">Save Workspace</button>
							<button id="load-workspace-btn" class="button">Load Workspace</button>
						</div>
						<div class="control-group mt-20">
							<h4>Backup Options</h4>
							<button id="export-workspace-btn" class="button">Export Workspace</button>
							<button id="import-workspace-btn" class="button">Import Workspace</button>
						</div>
						<div class="control-group mt-20">
							<h4>Auto-Save</h4>
							<div class="toggle-container">
								<label class="toggle">
									<input type="checkbox" id="auto-save-toggle">
									<span class="toggle-slider"></span>
								</label>
								<span id="auto-save-label">Auto-save is off</span>
							</div>
							<p class="hint-text">When enabled, your workspace will be automatically saved when you leave the page.</p>
						</div>
					</div>
					<div class="operation-result">
						<h3>Workspace Status</h3>
						<div id="workspace-info" class="workspace-info">
							<div class="info-item">
								<span class="info-label">Last Saved:</span>
								<span id="last-saved-time">Never</span>
							</div>
							<div class="info-item">
								<span class="info-label">Components:</span>
								<span id="component-count">0</span>
							</div>
							<div class="info-item">
								<span class="info-label">Storage Used:</span>
								<span id="storage-used">0 KB</span>
							</div>
						</div>
						<div class="mt-20">
							<h4>Recent Actions</h4>
							<div id="session-history" class="session-history">
								<div class="empty-history">No recent actions</div>
							</div>
						</div>
						<div class="mt-20">
							<button id="clear-storage-btn" class="button button-secondary">Clear Stored Data</button>
						</div>
					</div>
				</div>
			`;
			
			// Add the section to the main content
			const main = document.querySelector('main');
			if (main) {
				main.appendChild(section);
				
				// Add to navigation
				const navSection = document.querySelector('#main-nav');
				if (navSection) {
					const sessionNav = document.createElement('div');
					sessionNav.className = 'nav-section';
					sessionNav.innerHTML = `
						<h3>Session</h3>
						<button data-section="session-management">Workspace Management</button>
					`;
					navSection.appendChild(sessionNav);
				}
				
				// Set up event listeners
				setupSessionManagementListeners();
				updateWorkspaceInfo();
			}
		}

		// Call this function from setupPersistenceControls
		createSessionManagementSection();
		
    }
    
    /**
     * Create floating persistence controls if they don't exist in main nav
     */
    function createFloatingPersistenceControls() {
        // Check if floating controls already exist
        if (document.getElementById('floating-persistence-controls')) {
            return;
        }
        
        // Create container
        const controlsContainer = document.createElement('div');
        controlsContainer.id = 'floating-persistence-controls';
        controlsContainer.className = 'persistence-controls-container';
        controlsContainer.style.cssText = `
            position: fixed;
            bottom: 20px;
            right: 20px;
            background-color: white;
            border: 1px solid var(--secondary-color);
            border-radius: 5px;
            padding: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            z-index: 1000;
            display: flex;
            flex-direction: column;
            gap: 10px;
        `;
        
        // Add buttons
        const saveButton = document.createElement('button');
        saveButton.textContent = 'Save Workspace';
        saveButton.className = 'button';
        saveButton.addEventListener('click', saveAllStates);
        
        const loadButton = document.createElement('button');
        loadButton.textContent = 'Load Workspace';
        loadButton.className = 'button';
        loadButton.addEventListener('click', loadWorkspaceFromFile);
        
        const autoSaveToggle = document.createElement('button');
        autoSaveToggle.className = 'button button-secondary';
        
        const autoSaveEnabled = localStorage.getItem(CONFIG.autoSaveKey) === 'true';
        autoSaveToggle.textContent = `Auto Save: ${autoSaveEnabled ? 'On' : 'Off'}`;
        
        autoSaveToggle.addEventListener('click', function() {
            const currentStatus = localStorage.getItem(CONFIG.autoSaveKey) === 'true';
            const newStatus = !currentStatus;
            
            localStorage.setItem(CONFIG.autoSaveKey, newStatus.toString());
            autoSaveToggle.textContent = `Auto Save: ${newStatus ? 'On' : 'Off'}`;
            
            showNotification(`Auto save ${newStatus ? 'enabled' : 'disabled'}`, 'info');
        });
        
        // Add to container
        controlsContainer.appendChild(saveButton);
        controlsContainer.appendChild(loadButton);
        controlsContainer.appendChild(autoSaveToggle);
        
        // Add to document
        document.body.appendChild(controlsContainer);
        console.log("Created floating persistence controls");
    }
    
    /**
     * Save all component states
     */
    async function saveAllStates() {
        try {
            console.log("Saving all states...");
            showNotification('Saving workspace...', 'info');
            
            // Collect state from all registered components
            const fullState = {
                version: CONFIG.version,
                timestamp: new Date().toISOString(),
                components: {}
            };
            
            // Save each component's state
            for (const [id, component] of stateRegistry.entries()) {
                if (!component.active) continue;
                
                try {
                    const componentState = await component.save();
                    if (componentState !== undefined) {
                        fullState.components[id] = componentState;
                    }
                } catch (error) {
                    console.error(`Error saving state for ${id}:`, error);
                }
            }
            
            // Convert to JSON and encrypt
            const jsonData = JSON.stringify(fullState);
            const encryptedData = encryptData(jsonData);
            
            // Split into chunks for localStorage
            const chunks = chunkString(encryptedData, CONFIG.chunkSize);
            
            // Store metadata
            localStorage.setItem(CONFIG.metadataKey, JSON.stringify({
                version: CONFIG.version,
                timestamp: new Date().toISOString(),
                chunks: chunks.length,
                size: encryptedData.length
            }));
            
            // Store chunks
            chunks.forEach((chunk, index) => {
                localStorage.setItem(`${CONFIG.chunkPrefix}${index}`, chunk);
            });
            
            // Create download link for backup
            offerDownload(fullState);
            
            showNotification('Workspace saved successfully', 'success');
			// Add to the end of the saveAllStates function, before the return statement:
			addHistoryItem('Workspace saved');
			updateWorkspaceInfo();
        } catch (error) {
            console.error('Error saving workspace:', error);
            showNotification('Failed to save workspace: ' + error.message, 'error');
        }
    }
    
    /**
     * Load workspace from a file selected by the user
     */
    function loadWorkspaceFromFile() {
        // Create file input for loading JSON
        const fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.accept = '.json';
        fileInput.style.display = 'none';
        document.body.appendChild(fileInput);
        
        fileInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (!file) return;
            
            const reader = new FileReader();
            reader.onload = function(e) {
                try {
                    // Parse the file content
                    const workspaceData = JSON.parse(e.target.result);
                    
                    // Basic validation
                    if (!workspaceData.timestamp) {
                        throw new Error('Invalid workspace file format');
                    }
                    
                    // Confirm before loading
                    if (!confirm(`Load workspace from ${new Date(workspaceData.timestamp).toLocaleString()}? This will replace your current workspace.`)) {
                        return;
                    }
                    
                    // Load the workspace
                    loadFromObject(workspaceData);
                } catch (error) {
                    console.error('Error loading workspace file:', error);
                    showNotification('Failed to load workspace: ' + error.message, 'error');
                }
            };
            
            reader.onerror = function() {
                showNotification('Error reading file', 'error');
            };
            
            reader.readAsText(file);
            
            // Clean up
            document.body.removeChild(fileInput);
        });
        
        // Trigger file selection
        fileInput.click();
    }
    
    /**
     * Load workspace from localStorage
     */
    async function loadFromLocalStorage() {
        try {
            // Check if there's a saved state
            const metadataStr = localStorage.getItem(CONFIG.metadataKey);
            if (!metadataStr) {
                showNotification('No saved workspace found in browser storage', 'error');
                return;
            }
            
            showNotification('Loading workspace...', 'info');
            
            // Parse metadata
            const metadata = JSON.parse(metadataStr);
            
            // Retrieve and combine chunks
            let encryptedData = '';
            for (let i = 0; i < metadata.chunks; i++) {
                const chunk = localStorage.getItem(`${CONFIG.chunkPrefix}${i}`);
                if (!chunk) {
                    throw new Error(`Missing session data chunk ${i}`);
                }
                encryptedData += chunk;
            }
            
            // Decrypt data
            const jsonData = decryptData(encryptedData);
            const fullState = JSON.parse(jsonData);
            
            // Load the workspace
            await loadFromObject(fullState);
        } catch (error) {
            console.error('Error loading from localStorage:', error);
            showNotification('Failed to load workspace: ' + error.message, 'error');
        }
    }
    
    /**
     * Load state from a workspace object
     */
    async function loadFromObject(workspaceData) {
        try {
            showNotification('Loading workspace...', 'info');
            
            // Verify version compatibility
            if (workspaceData.version && workspaceData.version !== CONFIG.version) {
                console.warn(`Version mismatch: saved=${workspaceData.version}, current=${CONFIG.version}`);
                // Allow loading but warn
                showNotification('Loading workspace from a different version', 'warning');
            }
            
            // Handle both formats:
            // 1. New format: { components: { id: state } }
            // 2. Legacy format: { virtualFS, database, etc. }
            const hasComponents = workspaceData.components && typeof workspaceData.components === 'object';
            
            if (hasComponents) {
                // Get components sorted by priority
                const sortedComponents = Array.from(stateRegistry.values())
                    .sort((a, b) => b.priority - a.priority);
                
                // Load each component state
                for (const component of sortedComponents) {
                    if (!component.active) continue;
                    
                    const id = component.id;
                    if (workspaceData.components[id]) {
                        try {
                            await component.load(workspaceData.components[id]);
                            console.log(`Loaded state for ${id}`);
                        } catch (error) {
                            console.error(`Error loading state for ${id}:`, error);
                        }
                    }
                }
            } else {
                // Legacy format - map directly to components
                // File System
                if (workspaceData.virtualFS) {
                    try {
                        window.virtualFS = workspaceData.virtualFS;
                        if (typeof window.renderFileTree === 'function') {
                            window.renderFileTree();
                        }
                    } catch (error) {
                        console.error('Error loading file system:', error);
                    }
                }
                
                // Database
                if (workspaceData.database && workspaceData.database.records) {
                    try {
                        if (window.database) {
                            window.database.deleteAll();
                            workspaceData.database.records.forEach(([id, record]) => {
                                window.database.records.set(id, record);
                            });
                            
                            if (window.databaseDisplayUpdater) {
                                window.databaseDisplayUpdater.updateDatabaseDisplay();
                            }
                        }
                    } catch (error) {
                        console.error('Error loading database:', error);
                    }
                }
                
                // Memory
                if (workspaceData.memorySlots && window.memoryManager) {
                    try {
                        window.memoryManager.memorySlots = workspaceData.memorySlots;
                        if (typeof window.updateMemoryDisplay === 'function') {
                            window.updateMemoryDisplay();
                        }
                    } catch (error) {
                        console.error('Error loading memory state:', error);
                    }
                }
                
                // OperatorLang
                if (workspaceData.programming && window.operatorLang) {
                    try {
                        const codeEditor = document.getElementById('code-editor');
                        if (codeEditor && workspaceData.programming.code) {
                            codeEditor.value = workspaceData.programming.code;
                        }
                        
                        if (workspaceData.programming.variables) {
                            window.operatorLang.variables = new Map(workspaceData.programming.variables);
                        }
                    } catch (error) {
                        console.error('Error loading programming state:', error);
                    }
                }
				// Update workspace info display
				updateWorkspaceInfo();
            }
            
            showNotification('Workspace loaded successfully', 'success');
        } catch (error) {
            console.error('Error loading workspace:', error);
            showNotification('Failed to load workspace: ' + error.message, 'error');
        }
    }

    /**
     * Offer to download state as a backup file
     */
    function offerDownload(state) {
        try {
            // Create a JSON file
            const blob = new Blob([JSON.stringify(state)], {type: 'application/json'});
            const url = URL.createObjectURL(blob);
            
            // Create a temporary link element
            const a = document.createElement('a');
            a.href = url;
            a.download = `operator_workspace_${new Date().toISOString().replace(/:/g, '-')}.json`;
            
            // Ask user if they want to download
            if (confirm('Would you like to download a backup of your workspace?')) {
                a.click();
            }
            
            // Clean up
            setTimeout(() => URL.revokeObjectURL(url), 5000);
        } catch (error) {
            console.error('Error creating download:', error);
        }
    }
    
	// Modify checkAutoRecovery to update UI:
	function checkAutoRecovery() {
		// Check for a saved state
		const metadataStr = localStorage.getItem(CONFIG.metadataKey);
		if (!metadataStr) return;
		
		try {
			const metadata = JSON.parse(metadataStr);
			const savedDate = new Date(metadata.timestamp);
			const now = new Date();
			
			// Update the workspace info display
			updateWorkspaceInfo();
			
			// If the saved state is recent (within the last day)
			if ((now - savedDate) < 24 * 60 * 60 * 1000) {
				// Show recovery banner
				const banner = document.createElement('div');
				banner.className = 'recovery-banner';
				banner.style.cssText = `
					position: fixed;
					top: 0;
					left: 0;
					right: 0;
					background-color: var(--primary-color);
					color: white;
					padding: 10px 20px;
					text-align: center;
					z-index: 2000;
					display: flex;
					justify-content: center;
					align-items: center;
					gap: 20px;
				`;
				
				banner.innerHTML = `
					<div>Saved workspace found from ${savedDate.toLocaleString()}. Would you like to restore it?</div>
					<div>
						<button id="restore-workspace" class="button">Restore</button>
						<button id="dismiss-banner" class="button button-secondary">Dismiss</button>
					</div>
				`;
				
				document.body.appendChild(banner);
				
				// Add event listeners
				document.getElementById('restore-workspace').addEventListener('click', () => {
					loadFromLocalStorage();
					document.body.removeChild(banner);
					addHistoryItem('Workspace restored from auto-recovery');
				});
				
				document.getElementById('dismiss-banner').addEventListener('click', () => {
					document.body.removeChild(banner);
				});
			}
		} catch (error) {
			console.error('Error checking for recovery:', error);
		}
	}
    
    /**
     * Setup window unload handler
     */
    function setupUnloadHandler() {
        window.addEventListener('beforeunload', function(e) {
            // Check if auto-save is enabled
            const autoSave = localStorage.getItem(CONFIG.autoSaveKey) === 'true';
            if (autoSave) {
                // Attempt to save state (async, might not complete)
                saveAllStates();
                return;
            }
            
            // Otherwise, show confirmation dialog
            const confirmationMessage = 'You have unsaved changes. Would you like to save your workspace before leaving?';
            e.returnValue = confirmationMessage;
            return confirmationMessage;
        });
    }

    /**
     * Show a notification to the user
     */
    function showNotification(message, type = 'info') {
        // Check if a notification container exists
        let container = document.getElementById('persistence-notifications');
        if (!container) {
            // Create a container
            container = document.createElement('div');
            container.id = 'persistence-notifications';
            container.style.cssText = `
                position: fixed;
                bottom: 20px;
                left: 20px;
                z-index: 2000;
                display: flex;
                flex-direction: column;
                gap: 10px;
            `;
            document.body.appendChild(container);
        }
        
        // Create notification
        const notification = document.createElement('div');
        notification.className = `persistence-notification ${type}`;
        notification.style.cssText = `
            background-color: white;
            border-left: 4px solid ${getTypeColor(type)};
            padding: 15px 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            border-radius: 4px;
            max-width: 300px;
            animation: fadeIn 0.3s ease-out;
            position: relative;
        `;
        
        notification.innerHTML = `
            <div style="margin-right: 20px;">${message}</div>
            <button class="close-notification" style="
                position: absolute;
                top: 5px;
                right: 5px;
                border: none;
                background: none;
                cursor: pointer;
                font-size: 16px;
                color: #999;
            ">&times;</button>
        `;
        
        // Add to container
        container.appendChild(notification);
        
        // Add close button event
        notification.querySelector('.close-notification').addEventListener('click', () => {
            container.removeChild(notification);
        });
        
        // Auto-hide after a delay
        setTimeout(() => {
            notification.style.opacity = '0';
            notification.style.transition = 'opacity 0.3s';
            setTimeout(() => {
                if (container.contains(notification)) {
                    container.removeChild(notification);
                }
            }, 300);
        }, 5000);
    }
    
    /**
     * Get color for notification type
     */
    function getTypeColor(type) {
        switch (type) {
            case 'success': return '#4caf50';
            case 'error': return '#f44336';
            case 'warning': return '#ff9800';
            case 'info': 
            default: return '#2196f3';
        }
    }

    /**
     * Encryption functions for secure storage
     */
    function encryptData(data) {
        try {
            // Simple XOR encryption for demonstration
            // In production, use a proper encryption library
            const key = CONFIG.encryptionKey;
            let result = '';
            
            for (let i = 0; i < data.length; i++) {
                const charCode = data.charCodeAt(i) ^ key.charCodeAt(i % key.length);
                result += String.fromCharCode(charCode);
            }
            
            // Convert to base64 for safer storage
            return btoa(result);
        } catch (error) {
            console.error('Error encrypting data:', error);
            return btoa(data); // Fallback to basic encoding
        }
    }
    
    function decryptData(encrypted) {
        try {
            // Decode from base64
            const encoded = atob(encrypted);
            const key = CONFIG.encryptionKey;
            let result = '';
            
            for (let i = 0; i < encoded.length; i++) {
                const charCode = encoded.charCodeAt(i) ^ key.charCodeAt(i % key.length);
                result += String.fromCharCode(charCode);
            }
            
            return result;
        } catch (error) {
            console.error('Error decrypting data:', error);
            return atob(encrypted); // Fallback to basic decoding
        }
    }
    
    /**
     * Split a string into chunks
     */
    function chunkString(str, size) {
        const chunks = [];
        for (let i = 0; i < str.length; i += size) {
            chunks.push(str.substring(i, i + size));
        }
        return chunks;
    }

    /**
     * Component State Handlers
     * These functions handle saving and loading state for specific components
     */

    // ------ Data Structures ------
    
    async function saveArrayState() {
        const container = document.getElementById('array-operations');
        if (!container) return null;
        
        const inputElement = container.querySelector('#array-input');
        const resultContainer = container.querySelector('#array-result');
        
        return {
            input: inputElement ? inputElement.value : '',
            // Also capture the current visualization state if possible
            displayHTML: resultContainer ? resultContainer.innerHTML : ''
        };
    }
    
    async function loadArrayState(state) {
        const container = document.getElementById('array-operations');
        if (!container || !state) return;
        
        const inputElement = container.querySelector('#array-input');
        if (inputElement && state.input) {
            inputElement.value = state.input;
        }
        
        // Attempt to restore visualization
        const resultContainer = container.querySelector('#array-result');
        if (resultContainer && state.displayHTML) {
            resultContainer.innerHTML = state.displayHTML;
        }
    }
    
    async function saveObjectState() {
        const container = document.getElementById('object-operations');
        if (!container) return null;
        
        // Try to access the current object state
        let currentObject = {};
        try {
            currentObject = window.currentObject || {};
        } catch (e) {
            console.warn("Couldn't access current object state");
        }
        
        return {
            objectState: currentObject,
            displayHTML: container.querySelector('#object-result')?.innerHTML
        };
    }
    
    async function loadObjectState(state) {
        const container = document.getElementById('object-operations');
        if (!container || !state) return;
        
        // Try to restore the object state
        try {
            window.currentObject = state.objectState || {};
        } catch (e) {
            console.warn("Couldn't restore object state");
        }
        
        // Restore display
        if (state.displayHTML) {
            const resultContainer = container.querySelector('#object-result');
            if (resultContainer) {
                resultContainer.innerHTML = state.displayHTML;
            }
        }
    }
    
    async function saveSetState() {
        const container = document.getElementById('set-operations');
        if (!container) return null;
        
        const setAInput = container.querySelector('#set-a-input');
        const setBInput = container.querySelector('#set-b-input');
        
        return {
            setA: setAInput ? setAInput.value : '',
            setB: setBInput ? setBInput.value : '',
            displayHTML: container.querySelector('#set-result')?.innerHTML
        };
    }
    
    async function loadSetState(state) {
        const container = document.getElementById('set-operations');
        if (!container || !state) return;
        
        if (state.setA) {
            const input = container.querySelector('#set-a-input');
            if (input) input.value = state.setA;
        }
        
        if (state.setB) {
            const input = container.querySelector('#set-b-input');
            if (input) input.value = state.setB;
        }
        
        if (state.displayHTML) {
            const result = container.querySelector('#set-result');
            if (result) result.innerHTML = state.displayHTML;
        }
    }
    
    async function saveQuadtreeState() {
        const container = document.getElementById('tree-operations');
        if (!container) return null;
        
        // Get quadtree parameters
        const maxDepth = document.getElementById('max-depth')?.value || 3;
        const quadtreeSize = document.getElementById('quadtree-size')?.value || 400;
        
        // Get the HTML structure of all cells
        const quadtreeContainer = document.getElementById('quadtree-container');
        const cellsHTML = quadtreeContainer?.innerHTML || '';
        
        // Try to find customized cells
        const customizedCells = [];
        quadtreeContainer?.querySelectorAll('.quadtree-cell').forEach(cell => {
            if (cell.classList.contains('customized') || 
                cell.style.backgroundColor || 
                cell.querySelector('.quadtree-cell-custom-text') ||
                cell.querySelector('.quadtree-cell-image')) {
                
                // Extract the customization details
                const customization = {
                    x: parseFloat(cell.style.left) || 0,
                    y: parseFloat(cell.style.top) || 0,
                    width: parseFloat(cell.style.width) || 0,
                    height: parseFloat(cell.style.height) || 0,
                    backgroundColor: cell.style.backgroundColor,
                    opacity: cell.style.opacity,
                    customized: cell.classList.contains('customized')
                };
                
                // Extract text if present
                const textElement = cell.querySelector('.quadtree-cell-custom-text');
                if (textElement) {
                    customization.text = {
                        content: textElement.textContent,
                        color: textElement.style.color,
                        fontSize: textElement.style.fontSize
                    };
                }
                
                // Extract image if present
                const imageElement = cell.querySelector('.quadtree-cell-image');
                if (imageElement) {
                    customization.image = {
                        src: imageElement.src
                    };
                }
                
                customizedCells.push(customization);
            }
        });
        
        return {
            maxDepth,
            quadtreeSize,
            cellsHTML,
            customizedCells
        };
    }
    
    async function loadQuadtreeState(state) {
        const container = document.getElementById('tree-operations');
        if (!container || !state) return;
        
        // Set quadtree parameters
        if (state.maxDepth) {
            const input = document.getElementById('max-depth');
            if (input) input.value = state.maxDepth;
        }
        
        if (state.quadtreeSize) {
            const input = document.getElementById('quadtree-size');
            if (input) input.value = state.quadtreeSize;
        }
        
        // Recreate the quadtree
        const createBtn = document.getElementById('create-quadtree');
        if (createBtn) {
            createBtn.click();
            
            // Wait for the quadtree to be created
            setTimeout(() => {
                // Try to restore customized cells
                const quadtreeContainer = document.getElementById('quadtree-container');
                if (!quadtreeContainer || !state.customizedCells) return;
                
                state.customizedCells.forEach(customization => {
                    // Find a cell at the same position
                    const cells = quadtreeContainer.querySelectorAll('.quadtree-cell');
                    let matchingCell = null;
                    
                    for (const cell of cells) {
                        const x = parseFloat(cell.style.left) || 0;
                        const y = parseFloat(cell.style.top) || 0;
                        const width = parseFloat(cell.style.width) || 0;
                        const height = parseFloat(cell.style.height) || 0;
                        
                        if (Math.abs(x - customization.x) < 1 && 
                            Math.abs(y - customization.y) < 1 &&
                            Math.abs(width - customization.width) < 1 &&
                            Math.abs(height - customization.height) < 1) {
                            matchingCell = cell;
                            break;
                        }
                    }
                    
                    if (matchingCell) {
                        // Apply customizations
                        if (customization.backgroundColor) {
                            matchingCell.style.backgroundColor = customization.backgroundColor;
                        }
                        
                        if (customization.opacity) {
                            matchingCell.style.opacity = customization.opacity;
                        }
                        
                        if (customization.customized) {
                            matchingCell.classList.add('customized');
                        }
                        
                        // Add text if present
                        if (customization.text) {
                            const textElement = document.createElement('div');
                            textElement.className = 'quadtree-cell-custom-text';
                            textElement.textContent = customization.text.content;
                            textElement.style.color = customization.text.color;
                            textElement.style.fontSize = customization.text.fontSize;
                            matchingCell.appendChild(textElement);
                        }
                        
                        // Add image if present
                        if (customization.image && customization.image.src) {
                            const imageElement = document.createElement('img');
                            imageElement.className = 'quadtree-cell-image';
                            imageElement.src = customization.image.src;
                            matchingCell.appendChild(imageElement);
                        }
                    }
                });
            }, 500);
        }
    }

    // ------ CRUD Database ------
    
    async function saveDatabaseState() {
        if (!window.database) return null;
        
        try {
            // Capture database records
            const records = Array.from(window.database.records.entries()).map(([id, record]) => {
                // Clone the record to avoid circular references
                return {
                    id: id,
                    name: record.name,
                    data: record.data,
                    createdAt: record.createdAt ? record.createdAt.toISOString() : null,
                    updatedAt: record.updatedAt ? record.updatedAt.toISOString() : null
                };
            });
            
            return { records };
        } catch (e) {
            console.error('Error saving database state:', e);
            return null;
        }
    }
    
    async function loadDatabaseState(state) {
        if (!window.database || !state || !state.records) return;
        
        try {
            // Clear database
            window.database.deleteAll();
            
            // Restore records
            state.records.forEach(record => {
                window.database.create({
                    id: record.id,
                    name: record.name,
                    data: record.data,
                    createdAt: record.createdAt ? new Date(record.createdAt) : new Date(),
                    updatedAt: record.updatedAt ? new Date(record.updatedAt) : null
                });
            });
            
            // Update display if possible
            if (window.databaseDisplayUpdater && window.databaseDisplayUpdater.updateDatabaseDisplay) {
                window.databaseDisplayUpdater.updateDatabaseDisplay();
            }
        } catch (e) {
            console.error('Error loading database state:', e);
        }
    }

    // ------ System Operations ------
    
    async function saveFileSystemState() {
        try {
            // Get the virtual file system or create an empty one
            const virtualFS = window.virtualFS || {
                root: { type: 'directory', name: 'root', children: {} }
            };
            
            return virtualFS;
        } catch (e) {
            console.error('Error saving file system state:', e);
            return null;
        }
    }
    
    async function loadFileSystemState(state) {
        if (!state) return;
        
        try {
            // Restore virtual file system
            window.virtualFS = state;
            
            // Update file tree display if possible
            if (typeof window.renderFileTree === 'function') {
                window.renderFileTree();
            }
        } catch (e) {
            console.error('Error loading file system state:', e);
        }
    }
    
    async function saveMemoryState() {
        try {
            if (!window.memoryManager) return null;
            
            return {
                memorySlots: window.memoryManager.memorySlots
            };
        } catch (e) {
            console.error('Error saving memory state:', e);
            return null;
        }
    }
    
    async function loadMemoryState(state) {
        if (!window.memoryManager || !state || !state.memorySlots) return;
        
        try {
            // Restore memory slots
            window.memoryManager.memorySlots = state.memorySlots;
            
            // Update memory display if possible
            if (typeof window.updateMemoryDisplay === 'function') {
                window.updateMemoryDisplay();
            }
        } catch (e) {
            console.error('Error loading memory state:', e);
        }
    }
    
    async function saveProcessState() {
        try {
            // Process manager is mostly runtime state, not much to save
            return {
                // Could save process templates/configurations if needed
            };
        } catch (e) {
            console.error('Error saving process state:', e);
            return null;
        }
    }
    
    async function loadProcessState(state) {
        // Mainly for future expansion
        if (!state) return;
        
        try {
            // Restore any saved process configurations
        } catch (e) {
            console.error('Error loading process state:', e);
        }
    }

    // ------ Algorithm States ------
    
    async function saveRecursionState() {
        const container = document.getElementById('recursion-operations');
        if (!container) return null;
        
        return {
            n: document.getElementById('recursion-n')?.value,
            result: document.getElementById('recursion-result')?.innerHTML
        };
    }
    
    async function loadRecursionState(state) {
        if (!state) return;
        
        try {
            if (state.n) {
                const input = document.getElementById('recursion-n');
                if (input) input.value = state.n;
            }
            
            if (state.result) {
                const result = document.getElementById('recursion-result');
                if (result) result.innerHTML = state.result;
            }
        } catch (e) {
            console.error('Error loading recursion state:', e);
        }
    }
    
    async function saveIterationState() {
        const container = document.getElementById('iteration-operations');
        if (!container) return null;
        
        return {
            n: document.getElementById('iteration-n')?.value,
            charset: document.getElementById('charset-input')?.value,
            result: document.getElementById('iteration-result')?.innerHTML
        };
    }
    
    async function loadIterationState(state) {
        if (!state) return;
        
        try {
            if (state.n) {
                const input = document.getElementById('iteration-n');
                if (input) input.value = state.n;
            }
            
            if (state.charset) {
                const input = document.getElementById('charset-input');
                if (input) input.value = state.charset;
            }
            
            if (state.result) {
                const result = document.getElementById('iteration-result');
                if (result) result.innerHTML = state.result;
            }
        } catch (e) {
            console.error('Error loading iteration state:', e);
        }
    }
    
    async function saveSearchState() {
        const container = document.getElementById('search-operations');
        if (!container) return null;
        
        return {
            data: document.getElementById('search-data')?.value,
            query: document.getElementById('search-query')?.value,
            result: document.getElementById('search-result')?.innerHTML
        };
    }
    
    async function loadSearchState(state) {
        if (!state) return;
        
        try {
            if (state.data) {
                const input = document.getElementById('search-data');
                if (input) input.value = state.data;
            }
            
            if (state.query) {
                const input = document.getElementById('search-query');
                if (input) input.value = state.query;
            }
            
            if (state.result) {
                const result = document.getElementById('search-result');
                if (result) result.innerHTML = state.result;
            }
        } catch (e) {
            console.error('Error loading search state:', e);
        }
    }
    
    async function saveBinaryOperationsState() {
        const container = document.getElementById('binary-operations');
        if (!container) return null;
        
        return {
            valueA: document.getElementById('binary-input-a')?.value,
            valueB: document.getElementById('binary-input-b')?.value,
            result: document.getElementById('binary-result')?.innerHTML
        };
    }
    
    async function loadBinaryOperationsState(state) {
        if (!state) return;
        
        try {
            if (state.valueA) {
                const input = document.getElementById('binary-input-a');
                if (input) input.value = state.valueA;
            }
            
            if (state.valueB) {
                const input = document.getElementById('binary-input-b');
                if (input) input.value = state.valueB;
            }
            
            if (state.result) {
                const result = document.getElementById('binary-result');
                if (result) result.innerHTML = state.result;
            }
        } catch (e) {
            console.error('Error loading binary operations state:', e);
        }
    }

    // ------ Advanced Components ------
    
    async function saveSerializationState() {
        const container = document.getElementById('serialization-operations');
        if (!container) return null;
        
        return {
            input: document.getElementById('serialize-input')?.value,
            format: document.getElementById('serialization-format')?.value,
            result: document.getElementById('serialization-result')?.innerHTML
        };
    }
    
    async function loadSerializationState(state) {
        if (!state) return;
        
        try {
            if (state.input) {
                const input = document.getElementById('serialize-input');
                if (input) input.value = state.input;
            }
            
            if (state.format) {
                const select = document.getElementById('serialization-format');
                if (select) select.value = state.format;
            }
            
            if (state.result) {
                const result = document.getElementById('serialization-result');
                if (result) result.innerHTML = state.result;
            }
        } catch (e) {
            console.error('Error loading serialization state:', e);
        }
    }
    
    async function saveCompressionState() {
        const container = document.getElementById('compression-operations');
        if (!container) return null;
        
        return {
            input: document.getElementById('compression-input')?.value,
            method: document.getElementById('compression-method')?.value,
            result: document.getElementById('compression-result')?.innerHTML,
            stats: document.getElementById('compression-stats')?.innerHTML
        };
    }
    
    async function loadCompressionState(state) {
        if (!state) return;
        
        try {
            if (state.input) {
                const input = document.getElementById('compression-input');
                if (input) input.value = state.input;
            }
            
            if (state.method) {
                const select = document.getElementById('compression-method');
                if (select) select.value = state.method;
            }
            
            if (state.result) {
                const result = document.getElementById('compression-result');
                if (result) result.innerHTML = state.result;
            }
            
            if (state.stats) {
                const stats = document.getElementById('compression-stats');
                if (stats) stats.innerHTML = state.stats;
            }
        } catch (e) {
            console.error('Error loading compression state:', e);
        }
    }
    
    async function saveEncodingState() {
        const container = document.getElementById('encoding-operations');
        if (!container) return null;
        
        return {
            input: document.getElementById('encoding-input')?.value,
            method: document.getElementById('encoding-method')?.value,
            result: document.getElementById('encoding-result')?.innerHTML
        };
    }
    
    async function loadEncodingState(state) {
        if (!state) return;
        
        try {
            if (state.input) {
                const input = document.getElementById('encoding-input');
                if (input) input.value = state.input;
            }
            
            if (state.method) {
                const select = document.getElementById('encoding-method');
                if (select) select.value = state.method;
            }
            
            if (state.result) {
                const result = document.getElementById('encoding-result');
                if (result) result.innerHTML = state.result;
            }
        } catch (e) {
            console.error('Error loading encoding state:', e);
        }
    }
    
    async function saveTransactionState() {
        const container = document.getElementById('transactions-operations');
        if (!container) return null;
        
        try {
            // Capture canvas state as image
            const canvas = document.getElementById('drawing-canvas');
            let canvasDataUrl = null;
            
            if (canvas) {
                canvasDataUrl = canvas.toDataURL('image/png');
            }
            
            return {
                canvasState: canvasDataUrl,
                history: document.getElementById('transaction-history')?.innerHTML
            };
        } catch (e) {
            console.error('Error saving transaction state:', e);
            return null;
        }
    }
    
    async function loadTransactionState(state) {
        if (!state) return;
        
        try {
            // Restore canvas state if possible
            if (state.canvasState) {
                const canvas = document.getElementById('drawing-canvas');
                if (canvas) {
                    const ctx = canvas.getContext('2d');
                    if (ctx) {
                        const img = new Image();
                        img.onload = function() {
                            ctx.clearRect(0, 0, canvas.width, canvas.height);
                            ctx.drawImage(img, 0, 0);
                        };
                        img.src = state.canvasState;
                    }
                }
            }
            
            // Restore history display
            if (state.history) {
                const history = document.getElementById('transaction-history');
                if (history) history.innerHTML = state.history;
            }
        } catch (e) {
            console.error('Error loading transaction state:', e);
        }
    }

    // ------ Programming Language ------
    
    async function saveOperatorLangState() {
        const container = document.getElementById('programming-section');
        if (!container) return null;
        
        try {
            // Get editor content
            const editorContent = document.getElementById('code-editor')?.value;
            
            // Get console output
            const consoleOutput = Array.from(
                document.getElementById('language-console')?.childNodes || []
            ).map(node => node.textContent).join('\n');
            
            // Get canvas state
            const canvas = document.getElementById('language-canvas');
            let canvasDataUrl = null;
            
            if (canvas) {
                canvasDataUrl = canvas.toDataURL('image/png');
            }
            
            // Get variables from operatorLang if possible
            let variables = [];
            if (window.operatorLang && window.operatorLang.variables) {
                variables = Array.from(window.operatorLang.variables.entries());
            }
            
            return {
                code: editorContent,
                console: consoleOutput,
                canvasState: canvasDataUrl,
                variables: variables
            };
        } catch (e) {
            console.error('Error saving OperatorLang state:', e);
            return null;
        }
    }
    
    async function loadOperatorLangState(state) {
        if (!state) return;
        
        try {
            // Restore editor content
            if (state.code) {
                const editor = document.getElementById('code-editor');
                if (editor) editor.value = state.code;
            }
            
            // Restore console output
            if (state.console) {
                const consoleEl = document.getElementById('language-console');
                if (consoleEl) {
                    consoleEl.innerHTML = '';
                    state.console.split('\n').forEach(line => {
                        const lineElement = document.createElement('div');
                        lineElement.className = 'console-line';
                        lineElement.textContent = line;
                        consoleEl.appendChild(lineElement);
                    });
                }
            }
            
            // Restore canvas state
            if (state.canvasState) {
                const canvas = document.getElementById('language-canvas');
                if (canvas) {
                    const ctx = canvas.getContext('2d');
                    if (ctx) {
                        const img = new Image();
                        img.onload = function() {
                            ctx.clearRect(0, 0, canvas.width, canvas.height);
                            ctx.drawImage(img, 0, 0);
                        };
                        img.src = state.canvasState;
                    }
                }
            }
            
            // Restore variables if possible
            if (state.variables && window.operatorLang) {
                try {
                    window.operatorLang.variables = new Map(state.variables);
                } catch (e) {
                    console.warn('Could not restore OperatorLang variables:', e);
                }
            }
        } catch (e) {
            console.error('Error loading OperatorLang state:', e);
        }
    }
	
	// Add this function to operator-persistence.js
	function setupSessionManagementListeners() {
		// Save workspace button
		const saveWorkspaceBtn = document.getElementById('save-workspace-btn');
		if (saveWorkspaceBtn) {
			saveWorkspaceBtn.addEventListener('click', saveAllStates);
		}
		
		// Load workspace button
		const loadWorkspaceBtn = document.getElementById('load-workspace-btn');
		if (loadWorkspaceBtn) {
			loadWorkspaceBtn.addEventListener('click', loadFromLocalStorage);
		}
		
		// Export workspace button
		const exportWorkspaceBtn = document.getElementById('export-workspace-btn');
		if (exportWorkspaceBtn) {
			exportWorkspaceBtn.addEventListener('click', exportWorkspace);
		}
		
		// Import workspace button
		const importWorkspaceBtn = document.getElementById('import-workspace-btn');
		if (importWorkspaceBtn) {
			importWorkspaceBtn.addEventListener('click', importWorkspace);
		}
		
		// Auto-save toggle
		const autoSaveToggle = document.getElementById('auto-save-toggle');
		const autoSaveLabel = document.getElementById('auto-save-label');
		if (autoSaveToggle && autoSaveLabel) {
			// Set initial state
			const autoSaveEnabled = localStorage.getItem(CONFIG.autoSaveKey) === 'true';
			autoSaveToggle.checked = autoSaveEnabled;
			autoSaveLabel.textContent = `Auto-save is ${autoSaveEnabled ? 'on' : 'off'}`;
			
			// Add change listener
			autoSaveToggle.addEventListener('change', function() {
				const newState = this.checked;
				localStorage.setItem(CONFIG.autoSaveKey, newState.toString());
				autoSaveLabel.textContent = `Auto-save is ${newState ? 'on' : 'off'}`;
				showNotification(`Auto-save ${newState ? 'enabled' : 'disabled'}`, 'info');
			});
		}
		
		// Clear storage button
		const clearStorageBtn = document.getElementById('clear-storage-btn');
		if (clearStorageBtn) {
			clearStorageBtn.addEventListener('click', function() {
				if (confirm('Are you sure you want to clear all saved workspace data? This cannot be undone.')) {
					clearAllStoredData();
					updateWorkspaceInfo();
					showNotification('All stored workspace data has been cleared', 'info');
				}
			});
		}
	}
	
	// Add this function to operator-persistence.js
	async function collectAllStates() {
		const fullState = {
			version: CONFIG.version,
			timestamp: new Date().toISOString(),
			components: {}
		};
		
		// Save each component's state
		for (const [id, component] of stateRegistry.entries()) {
			if (!component.active) continue;
			
			try {
				const componentState = await component.save();
				if (componentState !== undefined) {
					fullState.components[id] = componentState;
				}
			} catch (error) {
				console.error(`Error saving state for ${id}:`, error);
			}
		}
		
		return fullState;
	}

	// Add these functions to operator-persistence.js
	function exportWorkspace() {
		safeExecute(async () => {
			// Collect all state
			const fullState = await collectAllStates();
			
			// Create a JSON file
			const blob = new Blob([JSON.stringify(fullState, null, 2)], {type: 'application/json'});
			const url = URL.createObjectURL(blob);
			
			// Create download link
			const a = document.createElement('a');
			a.href = url;
			a.download = `operator_workspace_${new Date().toISOString().replace(/:/g, '-')}.json`;
			a.click();
			
			// Clean up
			setTimeout(() => URL.revokeObjectURL(url), 5000);
			
			// Add to history
			addHistoryItem('Workspace exported to file');
			
			showNotification('Workspace exported successfully', 'success');
			return 'Workspace exported successfully';
		}, error => {
			showNotification('Failed to export workspace: ' + error.message, 'error');
		});
	}

	function importWorkspace() {
		// Create file input
		const fileInput = document.createElement('input');
		fileInput.type = 'file';
		fileInput.accept = '.json';
		fileInput.style.display = 'none';
		document.body.appendChild(fileInput);
		
		fileInput.addEventListener('change', function(e) {
			const file = e.target.files[0];
			if (!file) return;
			
			const reader = new FileReader();
			reader.onload = function(e) {
				safeExecute(async () => {
					// Parse the file
					const data = JSON.parse(e.target.result);
					
					// Validate
					if (!data.timestamp) {
						throw new Error('Invalid workspace file format');
					}
					
					// Confirm
					if (!confirm(`Load workspace from ${new Date(data.timestamp).toLocaleString()}? This will replace your current workspace.`)) {
						return;
					}
					
					// Load the data
					await loadFromObject(data);
					
					// Add to history
					addHistoryItem('Workspace imported from file');
					
					showNotification('Workspace imported successfully', 'success');
					updateWorkspaceInfo();
					
					return 'Workspace imported successfully';
				}, error => {
					showNotification('Failed to import workspace: ' + error.message, 'error');
				});
			};
			
			reader.readAsText(file);
			
			// Clean up
			document.body.removeChild(fileInput);
		});
		
		fileInput.click();
	}

	function clearAllStoredData() {
		// Clear localStorage
		const metadataKey = localStorage.getItem(CONFIG.metadataKey);
		if (metadataKey) {
			try {
				const metadata = JSON.parse(metadataKey);
				// Remove chunks
				for (let i = 0; i < metadata.chunks; i++) {
					localStorage.removeItem(`${CONFIG.chunkPrefix}${i}`);
				}
			} catch (e) {
				console.error('Error parsing metadata:', e);
			}
			
			// Remove metadata
			localStorage.removeItem(CONFIG.metadataKey);
		}
		
		// Add to history
		addHistoryItem('Cleared all stored workspace data');
	}

	function addHistoryItem(action) {
		const historyContainer = document.getElementById('session-history');
		if (!historyContainer) return;
		
		// Remove empty history message if present
		const emptyHistory = historyContainer.querySelector('.empty-history');
		if (emptyHistory) {
			historyContainer.removeChild(emptyHistory);
		}
		
		// Create history item
		const historyItem = document.createElement('div');
		historyItem.className = 'history-item';
		
		const now = new Date();
		historyItem.innerHTML = `
			<div class="history-time">${now.toLocaleTimeString()}</div>
			<div class="history-action">${action}</div>
		`;
		
		// Add to container (at the top)
		if (historyContainer.firstChild) {
			historyContainer.insertBefore(historyItem, historyContainer.firstChild);
		} else {
			historyContainer.appendChild(historyItem);
		}
		
		// Limit history items
		const maxItems = 10;
		const items = historyContainer.querySelectorAll('.history-item');
		if (items.length > maxItems) {
			for (let i = maxItems; i < items.length; i++) {
				historyContainer.removeChild(items[i]);
			}
		}
	}

	function updateWorkspaceInfo() {
		const lastSavedTime = document.getElementById('last-saved-time');
		const componentCount = document.getElementById('component-count');
		const storageUsed = document.getElementById('storage-used');
		
		if (!lastSavedTime || !componentCount || !storageUsed) return;
		
		// Get last saved time
		const metadataStr = localStorage.getItem(CONFIG.metadataKey);
		if (metadataStr) {
			try {
				const metadata = JSON.parse(metadataStr);
				lastSavedTime.textContent = new Date(metadata.timestamp).toLocaleString();
				componentCount.textContent = stateRegistry.size.toString();
				
				// Calculate storage used
				let size = metadata.size || 0;
				let sizeStr;
				
				if (size < 1024) {
					sizeStr = `${size} bytes`;
				} else if (size < 1024 * 1024) {
					sizeStr = `${(size / 1024).toFixed(2)} KB`;
				} else {
					sizeStr = `${(size / (1024 * 1024)).toFixed(2)} MB`;
				}
				
				storageUsed.textContent = sizeStr;
			} catch (e) {
				console.error('Error parsing metadata:', e);
				lastSavedTime.textContent = 'Error reading data';
			}
		} else {
			lastSavedTime.textContent = 'Never';
			componentCount.textContent = stateRegistry.size.toString();
			storageUsed.textContent = '0 bytes';
		}
	}

	// Add this utility function
	function safeExecute(func, errorCallback) {
		try {
			return func();
		} catch (error) {
			console.error('Operation error:', error);
			if (errorCallback) {
				errorCallback(error);
			}
			return null;
		}
	}
	
	// Add this to initPersistenceSystem function
	function addSessionManagementStyles() {
		const styleElement = document.createElement('style');
		styleElement.textContent = `
			/* Session Management Styles */
			.workspace-info {
				background-color: var(--background-color);
				border: 1px solid var(--secondary-color);
				border-radius: 4px;
				padding: 15px;
			}
			
			.info-item {
				display: flex;
				justify-content: space-between;
				margin-bottom: 10px;
				padding-bottom: 10px;
				border-bottom: 1px solid rgba(0,0,0,0.05);
			}
			
			.info-item:last-child {
				margin-bottom: 0;
				padding-bottom: 0;
				border-bottom: none;
			}
			
			.info-label {
				font-weight: bold;
				color: var(--primary-color);
			}
			
			.session-history {
				max-height: 200px;
				overflow-y: auto;
				background-color: var(--background-color);
				border: 1px solid var(--secondary-color);
				border-radius: 4px;
				padding: 10px;
			}
			
			.history-item {
				padding: 8px;
				border-bottom: 1px solid rgba(0,0,0,0.05);
			}
			
			.history-item:last-child {
				border-bottom: none;
			}
			
			.history-time {
				font-size: 0.8em;
				color: var(--secondary-color);
			}
			
			.history-action {
				font-weight: bold;
			}
			
			.empty-history {
				text-align: center;
				color: #888;
				padding: 20px 0;
			}
			
			.toggle-container {
				display: flex;
				align-items: center;
				gap: 10px;
				margin-bottom: 10px;
			}
			
			.toggle {
				position: relative;
				display: inline-block;
				width: 50px;
				height: 24px;
			}
			
			.toggle input {
				opacity: 0;
				width: 0;
				height: 0;
			}
			
			.toggle-slider {
				position: absolute;
				cursor: pointer;
				top: 0;
				left: 0;
				right: 0;
				bottom: 0;
				background-color: #ccc;
				transition: .4s;
				border-radius: 24px;
			}
			
			.toggle-slider:before {
				position: absolute;
				content: "";
				height: 16px;
				width: 16px;
				left: 4px;
				bottom: 4px;
				background-color: white;
				transition: .4s;
				border-radius: 50%;
			}
			
			input:checked + .toggle-slider {
				background-color: var(--primary-color);
			}
			
			input:checked + .toggle-slider:before {
				transform: translateX(26px);
			}
			
			.hint-text {
				font-size: 0.8em;
				color: #666;
				margin-top: 5px;
			}
			
			.mt-20 {
				margin-top: 20px;
			}
		`;
		document.head.appendChild(styleElement);
	}

	// Call this function
	addSessionManagementStyles();



	// Update the export object at the bottom of operator-persistence.js
	window.OperatorPersistence = {
		saveAllStates,
		loadAllStates: loadFromLocalStorage,
		loadFromFile: loadWorkspaceFromFile,
		loadFromObject,
		exportWorkspace,
		importWorkspace,
		registerComponent,
		showNotification,
		updateWorkspaceInfo,
		addHistoryItem
	};

})();