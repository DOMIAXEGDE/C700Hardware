/**
 * operator-dropdown.js
 * 
 * This file provides the dropdown menu system for the Operator framework,
 * allowing seamless integration of different subsystems into the main interface.
 * 
 * @module OperatorDropdown
 * @version 1.0.0
 * @author Claude AI
 */

// Access the shared namespace for Operator framework

/**
 * Dropdown system for integrating external systems
 * @namespace OperatorDropdown
 */
OperatorFramework.Dropdown = (function() {
    'use strict';

    // Private variables
    let _initialized = false;
    let _availableSystems = [];
    let _activeSystem = null;
    let _navigationElement = null;
    
    /**
     * System configuration object format
     * @typedef {Object} SystemConfig
     * @property {string} id - Unique identifier for the system
     * @property {string} name - Display name for the system
     * @property {string} description - Brief description of the system
     * @property {Function} loadFunction - Function to call to load the system
     * @property {boolean} [isLoaded=false] - Whether the system is currently loaded
     */
    
    /**
     * Initialize the dropdown system
     * @param {string} navElementId - ID of the DOM element to contain the dropdown
     * @returns {boolean} Success status
     */
    function initialize(navElementId) {
        if (_initialized) {
            console.warn('OperatorDropdown is already initialized');
            return false;
        }
        
        // Find the navigation element
        _navigationElement = document.getElementById(navElementId);
        if (!_navigationElement) {
            console.error(`Navigation element with ID "${navElementId}" not found`);
            return false;
        }
        
        // Add styles for the dropdown
        _addDropdownStyles();
        
        // Create the initial dropdown structure
        _createDropdownStructure();
        
        _initialized = true;
        console.log('OperatorDropdown initialized successfully');
        return true;
    }
    
    /**
     * Add a system to the dropdown
     * @param {SystemConfig} systemConfig - The system configuration
     * @returns {boolean} Success status
     */
    function addSystem(systemConfig) {
        if (!_initialized) {
            console.error('OperatorDropdown not initialized, call initialize() first');
            return false;
        }
        
        // Validate the system config
        if (!_validateSystemConfig(systemConfig)) {
            return false;
        }
        
        // Check for duplicate IDs
        if (_availableSystems.some(sys => sys.id === systemConfig.id)) {
            console.error(`System with ID "${systemConfig.id}" already exists`);
            return false;
        }
        
        // Add default properties if not provided
        const system = {
            ...systemConfig,
            isLoaded: false
        };
        
        // Add to available systems
        _availableSystems.push(system);
        
        // Add to the dropdown menu
        _addSystemToDropdown(system);
        
        console.log(`Added system "${system.name}" to dropdown`);
        return true;
    }
    
    /**
     * Load a system by ID
     * @param {string} systemId - ID of the system to load
     * @returns {boolean} Success status
     */
    function loadSystem(systemId) {
        if (!_initialized) {
            console.error('OperatorDropdown not initialized, call initialize() first');
            return false;
        }
        
        // Find the system
        const system = _availableSystems.find(sys => sys.id === systemId);
        if (!system) {
            console.error(`System with ID "${systemId}" not found`);
            return false;
        }
        
        // Don't reload if already active
        if (_activeSystem === systemId && system.isLoaded) {
            console.log(`System "${system.name}" is already active`);
            return true;
        }
        
        try {
            // Call the system's load function
            system.loadFunction();
            
            // Update system status
            system.isLoaded = true;
            _activeSystem = systemId;
            
            // Update UI to indicate active system
            _updateActiveSystemUI(systemId);
            
            console.log(`Successfully loaded system "${system.name}"`);
            return true;
        } catch (error) {
            console.error(`Error loading system "${system.name}":`, error);
            return false;
        }
    }
    
    /**
     * Unload the currently active system
     * @returns {boolean} Success status
     */
    function unloadActiveSystem() {
        if (!_activeSystem) {
            console.log('No active system to unload');
            return false;
        }
        
        const system = _availableSystems.find(sys => sys.id === _activeSystem);
        if (!system) {
            console.error(`Active system with ID "${_activeSystem}" not found`);
            return false;
        }
        
        if (typeof system.unloadFunction === 'function') {
            try {
                system.unloadFunction();
            } catch (error) {
                console.error(`Error unloading system "${system.name}":`, error);
            }
        }
        
        system.isLoaded = false;
        _activeSystem = null;
        
        // Update UI
        _updateActiveSystemUI(null);
        
        console.log(`Unloaded system "${system.name}"`);
        return true;
    }
    
    /**
     * Get the currently active system
     * @returns {string|null} ID of the active system, or null if none
     */
    function getActiveSystem() {
        return _activeSystem;
    }
    
    /**
     * Get a list of all available systems
     * @returns {Array<SystemConfig>} Array of system configurations
     */
    function getAllSystems() {
        return [..._availableSystems];
    }
    
    /**
     * Check if a system is loaded
     * @param {string} systemId - ID of the system to check
     * @returns {boolean} Whether the system is loaded
     */
    function isSystemLoaded(systemId) {
        const system = _availableSystems.find(sys => sys.id === systemId);
        return system ? system.isLoaded : false;
    }
    
    /**
     * Validate a system configuration object
     * @private
     * @param {SystemConfig} config - The system configuration to validate
     * @returns {boolean} Whether the configuration is valid
     */
    function _validateSystemConfig(config) {
        if (!config) {
            console.error('System configuration is required');
            return false;
        }
        
        if (!config.id || typeof config.id !== 'string') {
            console.error('System must have a valid string ID');
            return false;
        }
        
        if (!config.name || typeof config.name !== 'string') {
            console.error('System must have a valid string name');
            return false;
        }
        
        if (!config.loadFunction || typeof config.loadFunction !== 'function') {
            console.error('System must have a valid load function');
            return false;
        }
        
        return true;
    }
    
    /**
     * Add CSS styles for the dropdown system
     * @private
     */
    function _addDropdownStyles() {
        const styleElement = document.createElement('style');
        styleElement.textContent = `
            /* Operator Dropdown Styles */
            .op-dropdown {
                position: relative;
                display: inline-block;
                width: 100%;
                margin-bottom: 10px;
            }
            
            .op-dropdown-button {
                width: 100%;
                padding: 10px;
                text-align: center;
                cursor: pointer;
                background-color: var(--primary-color, #4B5320);
                color: white;
                border: 2px solid var(--secondary-color, #BDB76B);
                transition: background-color 0.3s ease;
                font-family: var(--font-main, "Fira Code", "Consolas", monospace);
            }
            
            .op-dropdown-button:hover {
                background-color: var(--secondary-color, #BDB76B);
                color: var(--text-color, #333333);
            }
            
            .op-dropdown-content {
                display: none;
                position: absolute;
                background-color: white;
                min-width: 160px;
                box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
                z-index: 1000;
                width: 100%;
            }
            
            .op-dropdown:hover .op-dropdown-content {
                display: block;
            }
            
            .op-system-button {
                width: 100%;
                text-align: left;
                padding: 10px;
                display: block;
                background-color: white;
                color: var(--text-color, #333333);
                border: none;
                border-bottom: 1px solid #e0e0e0;
                cursor: pointer;
                transition: background-color 0.2s ease;
                font-family: var(--font-main, "Fira Code", "Consolas", monospace);
            }
            
            .op-system-button:hover {
                background-color: var(--background-color, #F5F5DC);
            }
            
            .op-system-button.active {
                border-left: 5px solid var(--primary-color, #4B5320);
                background-color: var(--background-color, #F5F5DC);
                font-weight: bold;
            }
            
			.op-system-tooltip {
				position: absolute;
				background-color: #333;
				color: white;
				padding: 5px 10px;
				border-radius: 4px;
				font-size: 0.8rem;
				z-index: 1001;
				visibility: hidden;
				opacity: 0;
				transition: opacity 0.3s;
				max-width: 200px;
				/* Change these properties */
				right: 105%;    /* Position to the left instead of using left property */
				left: auto;     /* Clear the left property */
				top: 50%;
				transform: translateY(-50%);
			}

			/* Add a small triangle/arrow pointing right */
			.op-system-tooltip::after {
				content: "";
				position: absolute;
				top: 50%;
				left: 100%;  /* Position at the right edge */
				margin-top: -5px;
				border-width: 5px;
				border-style: solid;
				border-color: transparent transparent transparent #333; /* Make triangle point right */
			}
            
            .op-system-button:hover .op-system-tooltip {
                visibility: visible;
                opacity: 1;
            }
        `;
        document.head.appendChild(styleElement);
    }
    
    /**
     * Create the initial dropdown structure
     * @private
     */
    function _createDropdownStructure() {
        const navSection = document.createElement('div');
        navSection.className = 'nav-section';
        navSection.innerHTML = `
            <h3>External Systems</h3>
            <div class="op-dropdown">
                <button class="op-dropdown-button">Select System</button>
                <div class="op-dropdown-content" id="op-systems-list">
                    <!-- Systems will be added here -->
                    <div class="op-no-systems">No systems available</div>
                </div>
            </div>
        `;
        
        _navigationElement.appendChild(navSection);
    }
    
    /**
     * Add a system to the dropdown UI
     * @private
     * @param {SystemConfig} system - The system to add
     */
    function _addSystemToDropdown(system) {
        const systemsList = document.getElementById('op-systems-list');
        
        // Remove the "no systems" message if it exists
        const noSystems = systemsList.querySelector('.op-no-systems');
        if (noSystems) {
            systemsList.removeChild(noSystems);
        }
        
        // Create button for the system
        const systemButton = document.createElement('button');
        systemButton.id = `op-system-${system.id}`;
        systemButton.className = 'op-system-button';
        systemButton.dataset.systemId = system.id;
        systemButton.innerHTML = `
            ${system.name}
            <span class="op-system-tooltip">${system.description || system.name}</span>
        `;
        
        // Add click handler
        systemButton.addEventListener('click', () => {
            loadSystem(system.id);
        });
        
        // Add to the dropdown
        systemsList.appendChild(systemButton);
    }
    
    /**
     * Update the UI to indicate the active system
     * @private
     * @param {string|null} systemId - ID of the active system, or null if none
     */
    function _updateActiveSystemUI(systemId) {
        // Remove active class from all buttons
        const allButtons = document.querySelectorAll('.op-system-button');
        allButtons.forEach(button => {
            button.classList.remove('active');
        });
        
        // Add active class to the active system
        if (systemId) {
            const activeButton = document.getElementById(`op-system-${systemId}`);
            if (activeButton) {
                activeButton.classList.add('active');
            }
        }
        
        // Update dropdown button text
        const dropdownButton = document.querySelector('.op-dropdown-button');
        if (dropdownButton) {
            if (systemId) {
                const system = _availableSystems.find(sys => sys.id === systemId);
                dropdownButton.textContent = system ? system.name : 'Select System';
            } else {
                dropdownButton.textContent = 'Select System';
            }
        }
    }
    
    /**
     * Search for systems by name or description
     * @param {string} query - The search query
     * @returns {Array<SystemConfig>} Array of matching system configurations
     */
    function searchSystems(query) {
        if (!query || typeof query !== 'string') {
            return [..._availableSystems];
        }
        
        const normalizedQuery = query.toLowerCase();
        return _availableSystems.filter(system => {
            return system.name.toLowerCase().includes(normalizedQuery) || 
                   (system.description && system.description.toLowerCase().includes(normalizedQuery));
        });
    }
    
    /**
     * Filter and update the dropdown based on a search query
     * @param {string} query - The search query
     */
    function filterDropdown(query) {
        const matchingSystems = searchSystems(query);
        const systemsList = document.getElementById('op-systems-list');
        
        // Remove all existing items
        systemsList.innerHTML = '';
        
        if (matchingSystems.length === 0) {
            const noResults = document.createElement('div');
            noResults.className = 'op-no-systems';
            noResults.textContent = 'No matching systems found';
            systemsList.appendChild(noResults);
        } else {
            // Add matching systems
            matchingSystems.forEach(system => {
                _addSystemToDropdown(system);
            });
            
            // Restore active state
            if (_activeSystem) {
                _updateActiveSystemUI(_activeSystem);
            }
        }
    }
    
    /**
     * Add a search box to filter systems
     * @param {string} [placeholder="Search systems..."] - Placeholder text for the search box
     */
    function addSearchBox(placeholder = "Search systems...") {
        const navSection = _navigationElement.querySelector('.nav-section:last-child');
        if (!navSection) return;
        
        const searchContainer = document.createElement('div');
        searchContainer.className = 'op-search-container';
        searchContainer.style.padding = '10px 0';
        
        const searchInput = document.createElement('input');
        searchInput.type = 'text';
        searchInput.placeholder = placeholder;
        searchInput.className = 'op-search-input';
        searchInput.style.width = '100%';
        searchInput.style.padding = '8px';
        searchInput.style.border = '1px solid var(--secondary-color, #BDB76B)';
        searchInput.style.fontFamily = 'var(--font-main, "Fira Code", "Consolas", monospace)';
        
        searchInput.addEventListener('input', (e) => {
            filterDropdown(e.target.value);
        });
        
        searchContainer.appendChild(searchInput);
        navSection.appendChild(searchContainer);
    }
    
    // Public API
    return {
        initialize,
        addSystem,
        loadSystem,
        unloadActiveSystem,
        getActiveSystem,
        getAllSystems,
        isSystemLoaded,
        searchSystems,
        filterDropdown,
        addSearchBox
    };
})();

// Automatically initialize when the DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    // Look for the main navigation element
    const mainNav = document.getElementById('main-nav');
    if (mainNav) {
        OperatorFramework.Dropdown.initialize('main-nav');
        
        // Optional: Add search capability
        OperatorFramework.Dropdown.addSearchBox();
    } else {
        console.warn('Main navigation element #main-nav not found, OperatorDropdown not initialized');
    }
});