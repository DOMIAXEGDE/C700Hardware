/**
 * operator-map.js
 * 
 * This module implements the Map System for the Operator framework,
 * providing charset management and string ID calculation functionality.
 * It integrates with the operator-dropdown.js system.
 * 
 * @module OperatorMap
 * @version 1.0.0
 * @depends OperatorFramework.Dropdown
 */

// Access the shared namespace for Operator framework

/**
 * Map System for charset operations and string ID calculations
 * @namespace OperatorMap
 */
OperatorFramework.Map = (function() {
    'use strict';

    // Private module variables
    let _initialized = false;
    let _section = null;
    let _charsetConfig = [];
    let _uniqueCharset = [];
    let _defaultOptions = {
        containerId: 'main', // ID of the container to add the map section to
        sectionId: 'map-system-section' // ID for the created section element
    };
    let _options = {};
    
    /**
     * Initialize the Map System
     * @param {Object} options - Configuration options
     * @param {string} [options.containerId='main'] - ID of the container to add the map section to
     * @param {string} [options.sectionId='map-system-section'] - ID for the created section element
     * @returns {boolean} Success status
     */
    function initialize(options = {}) {
        if (_initialized) {
            console.warn('OperatorMap is already initialized');
            return false;
        }
        
        // Merge options with defaults
        _options = { ..._defaultOptions, ...options };
        
        // Initialize the character set configuration
        _initCharsetConfig();
        
        // Generate the unique charset based on the configuration
        _uniqueCharset = generateCharsetFromConfig(_charsetConfig);
        
        console.log(`OperatorMap initialized with ${_uniqueCharset.length} characters`);
        _initialized = true;
        
        // Register with dropdown system if available
        if (OperatorFramework.Dropdown) {
            OperatorFramework.Dropdown.addSystem({
                id: 'map',
                name: 'Charset App',
                description: 'Calculate String IDs and perform charset operations',
                loadFunction: loadMapSystem
            });
            console.log('Map System registered with OperatorFramework.Dropdown');
        } else {
            console.warn('OperatorFramework.Dropdown not available, Map System not registered');
        }
        
        return true;
    }
    
    /**
     * Load the Map System UI and functionality
     * @returns {boolean} Success status
     */
    function loadMapSystem() {
        if (!_initialized) {
            console.error('OperatorMap not initialized, call initialize() first');
            return false;
        }
        
        // Check if already loaded
        if (_section && document.getElementById(_options.sectionId)) {
            showMapSection();
            return true;
        }
        
        // Get container
        //const container = document.getElementById(_options.containerId);
		// Use:
		const container = document.querySelector('main');
		if (!container) {
            console.error(`Container with ID "${_options.containerId}" not found`);
            return false;
        }
        
        // Create Map System section
        _section = document.createElement('section');
        _section.id = _options.sectionId;
        _section.className = 'operation-section';
        
        // Populate with Map System content
        _section.innerHTML = _getMapSystemHTML();
        
        // Add to container
        container.appendChild(_section);
        
        // Add styles
        _addMapSystemStyles();
        
        // Initialize event listeners
        _initMapSystemEventListeners();
        
        // Show the section
        showMapSection();
        
        console.log('Map System loaded successfully');
        return true;
    }
    
    /**
     * Show the Map System section and hide other sections
     */
    function showMapSection() {
        if (!_section) return;
        
        // Hide all sections
        const allSections = document.querySelectorAll('.operation-section');
        allSections.forEach(section => {
            section.classList.remove('active');
        });
        
        // Show Map section
        _section.classList.add('active');
    }
    
    /**
     * Generate the Map System HTML content
     * @private
     * @returns {string} HTML content
     */
    function _getMapSystemHTML() {
        return `
            <h2>Charset App (Spatial Systems Engineering)</h2>
            <div class="operation-container">
                <div class="operation-controls">
                    <div id="main-menu">
                        <h3>Choose an option:</h3>
                        <button id="show-generate-combinations">Generate Combinations</button>
                        <button id="show-calculate-string-id">Calculate String ID</button>
                        <button id="show-decode-id">Decode ID to String</button>
                        <button id="show-find-optimal-variable">Find Optimal Variable and Save to File</button>
                    </div>
                    
                    <div id="color-bar" style="width: 100%; height: 20px; background-color: gold; margin-top: 10px;"></div>
                    
                    <div id="option-container" style="display: none;">
                        <!-- Mode 1: Generate Combinations -->
                        <div id="generate-combinations" style="display: none;">
                            <h3>Generate Combinations</h3>
                            <label for="combination-size">Enter the size of combinations (n):</label>
                            <input type="number" id="combination-size">
                            <br>
                            <label for="output-file-generate">Enter the name of the output file:</label>
                            <input type="text" id="output-file-generate">
                            <br>
                            <label for="use-multithreading">Use Multithreading:</label>
                            <select id="use-multithreading">
                                <option value="yes">Yes</option>
                                <option value="no">No</option>
                            </select>
                            <br>
                            <button id="generate-combinations-btn">Generate</button>
                        </div>
                        
                        <!-- Mode 2: Calculate String ID -->
                        <div id="calculate-string-id" style="display: none;">
                            <h3>Calculate String ID</h3>
                            <label for="custom-string">Enter your custom string:</label>
                            <textarea id="custom-string" rows="10" cols="50" wrap="off"></textarea>
                            <br>
                            <button id="calculate-string-id-btn">Calculate</button>
                            <p id="string-id-result"></p>
                            <div id="character-word-count">Characters: 0, Words: 0</div>
                        </div>
                        
                        <!-- Mode 3: Decode ID to String -->
                        <div id="decode-id" style="display: none;">
                            <h3>Decode ID to String</h3>
                            <label for="string-id">Enter the ID to decode:</label>
                            <input type="number" id="string-id">
                            <br>
                            <button id="decode-id-btn">Decode</button>
                            <p id="decoded-string-result"></p>
                        </div>
                        
                        <!-- Mode 4: Find Optimal Variable -->
                        <div id="find-optimal-variable" style="display: none;">
                            <h3>Find Optimal Variable and Save to File</h3>
                            <label for="user-number">Enter the user number:</label>
                            <input type="number" id="user-number">
                            <br>
                            <label for="output-file-optimal">Enter the name of the output file:</label>
                            <input type="text" id="output-file-optimal">
                            <br>
                            <button id="find-optimal-variable-btn">Find and Save</button>
                        </div>
                    </div>
                </div>
                
                <div class="operation-result">
                    <h3>Map System Result</h3>
                    <div id="map-result-display" class="result-container">
                        <p>Select an operation from the left panel to start.</p>
                    </div>
                </div>
            </div>
        `;
    }
    
    /**
     * Add CSS styles for the Map System
     * @private
     */
    function _addMapSystemStyles() {
        const styleId = 'operator-map-styles';
        
        // Don't add styles if they already exist
        if (document.getElementById(styleId)) return;
        
        const styleElement = document.createElement('style');
        styleElement.id = styleId;
        styleElement.textContent = `
            /* Basic Reset */
            #map-system-section * {
                margin: 0;
                padding: 0;
                box-sizing: border-box;
            }

            /* Body Styling - adapted for the section */
            #map-system-section {
                font-family: "Fira Code", "Consolas", monospace;
                color: #333333; /* Dark Gray */
            }

            /* Heading Styles */
            #map-system-section h3 {
                color: #4B5320; /* Army Green */
                margin-bottom: 15px;
                text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.3);
                font-weight: 600;
            }

            /* Button Styles */
            #map-system-section button {
                background-color: #4B5320; /* Army Green */
                color: #FFFFFF;
                padding: 10px 20px;
                font-size: 16px;
                border: 2px solid #BDB76B; /* Dark Khaki */
                cursor: pointer;
                transition: background-color 0.3s ease, color 0.3s ease;
                font-family: "Fira Code", "Consolas", monospace;
                margin-top: 10px;
            }

            #map-system-section button:hover {
                background-color: #BDB76B; /* Dark Khaki */
                color: #333333; /* Dark Gray */
            }

            /* Input and Textarea Styles */
            #map-system-section input[type="text"], 
            #map-system-section input[type="number"], 
            #map-system-section textarea, 
            #map-system-section select {
                width: calc(100% - 20px);
                padding: 10px;
                font-size: 16px;
                background-color: #F5F5DC; /* Beige */
                color: #333333; /* Dark Gray */
                border: 2px solid #BDB76B; /* Dark Khaki */
                font-family: "Fira Code", "Consolas", monospace;
                margin-bottom: 10px;
            }

            #map-system-section textarea {
                resize: none; /* Disables resizing of the textarea */
            }

            /* Results Styling */
            #string-id-result, #decoded-string-result {
                background-color: #FFFFFF; /* White */
                padding: 10px;
                border: 2px solid #BDB76B; /* Dark Khaki */
                font-family: "Fira Code", "Consolas", monospace;
                box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
                color: #333333; /* Dark Gray */
                word-wrap: break-word;
                white-space: pre-wrap; /* Preserves spaces and line breaks */
                margin-top: 10px;
            }

            /* Color bar styling */
            #color-bar {
                width: 100%;               /* Full width */
                height: 20px;              /* Fixed height */
                background-color: #BDB76B; /* Dark Khaki */
                margin-top: 10px;          /* Space above the bar */
                border: 2px solid #4B5320; /* Army Green border */
                box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3); /* Subtle shadow */
                transition: background-color 0.3s ease; /* Smooth transition for color change */
            }
        `;
        
        document.head.appendChild(styleElement);
    }
    
    /**
     * Initialize the charset configuration
     * @private
     */
    function _initCharsetConfig() {
        _charsetConfig = [
            { name: 'Basic Latin', range: [0x0020, 0x007F] },
            { name: 'Latin-1 Supplement', range: [0x0080, 0x00FF] },
            { name: 'Latin Extended-A', range: [0x0100, 0x017F] },
            { name: 'Latin Extended-B', range: [0x0180, 0x024F] },
            { name: 'Greek and Coptic', range: [0x0370, 0x03FF] },
            { name: 'Cyrillic', range: [0x0400, 0x04FF] },
            { name: 'Arabic', range: [0x0600, 0x06FF] },
            { name: 'Hebrew', range: [0x0590, 0x05FF] },
            { name: 'Devanagari', range: [0x0900, 0x097F] },
            { name: 'Mathematical Operators', range: [0x2200, 0x22FF] },
            { name: 'Supplemental Mathematical Operators', range: [0x2A00, 0x2AFF] },
            { name: 'Miscellaneous Technical', range: [0x2300, 0x23FF] },
            { name: 'Miscellaneous Symbols and Arrows', range: [0x2190, 0x21FF] },
            { name: 'CJK Unified Ideographs', range: [0x4E00, 0x9FFF] },
            { name: 'Hangul Syllables', range: [0xAC00, 0xD7AF] },
            { name: 'Hiragana', range: [0x3040, 0x309F] },
            { name: 'Katakana', range: [0x30A0, 0x30FF] },
            { name: 'Bopomofo', range: [0x3100, 0x312F] },
            { name: 'Currency Symbols', range: [0x20A0, 0x20CF] },
            { name: 'Additional Punctuation', range: [0x2000, 0x206F] }
        ];
    }
    
    /**
     * Generate a charset from configuration
     * @param {Array} config - Array of charset range configurations
     * @returns {Array} Array of characters in the charset
     */
    function generateCharsetFromConfig(config) {
        const charset = new Set();
        config.forEach(block => {
            for (let i = block.range[0]; i <= block.range[1]; i++) {
                try {
                    charset.add(String.fromCharCode(i));
                } catch (e) {
                    console.error(`Failed to add character code ${i}: ${e.message}`);
                }
            }
        });
        // Explicitly add newline and tab characters
        charset.add('\n');
        charset.add('\t');
        return Array.from(charset);
    }
    
    /**
     * Initialize event listeners for the Map System
     * @private
     */
    function _initMapSystemEventListeners() {
        // Option buttons
        document.getElementById('show-generate-combinations').addEventListener('click', () => showOption('generate-combinations'));
        document.getElementById('show-calculate-string-id').addEventListener('click', () => showOption('calculate-string-id'));
        document.getElementById('show-decode-id').addEventListener('click', () => showOption('decode-id'));
        document.getElementById('show-find-optimal-variable').addEventListener('click', () => showOption('find-optimal-variable'));
        
        // Action buttons
        document.getElementById('generate-combinations-btn').addEventListener('click', generateCombinations);
        document.getElementById('calculate-string-id-btn').addEventListener('click', calculateStringID);
        document.getElementById('decode-id-btn').addEventListener('click', decodeID);
        document.getElementById('find-optimal-variable-btn').addEventListener('click', findOptimalVariable);
        
        // Text area for character count
        const customStringTextarea = document.getElementById('custom-string');
        if (customStringTextarea) {
            customStringTextarea.addEventListener('input', function(event) {
                const inputString = event.target.value;
                displayCharacterAndWordCount(inputString);
            });
        }
    }
    
    /**
     * Show an option panel and hide others
     * @param {string} optionId - ID of the option to show
     */
    function showOption(optionId) {
        const options = document.querySelectorAll('#option-container > div');
        options.forEach(opt => opt.style.display = 'none');
        document.getElementById(optionId).style.display = 'block';
        document.getElementById('option-container').style.display = 'block';
    }
    
    /**
     * Generate combinations
     */
    function generateCombinations() {
        try {
            const n = BigInt(document.getElementById('combination-size').value);
            const outputFile = document.getElementById('output-file-generate').value || 'combinations.txt';
            
            if (isNaN(Number(n)) || n <= 0n) {
                throw new Error("Invalid combination size. Please enter a positive integer.");
            }
            
            // For large n values, show a warning
            if (n > 4n) {
                if (!confirm(`This will generate up to ${_uniqueCharset.length ** Number(n)} combinations. This could be a large file. Continue?`)) {
                    return;
                }
            }
            
            const resultDisplay = document.getElementById('map-result-display');
            resultDisplay.innerHTML = '<p>Generating combinations... This may take a while for large values.</p>';
            
            // Use setTimeout to allow UI to update before starting computation
            setTimeout(() => {
                try {
                    let combinationCount = 0;
                    let combinations = '';
                    const k = BigInt(_uniqueCharset.length);
                    const nbrComb = k ** n;
                    
                    // For large combinations, limit how many we generate
                    const maxToGenerate = 1000000n; // 1 million max
                    const actualGenerate = nbrComb > maxToGenerate ? maxToGenerate : nbrComb;
                    
                    // Generate combinations
                    for (let i = 0n; i < actualGenerate; i++) {
                        let id = i;
                        let combination = '';
                        for (let j = 0n; j < n; j++) {
                            combination = _uniqueCharset[Number(id % k)] + combination;
                            id = id / k;
                        }
                        combinations += combination + '\n';
                        combinationCount++;
                    }
                    
                    // Download the file
                    downloadFile(outputFile, combinations);
                    
                    // Update the result display
                    resultDisplay.innerHTML = `
                        <p>Successfully generated ${combinationCount.toLocaleString()} combinations.</p>
                        <p>Total possible combinations: ${nbrComb.toString()}.</p>
                        <p>File saved as: ${outputFile}</p>
                    `;
                } catch (error) {
                    resultDisplay.innerHTML = `<p class="error">Error during generation: ${error.message}</p>`;
                }
            }, 100);
        } catch (error) {
            alert(`Error: ${error.message}`);
        }
    }
    
    /**
     * Calculate a string ID
     */
    function calculateStringID() {
        try {
            const inputString = document.getElementById('custom-string').value;
            if (inputString.trim() === '') {
                throw new Error("Input string cannot be empty.");
            }
            
            let id = 0n;
            const resultDisplay = document.getElementById('map-result-display');
            resultDisplay.innerHTML = '<p>Calculating string ID...</p>';
            
            // Use setTimeout to allow UI to update before starting computation
            setTimeout(() => {
                try {
                    // Check all characters are in charset
                    const invalidChars = [];
                    for (const char of inputString) {
                        const charIndex = _uniqueCharset.indexOf(char);
                        if (charIndex === -1) {
                            invalidChars.push(char);
                        }
                    }
                    
                    if (invalidChars.length > 0) {
                        throw new Error(`Invalid characters found: ${invalidChars.join(' ')}`);
                    }
                    
                    // Calculate ID
                    for (const char of inputString) {
                        const charIndex = _uniqueCharset.indexOf(char);
                        id = id * BigInt(_uniqueCharset.length) + BigInt(charIndex);
                    }
                    
                    const result = id.toString() + "\t\n\n" + inputString;
                    document.getElementById('string-id-result').innerText = "The ID for the string is: " + id.toString();
                    
                    // Display character and word count
                    displayCharacterAndWordCount(inputString);
                    
                    // Decode ID to color indexes and update color bar
                    const colorIndexes = decodeIDtoColorIndexes(id.toString());
                    updateColorBar(colorIndexes);
                    
                    // Update result display
                    resultDisplay.innerHTML = `
                        <p>Calculation completed successfully.</p>
                        <p>String ID: ${id.toString()}</p>
                        <p>Character count: ${inputString.length}</p>
                        <p>Color indexes: ${colorIndexes.length}</p>
                        <p><button id="download-id-result">Download Result</button></p>
                    `;
                    
                    // Add event listener for download button
                    document.getElementById('download-id-result').addEventListener('click', () => {
                        const outputFile = `${colorIndexes.length}.txt`;
                        downloadFile(outputFile, result);
                    });
                } catch (error) {
                    resultDisplay.innerHTML = `<p class="error">Error calculating ID: ${error.message}</p>`;
                }
            }, 100);
        } catch (error) {
            alert(`Error: ${error.message}`);
        }
    }
    
    /**
     * Decode an ID to a string
     */
    function decodeID() {
        try {
            let id = BigInt(document.getElementById('string-id').value);
            if (id < 0n) {
                throw new Error("ID cannot be negative.");
            }
            
            const resultDisplay = document.getElementById('map-result-display');
            resultDisplay.innerHTML = '<p>Decoding ID to string...</p>';
            
            // Use setTimeout to allow UI to update before starting computation
            setTimeout(() => {
                try {
                    const decodedString = [];
                    const originalId = id;
                    
                    // If ID is too large, show warning
                    if (id > 10n ** 30n) {
                        resultDisplay.innerHTML += '<p class="warning">Warning: Very large ID. Decoding may be incomplete.</p>';
                    }
                    
                    // Decode ID to string
                    while (id > 0n) {
                        decodedString.push(_uniqueCharset[Number(id % BigInt(_uniqueCharset.length))]);
                        id = id / BigInt(_uniqueCharset.length);
                    }
                    
                    if (decodedString.length === 0) {
                        throw new Error("Decoded string is empty.");
                    }
                    
                    const decodedResult = decodedString.reverse().join('');
                    document.getElementById('decoded-string-result').innerText = "The decoded string is: " + decodedResult;
                    
                    // Update result display
                    resultDisplay.innerHTML = `
                        <p>Decoding completed successfully.</p>
                        <p>Original ID: ${originalId.toString()}</p>
                        <p>Decoded string length: ${decodedResult.length}</p>
                        <p>Decoded string:</p>
                        <pre>${decodedResult}</pre>
                    `;
                } catch (error) {
                    resultDisplay.innerHTML = `<p class="error">Error decoding ID: ${error.message}</p>`;
                }
            }, 100);
        } catch (error) {
            alert(`Error: ${error.message}`);
        }
    }
    
    /**
     * Find optimal variable
     */
    function findOptimalVariable() {
        try {
            const userNumber = BigInt(document.getElementById('user-number').value);
            const outputFile = document.getElementById('output-file-optimal').value || 'optimal_variables.txt';
            
            if (userNumber <= 0n) {
                throw new Error("User number must be positive.");
            }
            
            const resultDisplay = document.getElementById('map-result-display');
            resultDisplay.innerHTML = '<p>Finding optimal variables...</p>';
            
            // Use setTimeout to allow UI to update before starting computation
            setTimeout(() => {
                try {
                    const charsetLength = BigInt(_uniqueCharset.length);
                    const extendedCharsetLength = BigInt(_uniqueCharset.length);
                    const generator = optimalVariableGenerator(userNumber, charsetLength, extendedCharsetLength);
                    
                    const results = [];
                    for (let i = 0; i < 100; i++) {
                        const optVar = generator.next().value;
                        const decodedString = decodeIDFromNumber(optVar, _uniqueCharset);
                        results.push({
                            variable: optVar,
                            string: decodedString,
                            length: decodedString.length
                        });
                    }
                    
                    // Format the results for download
                    const resultString = results.map(r => `${r.variable}\t${r.string}`).join('\n');
                    
                    // Download the file
                    downloadFile(outputFile, resultString);
                    
                    // Display the results
                    let resultsHTML = '<p>Results (showing first 10):</p><table class="results-table">';
                    resultsHTML += '<tr><th>Variable</th><th>String</th><th>Length</th></tr>';
                    
                    results.slice(0, 10).forEach(r => {
                        resultsHTML += `<tr><td>${r.variable}</td><td>${r.string}</td><td>${r.length}</td></tr>`;
                    });
                    
                    resultsHTML += '</table>';
                    
                    // Update result display
                    resultDisplay.innerHTML = `
                        <p>Successfully found 100 optimal variables.</p>
                        <p>File saved as: ${outputFile}</p>
                        ${resultsHTML}
                    `;
                } catch (error) {
                    resultDisplay.innerHTML = `<p class="error">Error finding optimal variables: ${error.message}</p>`;
                }
            }, 100);
        } catch (error) {
            alert(`Error: ${error.message}`);
        }
    }
    
    /**
     * Generate an optimal variable
     * @param {BigInt} userNumber - The user number
     * @param {BigInt} charsetLength - The charset length
     * @param {BigInt} extendedCharsetLength - The extended charset length
     * @returns {Object} Iterator for generating optimal variables
     */
    function optimalVariableGenerator(userNumber, charsetLength, extendedCharsetLength) {
        let k = 1n;
        return {
            next: function() {
                while (true) {
                    const x = k * userNumber;
                    if (x % extendedCharsetLength < charsetLength) {
                        const result = { value: x, done: false };
                        k += 1n;
                        return result;
                    }
                    k += 1n;
                }
            }
        };
    }
    
    /**
     * Check if a number is a perfect square
     * @param {number} n - Number to check
     * @returns {boolean} Whether the number is a perfect square
     */
    function isPerfectSquare(n) {
        if (n <= 0) return false; // Grids must have a positive number of tiles
        const sqrt = Math.sqrt(n);
        return sqrt === Math.floor(sqrt);
    }
    
    /**
     * Validate color indexes
     * @param {Array<number>} indexes - Array of color indexes
     * @returns {boolean} Whether the indexes are valid
     */
    function areValidColorIndexes(indexes) {
        const maxColorIndex = Math.pow(16, 6); // Maximum valid color index is 16777216
        return indexes.every(index => index >= 1 && index <= maxColorIndex);
    }
    
    /**
     * Update the color bar based on color indexes
     * @param {Array<number>} indexes - Array of color indexes
     */
    function updateColorBar(indexes) {
        const colorBar = document.getElementById('color-bar');
        if (!colorBar) return;
        
        if (isPerfectSquare(indexes.length) && areValidColorIndexes(indexes)) {
            colorBar.style.backgroundColor = 'green'; // Valid grid
        } else {
            colorBar.style.backgroundColor = 'red'; // Invalid grid
        }
    }
    
    /**
     * Decode an ID to color indexes
     * @param {string} idString - The ID string
     * @returns {Array<number>} Array of color indexes
     */
    function decodeIDtoColorIndexes(idString) {
        const indexes = [];
        const segmentLength = 7; // Each color index is represented by a 7-digit segment
        
        // Split the integer string into 7-digit segments
        for (let i = 0; i < idString.length; i += segmentLength) {
            const segment = idString.slice(i, i + segmentLength);
            const index = parseInt(segment, 10);
            
            if (!isNaN(index)) {
                indexes.push(index);
            }
        }
        return indexes;
    }
    
    /**
     * Display character and word count
     * @param {string} inputText - The input text
     */
    function displayCharacterAndWordCount(inputText) {
        const characterCount = inputText.length;
        const wordCount = inputText.trim() === '' ? 0 : inputText.trim().split(/\s+/).length;
        
        const charWordCountElement = document.getElementById('character-word-count');
        if (charWordCountElement) {
            charWordCountElement.innerText = `Characters: ${characterCount}, Words: ${wordCount}`;
        }
    }
    
    /**
     * Decode an ID from a number
     * @param {BigInt} id - The ID to decode
     * @param {Array<string>} charset - The charset to use
     * @returns {string} The decoded string
     */
    function decodeIDFromNumber(id, charset) {
        const decodedString = [];
        while (id > 0n) {
            decodedString.push(charset[Number(id % BigInt(charset.length))]);
            id = id / BigInt(charset.length);
        }
        return decodedString.reverse().join('');
    }
    
    /**
     * Download a file
     * @param {string} filename - The filename
     * @param {string} content - The file content
     */
    function downloadFile(filename, content) {
        const blob = new Blob([content], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }
    
    /**
     * Get the charset configuration
     * @returns {Array} The charset configuration
     */
    function getCharsetConfig() {
        return [..._charsetConfig];
    }
    
    /**
     * Get the unique charset
     * @returns {Array<string>} The unique charset
     */
    function getUniqueCharset() {
        return [..._uniqueCharset];
    }
    
    /**
     * Calculate a string ID (functional version for API access)
     * @param {string} inputString - The input string
     * @returns {BigInt} The calculated ID
     */
    function calculateID(inputString) {
        if (!inputString || typeof inputString !== 'string') {
            throw new Error("Input must be a non-empty string");
        }
        
        let id = 0n;
        for (const char of inputString) {
            const charIndex = _uniqueCharset.indexOf(char);
            if (charIndex === -1) {
                throw new Error(`Character "${char}" is not in the charset`);
            }
            id = id * BigInt(_uniqueCharset.length) + BigInt(charIndex);
        }
        
        return id;
    }
    
    /**
     * Decode an ID to a string (functional version for API access)
     * @param {BigInt|string} id - The ID to decode
     * @returns {string} The decoded string
     */
    function decodeIDtoString(id) {
        try {
            id = BigInt(id);
        } catch (e) {
            throw new Error("Invalid ID format");
        }
        
        if (id < 0n) {
            throw new Error("ID cannot be negative");
        }
        
        const decodedString = [];
        while (id > 0n) {
            decodedString.push(_uniqueCharset[Number(id % BigInt(_uniqueCharset.length))]);
            id = id / BigInt(_uniqueCharset.length);
        }
        
        return decodedString.reverse().join('');
    }
    
    // Public API
    return {
        initialize,
        loadMapSystem,
        showMapSection,
        calculateID,
        decodeIDtoString,
        getCharsetConfig,
        getUniqueCharset,
        isPerfectSquare,
        areValidColorIndexes,
        updateColorBar,
        decodeIDtoColorIndexes,
        downloadFile
    };
})();

// Automatically initialize when the DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    // Look for the main container
    const mainElement = document.querySelector('main');
    if (mainElement) {
        OperatorFramework.Map.initialize({
            containerId: mainElement.id || 'main'
        });
        console.log('Map System initialized');
    } else {
        console.warn('Main element not found, Map System not automatically initialized');
    }
});