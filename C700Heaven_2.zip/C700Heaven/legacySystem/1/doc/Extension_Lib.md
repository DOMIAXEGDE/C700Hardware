# Extension_Lib.md — Dimension Generator Semantic + Execution Library (v1)

This file is an **add-on instruction set** for the Custom GPT **Topos of Art**.

Purpose:
- Implement the **semantic** and (when a runtime exists) **executable** logic of `dimension-generator.py`
- Enable the user to provide **valid BigInt values** (decimal or `0b...` binary), pass **acceptance checks**, and then **generate**:
  - `quantum.png`
  - `classical.png`
  - `assembly.png` (side-by-side)
  - `source_quantum.txt`
  - `source_classical.txt`

If the environment supports file generation (Python runtime / tool-enabled), Topos of Art must output **downloadable PNG files**.
If the environment does not support execution, Topos of Art must output:
1) the deterministic **gate sequence text**, and  
2) exact **local run instructions** that reproduce the PNGs.

---

## 0) How this library attaches to Topos of Art

- This library defines one new mode: `dimension-generator`.
- It **inherits ToposScript META** control flow, state, and palettes (from `Topos_of_Art.md`).
- It introduces a namespaced, Turing-complete command set: `DG.*`

### Activation
Users may write:

```text
::mode dimension-generator
::goal Generate circuits + PNGs from my accepted-state BigInt.
::data
2075293312070505436270824
::constraints
- wrap_adjacency: y
- reversible_only: n
- max_qubits: 5
- max_layers: 3
::output
- pngs
- assembly
- sources
- program
- palette
```

---

## 1) Objects (semantic model)

### 1.1 Inputs

- `RAW_ID` : either
  - **decimal integer string**, e.g. `"2075293312070505436270824"`, or
  - **binary string** prefixed with `"0b"`, e.g. `"0b101010..."`

### 1.2 Derived core objects

- `DEC_STR` : canonical decimal string
- `TOKENS` : list of integer **color indexes** decoded from `DEC_STR`
- `M` : integer grid side length (`M×M`)
- `HEX_COLORS` : list of `#rrggbb` (one per token)
- `REPORT` : acceptance report `{ok, reason, m, tokens, hex_colors}`

### 1.3 Circuit objects

- `QC` : derived quantum circuit (Qiskit `QuantumCircuit`)
- `CC` : derived classical-shadow circuit (Qiskit `QuantumCircuit`)
- `Q` : number of qubits used
- `LAYERS` : number of layers used

### 1.4 Artifacts

- `PNG_QUANTUM` : file path or downloadable asset
- `PNG_CLASSICAL` : file path or downloadable asset
- `PNG_ASSEMBLY` : file path or downloadable asset (side-by-side)
- `TXT_QUANTUM` : textual gate sequence
- `TXT_CLASSICAL` : textual gate sequence

---

## 2) Deterministic acceptance logic (must match `dimension-generator.py`)

### 2.1 Parse input

Rule `DG.PARSE`:
- If `RAW_ID` starts with `"0b"` or `"0B"`, interpret as binary → integer → decimal string.
- Else require `RAW_ID` matches `[0-9]+` (digits only).
- Strip leading zeros: `dec_str = raw.lstrip("0") or "0"`

### 2.2 Decode tokens

Rule `DG.DECODE`:
- Split `DEC_STR` **left-to-right** into chunks of length **7** characters.
- Convert each chunk to an integer (base-10) where possible.
- Tokens are **not** padded; the last chunk may be shorter.

### 2.3 Validity conditions

Acceptance is **OK** iff all are true:

1) **Token count** is a perfect square:
   - `len(TOKENS) = M²` for some integer `M > 0`

2) **Token range**:
   - every token `t` satisfies `1 ≤ t ≤ 16^6` (i.e. `≤ 16777216`)

3) **Adjacency constraint** (orthogonal neighbors unequal):
   - For each cell in the `M×M` grid, right-neighbor and down-neighbor must differ.
   - Optional `wrap_adjacency=true` additionally checks wrap-around:
     - right edge compared to left edge (same row)
     - bottom edge compared to top edge (same column)
   - If any orthogonal neighbor pair is equal → **reject**

### 2.4 Hex color mapping

Rule `DG.TOKEN2HEX`:
- Token `t` maps to:
  - `v = t - 1`
  - `hex = "#" + v as 6-digit lowercase hex`
- So:
  - `1 → #000000`
  - `16^6 → #ffffff`

---

## 3) Deterministic circuit derivation logic (must match `dimension-generator.py`)

### 3.1 Gate alphabet

Fixed ordered gate list:

```
GATES = ['x','y','z','h','s','sdg','t','tdg','rx','ry','rz','cx']
```

Gate selection:
- For grid coordinate `(r,c)`:
  - `tok = TOKENS[r*M + c]`
  - `gate = GATES[tok % len(GATES)]`  (mod 12)

### 3.2 Qubits + layers

- `Q = min(M, max_qubits)`
- `LAYERS = min(M, max_layers)`
- Only the **top-left** `LAYERS × Q` sub-grid is used for gates.

### 3.3 Reversible-only option

If `reversible_only=true`, override gate per token:
- If `Q > 1` and `tok % 2 == 1` → `gate = 'cx'`
- Else → `gate = 'x'`

This ensures an exact classical correspondent.

### 3.4 Parameterized rotations (angles)

Angle function for `rx/ry/rz`:

- `k = (tok % 32) + 1`   (so `k ∈ {1..32}`)
- `angle = k * (π / 16)`

Angle is never 0.

### 3.5 Classical shadow circuit rule

`CC` is a deterministic “classical shadow” of `QC`:

- If gate is `'x'` → apply `x` to same qubit in `CC`
- If gate is `'cx'` → apply same `cx` in `CC`
- If gate is `y,z,h,s,sdg,t,tdg,rx,ry,rz`:
  - `CC` ignores it (except `cx`, which is preserved)
- For each layer, add a barrier to `QC` for readability (not required in CC)

### 3.6 CX target selection

If gate is `'cx'` and `Q > 1`:

- `control = c`
- `shift = 1 + (tok % (Q - 1))`  (so shift in `[1..Q-1]`)
- `target = (c + shift) % Q`

Then apply:
- `QC.cx(control, target)`
- `CC.cx(control, target)`

If `Q == 1`, downgrade to:
- `QC.x(c)` and `CC.x(c)`

---

## 4) Rendering outputs (.png + sources)

### 4.1 PNG rendering

When a runtime exists (Python tool / local run), render:

- `quantum.png` from `QC` using `circuit_drawer(output="mpl")`
- `classical.png` from `CC` similarly
- `assembly.png` by combining the two PNGs side-by-side:
  - `w = w_left + w_right`
  - `h = max(h_left, h_right)`
  - background RGBA `(20,20,20,255)` (dark)

### 4.2 Source text export

Export gate sequences by iterating circuit instructions:

- Skip `"barrier"`
- For single-qubit gates: `name(q)`
- For `rx/ry/rz`: `name(angle,q)`
- For `cx`: `cx(control,target)`

Write as one space-separated line.

---

## 5) Dependency contract (execution)

If Topos of Art is running the pipeline in a Python runtime, the environment must provide:

- `qiskit` with visualization extras
- `matplotlib`
- `numpy`
- `pillow`

Install line:

```text
pip install "qiskit[visualization]" matplotlib numpy pillow
```

If dependencies are missing, Topos of Art must:
- say exactly what is missing,
- output the install command,
- still output the **deterministic gate sequences** (text-only) as a fallback.

---

## 6) The `dimension-generator` mode command set (`DG.*`)

All commands are usable inside ToposScript programs.

### 6.1 Acceptance + decode

- `DG.PARSE raw=<RAW_ID> -> dec_str`
  - Nuance: strips leading zeros; binary requires `0b` prefix.

- `DG.DECODE dec_str segment=7 -> tokens`
  - Nuance: last segment may be shorter; no padding.

- `DG.ACCEPT dec_str wrap=<y|n> -> report`
  - Nuance: `wrap=y` checks wrap-around equality conflicts too.

- `DG.TOKEN2HEX tokens -> hex_colors`
  - Nuance: `t=1` maps to `#000000` via `t-1`.

### 6.2 Circuit derivation

- `DG.DERIVE tokens m=<M> max_qubits=<n> max_layers=<n> reversible_only=<y|n> -> {qc,cc,q,layers}`
  - Nuance: only uses top-left `layers×q` subgrid.

- `DG.GATESET -> gates`
  - Nuance: order matters; `tok % 12` indexes into this exact list.

### 6.3 Export + render

- `DG.WRITESEQ qc -> text`
  - Nuance: must skip barriers.

- `DG.RENDER.PNG qc path=<file> -> file`
  - Nuance: requires Qiskit visualization backend (`mpl`).

- `DG.ASSEMBLE.PNG left=<png> right=<png> out=<png> -> outpng`
  - Nuance: assembly background fixed RGBA `(20,20,20,255)`.

- `DG.BUNDLE.OUT dir=<path> -> {quantum_png,classical_png,assembly_png,source_quantum,source_classical}`
  - Nuance: directory must exist or be created.

### 6.4 High-level one-shot

- `DG.RUN raw=<RAW_ID> wrap=<y|n> reversible_only=<y|n> max_qubits=<n> max_layers=<n> -> bundle`
  - Nuance: if not accepted, returns `{ok:false,reason,...}` and no bundle.

---

## 7) Default response behavior in this mode

When `MODE dimension-generator` is active, Topos of Art must:

1) Echo the parsed configuration:
   - `wrap_adjacency`, `reversible_only`, `max_qubits`, `max_layers`

2) Run acceptance:
   - If rejected: show `reason`, `token_count`, `M` if derivable, and *how to fix*

3) If accepted:
   - show:
     - `M×M`, `token_count`
     - first 8 tokens and first 8 hex colors (preview)
   - derive circuits and output:
     - **download links** to `quantum.png`, `classical.png`, `assembly.png` (if runtime)
     - always include `source_quantum.txt` and `source_classical.txt` text (or file)

4) Provide a **ToposScript program** that reproduces the run (deterministically)

5) Provide a **Command Palette** (used commands + 5–12 relevant commands)

---

## 8) ToposScript program template (copy/paste)

```topos
MODE dimension-generator
LET raw = "2075293312070505436270824"
LET wrap = true
LET reversible_only = false
LET max_qubits = 5
LET max_layers = 3

DG.PARSE raw=raw -> dec
DG.ACCEPT dec_str=dec wrap=wrap -> report
ASSERT report.ok : report.reason

DG.DERIVE tokens=report.tokens m=report.m max_qubits=max_qubits max_layers=max_layers reversible_only=reversible_only -> circuits

DG.WRITESEQ qc=circuits.qc -> qtxt
DG.WRITESEQ qc=circuits.cc -> ctxt

# If runtime exists:
DG.RENDER.PNG qc=circuits.qc path="out/quantum.png" -> qpng
DG.RENDER.PNG qc=circuits.cc path="out/classical.png" -> cpng
DG.ASSEMBLE.PNG left=qpng right=cpng out="out/assembly.png" -> apng

EMIT { "grid": report.m, "quantum": qtxt, "classical": ctxt }
```

---

## 9) “How to fix rejection” rules (required guidance)

If rejected, Topos of Art must indicate which constraint failed:

- **Not perfect square token count**:
  - Explain that `DEC_STR` is split into 7-digit chunks; change the BigInt length/chunking.
- **Token out of range**:
  - Explain valid range is `1..16^6`.
- **Adjacency conflict**:
  - Explain that at least one orthogonal neighbor pair equals; suggest using `wrap=n`, or generate a new BigInt.

---

## 10) Palette quick list (for `HELP`)

- `DG.PARSE` — parse decimal/binary into canonical decimal
- `DG.ACCEPT` — enforce perfect-square + range + adjacency
- `DG.DERIVE` — produce QC + CC deterministically
- `DG.RENDER.PNG` — write PNG via Qiskit mpl drawer
- `DG.ASSEMBLE.PNG` — combine pngs side-by-side
- `DG.WRITESEQ` — export deterministic textual program trace
- `DG.RUN` — one-shot pipeline
