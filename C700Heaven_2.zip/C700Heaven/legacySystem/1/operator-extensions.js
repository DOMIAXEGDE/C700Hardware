/**
 * Operator Extensions
 * Additional features for the Operator System
 * 
 * This file adds advanced features to the quadtree implementation:
 * - Custom cell colors
 * - Custom cell text
 * - Image insertion into cells (file upload and clipboard paste)
 * - Enhanced PNG export
 */

(function() {
    'use strict';

    // Track when the page is fully loaded
    document.addEventListener('DOMContentLoaded', function() {
        // Initialize extensions after a short delay to ensure main app is loaded
        setTimeout(initExtensions, 300);
    });

    /**
     * Initialize extension features
     */
    function initExtensions() {
        // Find tree operations section
        const treeSection = document.getElementById('tree-operations');
        if (!treeSection) {
            console.error('Tree operations section not found');
            return;
        }

        // Enhance the quadtree UI
        enhanceQuadtreeUI();
        
        // Create and add context menu
        createContextMenu();
        
        // Set up global clipboard paste handler
        setupClipboardPaste();
        
        // Override the export PNG functionality
        overrideExportPNG();
        
        console.log('Operator Extensions loaded successfully');
    }

    /**
     * Enhance the quadtree UI with additional controls
     */
    function enhanceQuadtreeUI() {
        const quadtreeContainer = document.getElementById('quadtree-container');
        if (!quadtreeContainer) {
            console.error('Quadtree container not found');
            return;
        }

        // Add right-click event listener to quadtree container
        quadtreeContainer.addEventListener('contextmenu', handleQuadtreeContextMenu);
        
        // Add custom styles
        addCustomStyles();
        
        // Add file input for images (hidden by default)
        const fileInput = document.createElement('input');
        fileInput.type = 'file';
        fileInput.id = 'quadtree-image-input';
        fileInput.accept = 'image/*';
        fileInput.style.display = 'none';
        document.body.appendChild(fileInput);
        
        fileInput.addEventListener('change', handleImageUpload);
    }

    /**
     * Add custom styles for the context menu
     */
    function addCustomStyles() {
        const styleElement = document.createElement('style');
        styleElement.textContent = `
            /* Context Menu Styles */
            .quadtree-context-menu {
                position: absolute;
                background-color: white;
                border: 1px solid var(--secondary-color);
                border-radius: 4px;
                box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
                padding: 8px 0;
                min-width: 180px;
                z-index: 1000;
                display: none;
            }
            
            .quadtree-context-menu.active {
                display: block;
            }
            
            .context-menu-item {
                padding: 8px 16px;
                cursor: pointer;
                transition: background-color 0.2s ease;
                display: flex;
                align-items: center;
            }
            
            .context-menu-item:hover {
                background-color: var(--background-color);
            }
            
            .context-menu-item-icon {
                margin-right: 10px;
                width: 16px;
                text-align: center;
            }
            
            .context-menu-separator {
                height: 1px;
                background-color: var(--secondary-color);
                margin: 6px 0;
                opacity: 0.3;
            }
            
            /* Color Picker */
            .color-picker-container {
                padding: 8px 16px;
            }
            
            /* Cell customizations */
            .quadtree-cell-custom-text {
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                max-width: 90%;
                font-family: var(--font-main);
                pointer-events: none;
            }
            
            .quadtree-cell-image {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                object-fit: cover;
                pointer-events: none;
            }
            
            /* Hide the original cell content when customized */
            .quadtree-cell.customized .cell-content {
                display: none;
            }
            
            /* Cell with focus for pasting */
            .quadtree-cell.paste-focus {
                outline: 2px dashed var(--primary-color);
                z-index: 10;
                position: relative;
            }
            
            /* Paste indicator */
            .paste-indicator {
                position: fixed;
                bottom: 20px;
                right: 20px;
                background-color: var(--background-color);
                border: 1px solid var(--secondary-color);
                border-left: 4px solid var(--primary-color);
                padding: 10px 15px;
                font-size: 0.9rem;
                box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
                border-radius: 4px;
                z-index: 1000;
                display: none;
            }
            
            .paste-indicator.active {
                display: block;
                animation: fadeIn 0.3s ease-in-out;
            }
            
            /* Export loading indicator */
            .export-loading {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.5);
                display: flex;
                justify-content: center;
                align-items: center;
                z-index: 2000;
            }
            
            .export-loading-content {
                background-color: white;
                padding: 20px;
                border-radius: 4px;
                text-align: center;
            }
            
            .export-spinner {
                border: 4px solid #f3f3f3;
                border-top: 4px solid var(--primary-color);
                border-radius: 50%;
                width: 40px;
                height: 40px;
                animation: spin 2s linear infinite;
                margin: 0 auto 15px auto;
            }
            
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
            
            @keyframes fadeIn {
                from { opacity: 0; transform: translateY(10px); }
                to { opacity: 1; transform: translateY(0); }
            }
            
            /* Custom cell modal */
            .quadtree-modal {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.5);
                display: flex;
                justify-content: center;
                align-items: center;
                z-index: 1100;
            }
            
            .quadtree-modal-content {
                background-color: white;
                padding: 20px;
                border-radius: 4px;
                max-width: 500px;
                width: 100%;
            }
            
            .quadtree-modal-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 20px;
            }
            
            .quadtree-modal-close {
                background: none;
                border: none;
                font-size: 1.5rem;
                cursor: pointer;
                padding: 0;
                color: var(--text-color);
            }
            
            .quadtree-modal-body {
                margin-bottom: 20px;
            }
            
            .quadtree-form-group {
                margin-bottom: 15px;
            }
            
            .quadtree-form-group label {
                display: block;
                margin-bottom: 5px;
                font-weight: bold;
            }
            
            .quadtree-form-group input,
            .quadtree-form-group textarea {
                width: 100%;
                padding: 8px;
                border: 1px solid var(--secondary-color);
                border-radius: 4px;
            }
            
            .quadtree-form-actions {
                display: flex;
                justify-content: flex-end;
                gap: 10px;
            }
        `;
        document.head.appendChild(styleElement);
    }

    /**
     * Create the context menu
     */
    function createContextMenu() {
        // Check if it already exists
        if (document.getElementById('quadtree-context-menu')) {
            return;
        }
        
        // Create context menu
        const contextMenu = document.createElement('div');
        contextMenu.id = 'quadtree-context-menu';
        contextMenu.className = 'quadtree-context-menu';
        
        // Menu items
        contextMenu.innerHTML = `
            <div class="context-menu-item" data-action="change-color">
                <span class="context-menu-item-icon">🎨</span>
                <span>Change Color...</span>
            </div>
            <div class="context-menu-item" data-action="add-text">
                <span class="context-menu-item-icon">T</span>
                <span>Add Text...</span>
            </div>
            <div class="context-menu-item" data-action="add-image">
                <span class="context-menu-item-icon">🖼️</span>
                <span>Add Image...</span>
            </div>
            <div class="context-menu-item" data-action="paste-image">
                <span class="context-menu-item-icon">📋</span>
                <span>Paste From Clipboard</span>
            </div>
            <div class="context-menu-separator"></div>
            <div class="context-menu-item" data-action="reset-cell">
                <span class="context-menu-item-icon">↩️</span>
                <span>Reset Cell</span>
            </div>
        `;
        
        // Add context menu to document
        document.body.appendChild(contextMenu);
        
        // Add click listeners to menu items
        contextMenu.querySelectorAll('.context-menu-item').forEach(item => {
            item.addEventListener('click', handleContextMenuAction);
        });
        
        // Click outside to close
        document.addEventListener('click', function(e) {
            if (!contextMenu.contains(e.target)) {
                contextMenu.classList.remove('active');
            }
        });
        
        // Create paste indicator
        const pasteIndicator = document.createElement('div');
        pasteIndicator.id = 'paste-indicator';
        pasteIndicator.className = 'paste-indicator';
        pasteIndicator.textContent = 'Press Ctrl+V to paste image';
        document.body.appendChild(pasteIndicator);
    }

    /**
     * Handle right-click on quadtree cells
     */
    function handleQuadtreeContextMenu(event) {
        // Prevent default context menu
        event.preventDefault();
        
        // Find if click was on a cell
        const cell = event.target.closest('.quadtree-cell');
        if (!cell) return;
        
        // Store reference to target cell
        window.activeQuadtreeCell = cell;
        
        // Position and show the context menu
        const contextMenu = document.getElementById('quadtree-context-menu');
        contextMenu.style.left = `${event.clientX}px`;
        contextMenu.style.top = `${event.clientY}px`;
        contextMenu.classList.add('active');
    }

    /**
     * Handle context menu actions
     */
    function handleContextMenuAction(event) {
        const action = event.currentTarget.getAttribute('data-action');
        const cell = window.activeQuadtreeCell;
        
        // Hide context menu
        document.getElementById('quadtree-context-menu').classList.remove('active');
        
        if (!cell) return;
        
        // Execute action
        switch (action) {
            case 'change-color':
                showColorPickerModal(cell);
                break;
                
            case 'add-text':
                showTextModal(cell);
                break;
                
            case 'add-image':
                const fileInput = document.getElementById('quadtree-image-input');
                fileInput.click();
                break;
                
            case 'paste-image':
                prepareCellForPaste(cell);
                break;
                
            case 'reset-cell':
                resetCell(cell);
                break;
        }
    }

    /**
     * Mark cell as customized to hide original content
     */
    function markCellAsCustomized(cell) {
        cell.classList.add('customized');
    }

    /**
     * Show color picker modal
     */
    function showColorPickerModal(cell) {
        // Create modal
        const modal = document.createElement('div');
        modal.className = 'quadtree-modal';
        
        // Modal content
        modal.innerHTML = `
            <div class="quadtree-modal-content">
                <div class="quadtree-modal-header">
                    <h3>Change Cell Color</h3>
                    <button class="quadtree-modal-close">&times;</button>
                </div>
                <div class="quadtree-modal-body">
                    <div class="quadtree-form-group">
                        <label for="cell-color">Select Color:</label>
                        <input type="color" id="cell-color" value="${getComputedStyle(cell).backgroundColor || '#f0f0f0'}">
                    </div>
                    <div class="quadtree-form-group">
                        <label for="cell-opacity">Opacity:</label>
                        <input type="range" id="cell-opacity" min="0" max="100" value="100">
                    </div>
                </div>
                <div class="quadtree-form-actions">
                    <button class="button button-secondary modal-cancel">Cancel</button>
                    <button class="button modal-apply">Apply</button>
                </div>
            </div>
        `;
        
        // Add modal to document
        document.body.appendChild(modal);
        
        // Handle close button
        modal.querySelector('.quadtree-modal-close').addEventListener('click', () => {
            document.body.removeChild(modal);
        });
        
        // Handle cancel button
        modal.querySelector('.modal-cancel').addEventListener('click', () => {
            document.body.removeChild(modal);
        });
        
        // Handle apply button
        modal.querySelector('.modal-apply').addEventListener('click', () => {
            const color = document.getElementById('cell-color').value;
            const opacity = document.getElementById('cell-opacity').value;
            
            // Apply color to cell
            cell.style.backgroundColor = color;
            cell.style.opacity = opacity / 100;
            
            // Mark cell as customized
            markCellAsCustomized(cell);
            
            // Close modal
            document.body.removeChild(modal);
        });
    }

    /**
     * Show text input modal
     */
    function showTextModal(cell) {
        // Find existing text element
        let existingText = '';
        const textElement = cell.querySelector('.quadtree-cell-custom-text');
        if (textElement) {
            existingText = textElement.textContent;
        }
        
        // Create modal
        const modal = document.createElement('div');
        modal.className = 'quadtree-modal';
        
        // Modal content
        modal.innerHTML = `
            <div class="quadtree-modal-content">
                <div class="quadtree-modal-header">
                    <h3>Add Text to Cell</h3>
                    <button class="quadtree-modal-close">&times;</button>
                </div>
                <div class="quadtree-modal-body">
                    <div class="quadtree-form-group">
                        <label for="cell-text">Text:</label>
                        <input type="text" id="cell-text" value="${existingText}">
                    </div>
                    <div class="quadtree-form-group">
                        <label for="text-color">Text Color:</label>
                        <input type="color" id="text-color" value="#000000">
                    </div>
                    <div class="quadtree-form-group">
                        <label for="text-size">Text Size:</label>
                        <input type="range" id="text-size" min="10" max="32" value="14">
                        <span id="text-size-value">14px</span>
                    </div>
                </div>
                <div class="quadtree-form-actions">
                    <button class="button button-secondary modal-cancel">Cancel</button>
                    <button class="button modal-apply">Apply</button>
                </div>
            </div>
        `;
        
        // Add modal to document
        document.body.appendChild(modal);
        
        // Update size value display
        const sizeInput = document.getElementById('text-size');
        const sizeValue = document.getElementById('text-size-value');
        sizeInput.addEventListener('input', () => {
            sizeValue.textContent = `${sizeInput.value}px`;
        });
        
        // Handle close button
        modal.querySelector('.quadtree-modal-close').addEventListener('click', () => {
            document.body.removeChild(modal);
        });
        
        // Handle cancel button
        modal.querySelector('.modal-cancel').addEventListener('click', () => {
            document.body.removeChild(modal);
        });
        
        // Handle apply button
        modal.querySelector('.modal-apply').addEventListener('click', () => {
            const text = document.getElementById('cell-text').value;
            const color = document.getElementById('text-color').value;
            const size = document.getElementById('text-size').value;
            
            // Remove any existing text element
            if (textElement) {
                cell.removeChild(textElement);
            }
            
            // If text is not empty, add it to the cell
            if (text.trim() !== '') {
                const newTextElement = document.createElement('div');
                newTextElement.className = 'quadtree-cell-custom-text';
                newTextElement.textContent = text;
                newTextElement.style.color = color;
                newTextElement.style.fontSize = `${size}px`;
                
                cell.appendChild(newTextElement);
                
                // Mark cell as customized
                markCellAsCustomized(cell);
            }
            
            // Close modal
            document.body.removeChild(modal);
        });
    }

    /**
     * Handle image upload
     */
    function handleImageUpload(event) {
        const cell = window.activeQuadtreeCell;
        if (!cell) return;
        
        const file = event.target.files[0];
        if (!file) return;
        
        // Check if file is an image
        if (!file.type.startsWith('image/')) {
            alert('Please select an image file');
            return;
        }
        
        // Read file as data URL
        const reader = new FileReader();
        reader.onload = function(e) {
            addImageToCell(cell, e.target.result);
        };
        
        reader.readAsDataURL(file);
        
        // Reset file input
        event.target.value = '';
    }

    /**
     * Add an image to a cell
     */
    function addImageToCell(cell, imageDataUrl) {
        // Remove any existing image
        const existingImage = cell.querySelector('.quadtree-cell-image');
        if (existingImage) {
            cell.removeChild(existingImage);
        }
        
        // Create image element
        const img = document.createElement('img');
        img.className = 'quadtree-cell-image';
        img.src = imageDataUrl;
        
        // Add image to cell
        cell.appendChild(img);
        
        // Mark cell as customized
        markCellAsCustomized(cell);
    }

    /**
     * Reset cell to default state
     */
    function resetCell(cell) {
        // Remove custom text
        const textElement = cell.querySelector('.quadtree-cell-custom-text');
        if (textElement) {
            cell.removeChild(textElement);
        }
        
        // Remove image
        const imageElement = cell.querySelector('.quadtree-cell-image');
        if (imageElement) {
            cell.removeChild(imageElement);
        }
        
        // Reset styles
        cell.style.backgroundColor = '';
        cell.style.opacity = '';
        
        // Remove customized class to show original content
        cell.classList.remove('customized');
        
        // Remove paste focus if present
        cell.classList.remove('paste-focus');
        
        // Trigger a redraw of the cell
        setTimeout(() => {
            const event = new Event('cellreset');
            cell.dispatchEvent(event);
        }, 0);
    }

    /**
     * Prepare a cell for clipboard paste
     */
    function prepareCellForPaste(cell) {
        // Remove focus from any previously focused cell
        const focusedCell = document.querySelector('.quadtree-cell.paste-focus');
        if (focusedCell) {
            focusedCell.classList.remove('paste-focus');
        }
        
        // Add focus to this cell
        cell.classList.add('paste-focus');
        
        // Show the paste indicator
        const pasteIndicator = document.getElementById('paste-indicator');
        pasteIndicator.classList.add('active');
        
        // Auto hide the paste indicator after 3 seconds
        setTimeout(() => {
            pasteIndicator.classList.remove('active');
        }, 3000);
    }

    /**
     * Setup clipboard paste functionality
     */
    function setupClipboardPaste() {
        // Listen for paste events on the document
        document.addEventListener('paste', function(event) {
            // Find the focused cell for paste
            const cell = document.querySelector('.quadtree-cell.paste-focus');
            if (!cell) return;
            
            // Get clipboard items
            const items = (event.clipboardData || event.originalEvent.clipboardData).items;
            
            // Look for image content
            for (const item of items) {
                if (item.type.indexOf('image') === 0) {
                    // Get image from clipboard
                    const blob = item.getAsFile();
                    const reader = new FileReader();
                    
                    reader.onload = function(e) {
                        // Add the image to the cell
                        addImageToCell(cell, e.target.result);
                        
                        // Remove the paste focus
                        cell.classList.remove('paste-focus');
                        
                        // Hide the paste indicator
                        document.getElementById('paste-indicator').classList.remove('active');
                    };
                    
                    reader.readAsDataURL(blob);
                    
                    // Prevent default paste behavior
                    event.preventDefault();
                    return;
                }
            }
            
            // If we get here, no image was found in clipboard
            console.log('No image found in clipboard');
        });
    }

    /**
     * Override the export PNG functionality to include custom elements
     */
    function overrideExportPNG() {
        // Find the export button
        const exportButton = document.getElementById('export-quadtree');
        if (!exportButton) {
            console.error('Export button not found');
            return;
        }
        
        // Store the original click handler
        const originalHandler = exportButton.onclick;
        
        // Override with our enhanced version
        exportButton.onclick = function(event) {
            // Prevent the default action
            event.preventDefault();
            
            // Call our enhanced export function
            exportQuadtreeAsPNG();
        };
    }
    
    /**
     * Export the quadtree as a PNG with all custom elements
     */
    function exportQuadtreeAsPNG() {
        // Show loading indicator
        showLoadingIndicator('Generating PNG...');
        
        // Get the quadtree container
        const quadtreeContainer = document.getElementById('quadtree-container');
        if (!quadtreeContainer) {
            hideLoadingIndicator();
            alert('Quadtree container not found');
            return;
        }
        
        // Use html2canvas to capture the DOM elements (including custom elements)
        // If html2canvas is not available, we'll use a fallback method
        if (typeof html2canvas === 'function') {
            html2canvas(quadtreeContainer, {
                scale: 2, // Higher quality
                backgroundColor: null,
                logging: false,
                useCORS: true, // For images from different origins
                allowTaint: true // Allow cross-origin images
            }).then(canvas => {
                // Convert canvas to PNG and download
                finishExport(canvas);
            }).catch(error => {
                console.error('Error capturing quadtree:', error);
                hideLoadingIndicator();
                alert('Failed to export quadtree: ' + error.message);
                
                // Try fallback method
                exportQuadtreeWithDOM2Canvas();
            });
        } else {
            // Fallback method
            exportQuadtreeWithDOM2Canvas();
        }
    }
    
    /**
     * Fallback method to export quadtree using DOM-to-Canvas drawing
     */
    function exportQuadtreeWithDOM2Canvas() {
        // Get the quadtree container
        const quadtreeContainer = document.getElementById('quadtree-container');
        if (!quadtreeContainer) {
            hideLoadingIndicator();
            alert('Quadtree container not found');
            return;
        }
        
        // Create a canvas
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        
        // Set canvas size to match container
        const width = quadtreeContainer.offsetWidth;
        const height = quadtreeContainer.offsetHeight;
        canvas.width = width * 2; // Higher quality
        canvas.height = height * 2;
        context.scale(2, 2);
        
        // Fill background
        context.fillStyle = 'white';
        context.fillRect(0, 0, width, height);
        
        // Draw each cell
        const cells = quadtreeContainer.querySelectorAll('.quadtree-cell');
        
        // First, render the cells and their backgrounds
        cells.forEach(cell => {
            // Only draw visible cells
            if (cell.style.display !== 'none') {
                // Get cell position and dimensions
                const rect = cell.getBoundingClientRect();
                const containerRect = quadtreeContainer.getBoundingClientRect();
                
                // Calculate position relative to container
                const x = rect.left - containerRect.left;
                const y = rect.top - containerRect.top;
                const cellWidth = rect.width;
                const cellHeight = rect.height;
                
                // Draw cell background
                context.fillStyle = getComputedStyle(cell).backgroundColor || '#f0f0f0';
                context.globalAlpha = parseFloat(getComputedStyle(cell).opacity) || 1;
                context.fillRect(x, y, cellWidth, cellHeight);
                
                // Draw cell border
                context.strokeStyle = getComputedStyle(cell).borderColor || '#ccc';
                context.lineWidth = parseFloat(getComputedStyle(cell).borderWidth) || 1;
                context.globalAlpha = 1;
                context.strokeRect(x, y, cellWidth, cellHeight);
            }
        });
        
        // Then, render the content (for proper z-order)
        cells.forEach(cell => {
            // Only draw visible cells
            if (cell.style.display !== 'none') {
                // Get cell position and dimensions
                const rect = cell.getBoundingClientRect();
                const containerRect = quadtreeContainer.getBoundingClientRect();
                
                // Calculate position relative to container
                const x = rect.left - containerRect.left;
                const y = rect.top - containerRect.top;
                const cellWidth = rect.width;
                const cellHeight = rect.height;
                
                // Draw original cell content if not customized
                if (!cell.classList.contains('customized')) {
                    const contentElement = cell.querySelector('.cell-content');
                    if (contentElement) {
                        context.fillStyle = getComputedStyle(contentElement).color || '#333';
                        context.font = getComputedStyle(contentElement).font || '12px sans-serif';
                        context.textAlign = 'center';
                        context.textBaseline = 'middle';
                        context.globalAlpha = 1;
                        context.fillText(
                            contentElement.textContent,
                            x + cellWidth / 2,
                            y + cellHeight / 2
                        );
                    }
                }
                
                // Draw custom text if present
                const textElement = cell.querySelector('.quadtree-cell-custom-text');
                if (textElement) {
                    context.fillStyle = getComputedStyle(textElement).color || '#000';
                    context.font = getComputedStyle(textElement).font || '14px sans-serif';
                    context.textAlign = 'center';
                    context.textBaseline = 'middle';
                    context.globalAlpha = 1;
                    context.fillText(
                        textElement.textContent,
                        x + cellWidth / 2,
                        y + cellHeight / 2
                    );
                }
                
                // Draw image if present (this requires handling async loading)
                const imageElement = cell.querySelector('.quadtree-cell-image');
                if (imageElement) {
                    try {
                        context.globalAlpha = 1;
                        context.drawImage(imageElement, x, y, cellWidth, cellHeight);
                    } catch (error) {
                        console.error('Error drawing image:', error);
                    }
                }
            }
        });
        
        // Convert canvas to PNG and download
        finishExport(canvas);
    }
    
    /**
     * Finish the export process by downloading the canvas as PNG
     */
    function finishExport(canvas) {
        try {
            // Convert canvas to data URL
            const dataUrl = canvas.toDataURL('image/png');
            
            // Create download link
            const link = document.createElement('a');
            link.download = 'quadtree.png';
            link.href = dataUrl;
            link.click();
            
            // Hide loading indicator
            hideLoadingIndicator();
        } catch (error) {
            console.error('Error generating PNG:', error);
            hideLoadingIndicator();
            alert('Failed to generate PNG: ' + error.message);
        }
    }
    
    /**
     * Show a loading indicator
     */
    function showLoadingIndicator(message) {
        // Create loading indicator if it doesn't exist
        let loadingEl = document.getElementById('export-loading');
        if (!loadingEl) {
            loadingEl = document.createElement('div');
            loadingEl.id = 'export-loading';
            loadingEl.className = 'export-loading';
            
            loadingEl.innerHTML = `
                <div class="export-loading-content">
                    <div class="export-spinner"></div>
                    <div id="export-loading-message">${message || 'Loading...'}</div>
                </div>
            `;
            
            document.body.appendChild(loadingEl);
        } else {
            // Update message if it exists
            const messageEl = document.getElementById('export-loading-message');
            if (messageEl) {
                messageEl.textContent = message || 'Loading...';
            }
            
            // Show the existing element
            loadingEl.style.display = 'flex';
        }
    }
    
    /**
     * Hide the loading indicator
     */
    function hideLoadingIndicator() {
        const loadingEl = document.getElementById('export-loading');
        if (loadingEl) {
            loadingEl.style.display = 'none';
        }
    }

    /**
     * Load html2canvas library dynamically if needed
     */
    function loadHtml2Canvas() {
        if (typeof html2canvas === 'undefined') {
            return new Promise((resolve, reject) => {
                const script = document.createElement('script');
                script.src = 'https://html2canvas.hertzen.com/dist/html2canvas.min.js';
                script.onload = resolve;
                script.onerror = reject;
                document.head.appendChild(script);
            });
        }
        
        return Promise.resolve();
    }
    
    // Initialize html2canvas if not present
    loadHtml2Canvas().catch(error => {
        console.warn('Failed to load html2canvas library:', error);
    });
})();