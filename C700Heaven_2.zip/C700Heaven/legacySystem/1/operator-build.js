/**
 * operator-build.js
 * 
 * This module implements the Build System (Memory Slot Manager & Logic Framework) 
 * for the Operator framework, providing memory management and logical operations.
 * It integrates with the operator-dropdown.js system.
 * 
 * @module OperatorBuild
 * @version 1.0.0
 * @depends OperatorFramework.Dropdown
 */

// Access the shared namespace for Operator framework

/**
 * Build System for memory management and logical operations
 * @namespace OperatorBuild
 */
OperatorFramework.Build = (function() {
    'use strict';

    // Private module variables
    let _initialized = false;
    let _section = null;
    let _memoryManager = null;
    let _logicEngine = null;
    let _iframe = null;
    let _defaultOptions = {
        containerId: 'main', // ID of the container to add the build section to
        sectionId: 'build-system-section', // ID for the created section element
        iframeId: 'build-system-iframe', // ID for the iframe element
        iframeHeight: '800px' // Default height for the iframe
    };
    let _options = {};
    let _loadCallbacks = [];
    
    /**
     * Initialize the Build System
     * @param {Object} options - Configuration options
     * @param {string} [options.containerId='main'] - ID of the container to add the build section to
     * @param {string} [options.sectionId='build-system-section'] - ID for the created section element
     * @param {string} [options.iframeId='build-system-iframe'] - ID for the iframe element
     * @param {string} [options.iframeHeight='800px'] - Height for the iframe
     * @returns {boolean} Success status
     */
    function initialize(options = {}) {
        if (_initialized) {
            console.warn('OperatorBuild is already initialized');
            return false;
        }
        
        // Merge options with defaults
        _options = { ..._defaultOptions, ...options };
        
        console.log('OperatorBuild initialized with default options');
        _initialized = true;
        
        // Register with dropdown system if available
        if (OperatorFramework.Dropdown) {
            OperatorFramework.Dropdown.addSystem({
                id: 'build',
                name: 'Memory Slot Manager & Logic Framework',
                description: 'Manage memory slots and perform logical operations',
                loadFunction: loadBuildSystem
            });
            console.log('Build System registered with OperatorFramework.Dropdown');
        } else {
            console.warn('OperatorFramework.Dropdown not available, Build System not registered');
        }
        
        return true;
    }
    
    /**
     * Load the Build System UI and functionality
     * @returns {boolean} Success status
     */
    function loadBuildSystem() {
        if (!_initialized) {
            console.error('OperatorBuild not initialized, call initialize() first');
            return false;
        }
        
        // Check if already loaded
        if (_section && document.getElementById(_options.sectionId)) {
            showBuildSection();
            return true;
        }
        
        // Get container
        //const container = document.getElementById(_options.containerId);
        // Use:
		const container = document.querySelector('main');
		if (!container) {
            console.error(`Container with ID "${_options.containerId}" not found`);
            return false;
        }
        
        // Create Build System section
        _section = document.createElement('section');
        _section.id = _options.sectionId;
        _section.className = 'operation-section';
        
        // Create header
        const header = document.createElement('h2');
        header.textContent = 'Memory Slot Manager & Logic Framework';
        _section.appendChild(header);
        
        // Create container div
        const operationContainer = document.createElement('div');
        operationContainer.className = 'operation-container';
        _section.appendChild(operationContainer);
        
        // Create loading indicator
        const loadingIndicator = document.createElement('div');
        loadingIndicator.id = 'build-loading-indicator';
        loadingIndicator.style.textAlign = 'center';
        loadingIndicator.style.padding = '20px';
        loadingIndicator.innerHTML = `
            <div style="margin-bottom: 15px;">Loading Memory Slot Manager & Logic Framework...</div>
            <div class="spinner" style="
                border: 4px solid rgba(0, 0, 0, 0.1);
                border-left-color: #4B5320;
                border-radius: 50%;
                width: 30px;
                height: 30px;
                animation: spin 1s linear infinite;
                margin: 0 auto;
            "></div>
            <style>
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
            </style>
        `;
        operationContainer.appendChild(loadingIndicator);
        
        // Create iframe (initially hidden)
        _iframe = document.createElement('iframe');
        _iframe.id = _options.iframeId;
        _iframe.style.width = '100%';
        _iframe.style.height = _options.iframeHeight;
        _iframe.style.border = 'none';
        _iframe.style.display = 'none';
        operationContainer.appendChild(_iframe);
        
        // Add to container
        container.appendChild(_section);
        
        // Show the section
        showBuildSection();
        
        // Create the iframe content
        createBuildSystemIframe();
        
        console.log('Build System loaded successfully');
        return true;
    }
    
    /**
     * Show the Build System section and hide other sections
     */
    function showBuildSection() {
        if (!_section) return;
        
        // Hide all sections
        const allSections = document.querySelectorAll('.operation-section');
        allSections.forEach(section => {
            section.classList.remove('active');
        });
        
        // Show Build section
        _section.classList.add('active');
    }
    
    /**
     * Create and populate the Build System iframe
     */
    function createBuildSystemIframe() {
        if (!_iframe) return;
        
        // Generate iframe content
        const iframeContent = generateIframeHTML();
        
        // Set up iframe load event
        _iframe.onload = function() {
            // Hide loading indicator
            const loadingIndicator = document.getElementById('build-loading-indicator');
            if (loadingIndicator) {
                loadingIndicator.style.display = 'none';
            }
            
            // Show iframe
            _iframe.style.display = 'block';
            
            // Access iframe contents
            const iframeWindow = _iframe.contentWindow;
            const iframeDocument = _iframe.contentDocument || iframeWindow.document;
            
            // Expose parent functions to iframe
            iframeWindow.parentAPI = createParentAPI();
            
            // Add event listeners for iframe-to-parent communication
            setupIframeCommunication(iframeWindow);
            
            // Store references to memory manager and logic engine
            if (iframeWindow.memoryManager) {
                _memoryManager = iframeWindow.memoryManager;
            }
            
            if (iframeWindow.logicEngine) {
                _logicEngine = iframeWindow.logicEngine;
            }
            
            // Execute any queued load callbacks
            for (const callback of _loadCallbacks) {
                try {
                    callback(_memoryManager, _logicEngine, iframeWindow);
                } catch (error) {
                    console.error('Error executing load callback:', error);
                }
            }
            
            // Clear load callbacks
            _loadCallbacks = [];
            
            console.log('Build System iframe loaded and initialized');
        };
        
        // Load content into iframe
        _iframe.srcdoc = iframeContent;
    }
    
    /**
     * Create API object for parent-to-iframe communication
     * @returns {Object} API object
     */
    function createParentAPI() {
        return {
            executeCommand: function(command) {
                return executeCommand(command);
            },
            notifyParent: function(message, type) {
                console.log(`Message from iframe: ${message}`, type);
            },
            getParentData: function() {
                return {
                    timestamp: new Date().toISOString(),
                    origin: window.location.origin,
                    framework: 'OperatorFramework',
                    version: '1.0.0'
                };
            }
        };
    }
    
    /**
     * Set up communication between parent and iframe
     * @param {Window} iframeWindow - The iframe window object
     */
    function setupIframeCommunication(iframeWindow) {
        // Listen for messages from iframe
        window.addEventListener('message', function(event) {
            // Verify origin
            if (event.source !== iframeWindow) return;
            
            const { action, data } = event.data || {};
            
            if (!action) return;
            
            switch (action) {
                case 'execute-command':
                    if (data && data.command) {
                        const result = executeCommand(data.command);
                        // Send result back to iframe
                        iframeWindow.postMessage({
                            action: 'command-result',
                            data: { result }
                        }, '*');
                    }
                    break;
                    
                case 'notify-parent':
                    if (data && data.message) {
                        console.log(`Notification from iframe: ${data.message}`, data.type);
                    }
                    break;
                    
                case 'request-data':
                    // Send data to iframe
                    iframeWindow.postMessage({
                        action: 'parent-data',
                        data: {
                            timestamp: new Date().toISOString(),
                            origin: window.location.origin,
                            framework: 'OperatorFramework',
                            version: '1.0.0'
                        }
                    }, '*');
                    break;
            }
        });
    }
    
    /**
     * Execute a command in the iframe
     * @param {string} command - Command to execute
     * @returns {Promise<any>} Command result
     */
    function executeCommand(command) {
        return new Promise((resolve, reject) => {
            if (!_iframe || !_iframe.contentWindow) {
                reject(new Error('Iframe not available'));
                return;
            }
            
            try {
                // Process the command
                const iframeWindow = _iframe.contentWindow;
                
                if (iframeWindow.submitCommand) {
                    // For terminal commands
                    iframeWindow.submitCommand(command);
                    resolve(true);
                } else if (iframeWindow.eval) {
                    // Direct evaluation (less secure but more flexible)
                    const result = iframeWindow.eval(command);
                    resolve(result);
                } else {
                    reject(new Error('No command execution method available in iframe'));
                }
            } catch (error) {
                reject(error);
            }
        });
    }
    
    /**
     * Register a callback to be executed when the iframe is loaded
     * @param {Function} callback - Callback function(memoryManager, logicEngine, iframeWindow)
     */
    function onLoad(callback) {
        if (typeof callback !== 'function') {
            console.error('onLoad requires a function parameter');
            return;
        }
        
        if (_memoryManager && _logicEngine && _iframe && _iframe.contentWindow) {
            // If already loaded, execute immediately
            try {
                callback(_memoryManager, _logicEngine, _iframe.contentWindow);
            } catch (error) {
                console.error('Error executing load callback:', error);
            }
        } else {
            // Otherwise, queue for later execution
            _loadCallbacks.push(callback);
        }
    }
    
    /**
     * Generate the HTML content for the iframe
     * @returns {string} HTML content
     */
    function generateIframeHTML() {
        return `<!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Memory Slot Manager & Logic Framework</title>
            <style>
                :root {
                    --primary-color: #0078d7;
                    --secondary-color: #4a4a4a;
                    --background-color: #f9f9f9;
                    --terminal-bg: #1e1e1e;
                    --terminal-text: #f0f0f0;
                    --border-color: #dbdbdb;
                    --highlight-color: #e6f2ff;
                }
                
                * {
                    box-sizing: border-box;
                    margin: 0;
                    padding: 0;
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                }
                
                body {
                    background-color: var(--background-color);
                    line-height: 1.6;
                    color: var(--secondary-color);
                    padding: 20px;
                    max-width: 1200px;
                    margin: 0 auto;
                }
                
                header {
                    text-align: center;
                    margin-bottom: 30px;
                    padding: 20px;
                    background-color: white;
                    border-radius: 5px;
                    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
                }
                
                h1 {
                    color: var(--primary-color);
                    margin-bottom: 10px;
                }
                
                .system-info {
                    font-size: 0.9em;
                    color: var(--secondary-color);
                }
                
                .main-container {
                    display: flex;
                    flex-direction: column;
                    gap: 20px;
                }
                
                @media (min-width: 992px) {
                    .main-container {
                        flex-direction: row;
                    }
                    
                    .terminal-section {
                        flex: 1;
                    }
                    
                    .results-section {
                        flex: 1;
                    }
                }
                
                .section {
                    background-color: white;
                    border-radius: 5px;
                    padding: 20px;
                    box-shadow: 0 2px 5px rgba(0,0,0,0.1);
                }
                
                .section-title {
                    font-size: 1.2em;
                    margin-bottom: 15px;
                    padding-bottom: 10px;
                    border-bottom: 1px solid var(--border-color);
                    color: var(--primary-color);
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                }
                
                .section-title-actions {
                    display: flex;
                    gap: 10px;
                }
                
                .action-button {
                    padding: 3px 8px;
                    font-size: 0.8em;
                    background-color: var(--primary-color);
                    color: white;
                    border: none;
                    border-radius: 3px;
                    cursor: pointer;
                }
                
                .action-button:hover {
                    background-color: #005a9e;
                }
                
                .terminal {
                    background-color: var(--terminal-bg);
                    color: var(--terminal-text);
                    padding: 15px;
                    border-radius: 5px;
                    font-family: 'Consolas', 'Courier New', monospace;
                    height: 350px;
                    overflow-y: auto;
                    margin-bottom: 15px;
                }
                
                .terminal-input {
                    display: flex;
                    margin-bottom: 10px;
                }
                
                .terminal-input span {
                    margin-right: 10px;
                    color: #4caf50;
                }
                
                #commandInput {
                    width: 100%;
                    padding: 10px;
                    font-family: 'Consolas', 'Courier New', monospace;
                    margin-bottom: 10px;
                    border: 1px solid var(--border-color);
                    border-radius: 5px;
                }
                
                .button {
                    background-color: var(--primary-color);
                    color: white;
                    border: none;
                    padding: 10px 15px;
                    border-radius: 5px;
                    cursor: pointer;
                    font-size: 0.9em;
                    transition: background-color 0.3s;
                }
                
                .button:hover {
                    background-color: #005a9e;
                }
                
                .button-secondary {
                    background-color: #6c757d;
                }
                
                .button-secondary:hover {
                    background-color: #5a6268;
                }
                
                #multilineInput {
                    width: 100%;
                    min-height: 100px;
                    padding: 10px;
                    font-family: 'Consolas', 'Courier New', monospace;
                    margin-bottom: 10px;
                    border: 1px solid var(--border-color);
                    border-radius: 5px;
                    display: none;
                    white-space: pre;
                    overflow-wrap: normal;
                    overflow-x: auto;
                }
                
                .memory-display {
                    background-color: white;
                    border: 1px solid var(--border-color);
                    border-radius: 5px;
                    padding: 15px;
                    height: 500px;
                    overflow-y: auto;
                }
                
                .memory-file {
                    margin-bottom: 20px;
                }
                
                .memory-file-title {
                    font-weight: bold;
                    margin-bottom: 5px;
                    padding-bottom: 5px;
                    border-bottom: 1px solid var(--border-color);
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                }
                
                .memory-file-actions {
                    display: flex;
                    gap: 5px;
                }
                
                .file-action {
                    font-size: 0.7em;
                    padding: 2px 5px;
                    background-color: var(--primary-color);
                    color: white;
                    border: none;
                    border-radius: 3px;
                    cursor: pointer;
                }
                
                .file-action:hover {
                    background-color: #005a9e;
                }
                
                .memory-slot {
                    padding: 8px;
                    border-bottom: 1px solid #f0f0f0;
                }
                
                .memory-slot:hover {
                    background-color: var(--highlight-color);
                }
                
                .memory-slot-title {
                    font-weight: bold;
                    margin-bottom: 5px;
                }
                
                .memory-slot-value {
                    white-space: pre-wrap;
                    font-family: 'Consolas', 'Courier New', monospace;
                    padding: 5px;
                    background-color: #f8f8f8;
                    border-radius: 3px;
                    font-size: 0.9em;
                }
                
                .quick-commands {
                    display: flex;
                    flex-wrap: wrap;
                    gap: 10px;
                    margin-top: 15px;
                }
                
                .quick-command {
                    background-color: #f0f0f0;
                    padding: 5px 10px;
                    border-radius: 3px;
                    font-size: 0.8em;
                    cursor: pointer;
                    transition: background-color 0.3s;
                }
                
                .quick-command:hover {
                    background-color: #e0e0e0;
                }
                
                .modal {
                    display: none;
                    position: fixed;
                    z-index: 1;
                    left: 0;
                    top: 0;
                    width: 100%;
                    height: 100%;
                    overflow: auto;
                    background-color: rgba(0,0,0,0.5);
                }
                
                .modal-content {
                    background-color: #fefefe;
                    margin: 15% auto;
                    padding: 20px;
                    border: 1px solid #888;
                    width: 80%;
                    max-width: 600px;
                    border-radius: 5px;
                }
                
                .close-modal {
                    color: #aaa;
                    float: right;
                    font-size: 28px;
                    font-weight: bold;
                    cursor: pointer;
                }
                
                .close-modal:hover {
                    color: black;
                }
                
                .progress-bar-container {
                    width: 100%;
                    background-color: #e0e0e0;
                    border-radius: 3px;
                    margin: 10px 0;
                }
                
                .progress-bar {
                    height: 20px;
                    background-color: var(--primary-color);
                    border-radius: 3px;
                    width: 0%;
                    transition: width 0.3s;
                }
                
                #generationStatus {
                    margin-top: 10px;
                    font-size: 0.9em;
                }
                
                /* File system styles */
                .files-section {
                    margin-top: 20px;
                }
                
                .file-system-actions {
                    display: flex;
                    gap: 10px;
                    margin-bottom: 10px;
                }
                
                /* Radio button styling */
                .radio-group {
                    margin: 15px 0;
                }
                
                .radio-option {
                    margin-bottom: 10px;
                    display: flex;
                    align-items: flex-start;
                }
                
                .radio-option input[type="radio"] {
                    margin-top: 3px;
                    margin-right: 10px;
                }
                
                .radio-option .option-label {
                    font-weight: bold;
                }
                
                .radio-option .option-description {
                    font-size: 0.85em;
                    color: #666;
                    margin-top: 2px;
                }
                
                /* File input styling */
                .file-input-container {
                    margin: 15px 0;
                }
                
                .file-input-label {
                    font-weight: bold;
                    margin-bottom: 5px;
                    display: block;
                }
                
                .file-input {
                    width: 100%;
                    padding: 8px;
                    border: 1px solid var(--border-color);
                    border-radius: 4px;
                }
                
                /* Logic engine styles */
                .nav-tabs {
                    display: flex;
                    border-bottom: 1px solid var(--border-color);
                    margin-bottom: 15px;
                }
                
                .nav-tab {
                    padding: 8px 15px;
                    cursor: pointer;
                    border: 1px solid transparent;
                    border-bottom: none;
                    border-radius: 5px 5px 0 0;
                    margin-right: 5px;
                    background-color: #f8f8f8;
                }
                
                .nav-tab.active {
                    background-color: white;
                    border-color: var(--border-color);
                    border-bottom: 1px solid white;
                    margin-bottom: -1px;
                    font-weight: bold;
                }
                
                .tab-content {
                    display: none;
                }
                
                .tab-content.active {
                    display: block;
                }
                
                #logicTerminal {
                    background-color: var(--terminal-bg);
                    color: var(--terminal-text);
                    padding: 15px;
                    border-radius: 5px;
                    font-family: 'Consolas', 'Courier New', monospace;
                    height: 300px;
                    overflow-y: auto;
                    margin-bottom: 15px;
                }
                
                @media (max-width: 768px) {
                    body {
                        padding: 10px;
                    }
                    
                    .terminal {
                        height: 250px;
                    }
                    
                    .memory-display {
                        height: 300px;
                    }
                    
                    .modal-content {
                        width: 95%;
                        margin: 10% auto;
                    }
                    
                    .file-system-actions {
                        flex-direction: column;
                    }
                }
            </style>
        </head>
        <body>
            <header>
                <h1>INTEGRATED MEMORY & LOGIC FRAMEWORK</h1>
                <div class="system-info">
                    <div id="systemTime"></div>
                    <div>MEMORY MANAGER & LOGIC ENGINE LOADED</div>
                    <div>READY FOR INPUT</div>
                </div>
            </header>
            
            <div class="main-container">
                <div class="terminal-section">
                    <div class="section">
                        <div class="nav-tabs">
                            <div class="nav-tab active" data-tab="memory">Memory Manager</div>
                            <div class="nav-tab" data-tab="logic">Logic Engine</div>
                        </div>
                        
                        <div id="memoryTab" class="tab-content active">
                            <div class="section-title">
                                Command Terminal
                                <div class="section-title-actions">
                                    <button class="action-button" onclick="clearTerminal()">Clear</button>
                                </div>
                            </div>
                            <div id="terminal" class="terminal"></div>
                            <input type="text" id="commandInput" placeholder="Enter command (type 'help' for list of commands)">
                            <textarea id="multilineInput" placeholder="Enter multi-line content (e.g. for assign or search)" wrap="off"></textarea>
                            <div class="quick-commands">
                                <span class="quick-command" onclick="insertCommand('help')">help</span>
                                <span class="quick-command" onclick="insertCommand('display')">display</span>
                                <span class="quick-command" onclick="insertCommand('assign')">assign</span>
                                <span class="quick-command" onclick="insertCommand('read')">read</span>
                                <span class="quick-command" onclick="insertCommand('search')">search</span>
                                <span class="quick-command" onclick="insertCommand('generate')">generate</span>
                                <span class="quick-command" onclick="insertCommand('save_all')">save_all</span>
                                <span class="quick-command" onclick="insertCommand('load_all')">load_all</span>
                            </div>
                            <div style="display: flex; gap: 10px; margin-top: 10px;">
                                <button id="submitCommand" class="button">Execute Command</button>
                                <button id="submitMultiline" class="button" style="display: none;">Submit</button>
                                <button id="cancelMultiline" class="button button-secondary" style="display: none;">Cancel</button>
                            </div>
                        </div>
                        
                        <div id="logicTab" class="tab-content">
                            <div class="section-title">
                                Proof by Contradiction Engine
                                <div class="section-title-actions">
                                    <button class="action-button" onclick="clearLogicTerminal()">Clear</button>
                                </div>
                            </div>
                            <div id="logicTerminal" class="terminal"></div>
                            <input type="text" id="logicCommandInput" placeholder="Enter instruction (type 'help' for available instructions)">
                            <div class="quick-commands">
                                <span class="quick-command" onclick="insertLogicCommand('help')">help</span>
                                <span class="quick-command" onclick="insertLogicCommand('ASSERT')">ASSERT</span>
                                <span class="quick-command" onclick="insertLogicCommand('NOT')">NOT</span>
                                <span class="quick-command" onclick="insertLogicCommand('AND')">AND</span>
                                <span class="quick-command" onclick="insertLogicCommand('OR')">OR</span>
                                <span class="quick-command" onclick="insertLogicCommand('IMPLIES')">IMPLIES</span>
                                <span class="quick-command" onclick="insertLogicCommand('CONTRADICTION')">CONTRADICTION</span>
                            </div>
                            <div style="display: flex; gap: 10px; margin-top: 10px;">
                                <button id="submitLogicCommand" class="button">Execute Instruction</button>
                                <button id="checkContradictions" class="button">Check Contradictions</button>
                                <button id="clearStatements" class="button button-secondary">Clear Statements</button>
                                <button id="generateStatements" class="button">Generate Statements</button>
                            </div>
                        </div>
                    </div>
                    
                    <div class="section files-section">
                        <div class="section-title">File System</div>
                        <div class="file-system-actions">
                            <button class="button" onclick="saveAllMemorySlots()">Save All Files</button>
                            <button class="button" onclick="loadMemorySlotsFromFile()">Load Files</button>
                            <button class="button button-secondary" onclick="clearAllMemorySlots()">Clear All Files</button>
                        </div>
                    </div>
                </div>
                
                <div class="results-section">
                    <div class="section">
                        <div class="section-title">
                            Memory Slots
                            <div class="section-title-actions">
                                <button class="action-button" onclick="updateMemoryDisplay()">Refresh</button>
                            </div>
                        </div>
                        <div id="memoryDisplay" class="memory-display">
                            <div style="text-align: center; color: #888; margin-top: 20px;">
                                No memory slots available.
                                <br><br>
                                Use the terminal to add memory slots.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div id="generationModal" class="modal">
                <div class="modal-content">
                    <span class="close-modal" onclick="document.getElementById('generationModal').style.display='none'">&times;</span>
                    <h2>Generating Combinations</h2>
                    
                    <div class="radio-group">
                        <div class="radio-option">
                            <input type="radio" id="generateSingleFile" name="generateType" value="singleFile" checked>
                            <div>
                                <div class="option-label">Single File with Multiple Slots</div>
                                <div class="option-description">Store all combinations in one file with each combination as a separate slot</div>
                            </div>
                        </div>
                        <div class="radio-option">
                            <input type="radio" id="generateMultiFile" name="generateType" value="multiFile">
                            <div>
                                <div class="option-label">One File Per Combination</div>
                                <div class="option-description">Create a separate file for each generated combination</div>
                            </div>
                        </div>
                    </div>
                    
                    <div id="fileInputContainer" class="file-input-container">
                        <div class="file-input-label">Enter Filename for Single File Mode:</div>
                        <input type="text" id="fileNameInput" class="file-input" value="combinations" placeholder="Enter filename (e.g. 3, combinations, etc.)">
                    </div>
                    
                    <div class="progress-bar-container">
                        <div id="generationProgress" class="progress-bar"></div>
                    </div>
                    <div id="generationStatus">Ready to generate</div>
                    <div style="margin-top: 20px; display: flex; gap: 10px; flex-wrap: wrap;">
                        <button id="startGenerationBtn" class="button">Start Generation</button>
                        <button id="downloadGeneratedBtn" class="button" disabled>Download Results</button>
                        <button id="importGeneratedBtn" class="button" disabled>Import to Memory Slots</button>
                        <button class="button button-secondary" onclick="document.getElementById('generationModal').style.display='none'">Close</button>
                    </div>
                </div>
            </div>
            
            <div id="statementsGenerationModal" class="modal">
                <div class="modal-content">
                    <span class="close-modal" onclick="document.getElementById('statementsGenerationModal').style.display='none'">&times;</span>
                    <h2>Generate Statements</h2>
                    
                    <div class="file-input-container">
                        <div class="file-input-label">Number of statements to generate:</div>
                        <input type="number" id="numStatementsInput" class="file-input" value="5" min="1" max="100">
                    </div>
                    
                    <div style="margin-top: 20px; display: flex; gap: 10px; flex-wrap: wrap;">
                        <button id="startStatementsGenBtn" class="button">Generate Statements</button>
                        <button class="button button-secondary" onclick="document.getElementById('statementsGenerationModal').style.display='none'">Cancel</button>
                    </div>
                </div>
            </div>
            
            <div id="helpModal" class="modal">
                <div class="modal-content">
                    <span class="close-modal" onclick="document.getElementById('helpModal').style.display='none'">&times;</span>
                    <h2>Available Commands</h2>
                    <pre style="white-space: pre-wrap; max-height: 400px; overflow-y: auto; margin-top: 10px;">
AVAILABLE COMMANDS:
------------------
assign &lt;fileNumber&gt; &lt;slotNumber&gt;
  &lt;value&gt;             : Assign a multi-line value to a slot
                        (Enter your multi-line value in the text area)

read &lt;fileNumber&gt; &lt;slotNumber&gt;
                     : Read the value from a slot

last_slot &lt;fileNumber&gt;
                     : Get the last slot number in a file

search
  &lt;value&gt;             : Search for a value across all slots

call &lt;fileNumber&gt; &lt;startSlot&gt; &lt;endSlot&gt;
                     : Call values from a range of slots

export &lt;fileNumber&gt;  : Export a file's memory slots to a text file

generate &lt;n&gt;         : Generate all combinations with n cells
                       using the standard character set
                       Results are ready to use with this application
                       
                       Generation Options:
                       - Single File: All combinations in one file with multiple slots
                       - One File Per Combination: Each combination in its own file

custom_generate &lt;n&gt;  : Generate combinations with custom character set

display              : Show all memory slots
clear                : Clear the terminal
help                 : Display this help message

save_json &lt;fileNumber&gt; : Save a specific file to JSON
save_all            : Save all memory slots to a ZIP archive
load_json           : Load memory slots from a JSON file
load_all            : Load memory slots from a ZIP archive

File System Operations:
------------------
The file system supports downloading all your data as a ZIP archive
and uploading it again for continuous use. This provides an automatic
way to save your work and continue where you left off.

Generated files are automatically structured to be used with the
memory slot manager system without any additional processing.
                    </pre>
                </div>
            </div>
            
            <div id="logicHelpModal" class="modal">
                <div class="modal-content">
                    <span class="close-modal" onclick="document.getElementById('logicHelpModal').style.display='none'">&times;</span>
                    <h2>Proof by Contradiction Engine Help</h2>
                    <pre style="white-space: pre-wrap; max-height: 400px; overflow-y: auto; margin-top: 10px;">
Proof by Contradiction Engine Help
----------------------------------
1. Add Instruction:
   - ASSERT &lt;statement&gt;
   - NOT &lt;statement&gt;
   - AND &lt;statement1&gt; &lt;statement2&gt;
   - OR &lt;statement1&gt; &lt;statement2&gt;
   - IMPLIES &lt;statement1&gt; &lt;statement2&gt;
   - CONTRADICTION &lt;statement1&gt; &lt;statement2&gt;
2. Clear Statements: Clears all statements from the current framework.
3. Check Contradictions: Checks for contradictions within the current framework using defined rules.
4. Generate Statements: Automatically generates a framework of statements.
5. Help: Displays this help message.

Example:
   ASSERT Statement1
   NOT Statement1
   CONTRADICTION Statement1 NOT Statement1
   (This will detect a contradiction based on the statement_not_statement rule)
                    </pre>
                </div>
            </div>

            <script>
                class MemorySlotManager {
                    constructor() {
                        this.memorySlots = {};
                    }
                    
                    assignSlot(fileNumber, slotNumber, value) {
                        if (!fileNumber || !slotNumber || !value) {
                            return "Error: Invalid input parameters.";
                        }
                        
                        if (this.valueExists(value)) {
                            return "Error: The value already exists in another memory slot.";
                        }
                        
                        if (!this.memorySlots[fileNumber]) {
                            this.memorySlots[fileNumber] = {};
                        }
                        
                        this.memorySlots[fileNumber][slotNumber] = value;
                        return \`Assigned value to slot \${slotNumber} in file \${fileNumber}.\`;
                    }
                    
                    readSlot(fileNumber, slotNumber) {
                        if (this.memorySlots[fileNumber] && this.memorySlots[fileNumber][slotNumber] !== undefined) {
                            return this.memorySlots[fileNumber][slotNumber];
                        }
                        return \`Slot \${slotNumber} not found in file \${fileNumber}.\`;
                    }
                    
                    getLastSlotNumber(fileNumber) {
                        if (this.memorySlots[fileNumber] && Object.keys(this.memorySlots[fileNumber]).length > 0) {
                            try {
                                const slots = [];
                                for (const slot in this.memorySlots[fileNumber]) {
                                    if (/^\\d+$/.test(slot)) {
                                        slots.push(parseInt(slot));
                                    }
                                }
                                
                                if (slots.length > 0) {
                                    return Math.max(...slots);
                                }
                            } catch (e) {
                                // Ignore exceptions
                            }
                        }
                        return null;
                    }
                    
                    searchValue(value) {
                        const results = [];
                        const searchValueLower = value.toLowerCase();
                        
                        for (const file in this.memorySlots) {
                            for (const slot in this.memorySlots[file]) {
                                const val = this.memorySlots[file][slot];
                                if (val.toLowerCase().includes(searchValueLower)) {
                                    results.push({
                                        file,
                                        slot,
                                        value: val
                                    });
                                }
                            }
                        }
                        
                        return results;
                    }
                    
                    valueExists(value) {
                        const valueLower = value.toLowerCase();
                        
                        for (const file in this.memorySlots) {
                            for (const slot in this.memorySlots[file]) {
                                if (this.memorySlots[file][slot].toLowerCase() === valueLower) {
                                    return true;
                                }
                            }
                        }
                        
                        return false;
                    }
                    
                    callSlotRange(fileNumber, startSlot, endSlot) {
                        if (!this.memorySlots[fileNumber]) {
                            return \`File \${fileNumber} not found.\`;
                        }
                        
                        const results = [];
                        for (let slot = startSlot; slot <= endSlot; slot++) {
                            const slotStr = slot.toString();
                            if (this.memorySlots[fileNumber][slotStr] !== undefined) {
                                results.push(\`Slot \${slotStr}:\\n\${this.memorySlots[fileNumber][slotStr]}\`);
                            } else {
                                results.push(\`Slot \${slotStr} not found.\`);
                            }
                        }
                        
                        return results.join('\\n\\n');
                    }
                    
                    exportToTextFile(fileNumber) {
                        if (!this.memorySlots[fileNumber]) {
                            return \`Error: File \${fileNumber} not found.\`;
                        }
                        
                        try {
                            let content = '';
                            const slots = this.memorySlots[fileNumber];
                            let slotKeys = [];
                            
                            try {
                                const numericKeys = [];
                                for (const key in slots) {
                                    if (/^\\d+$/.test(key)) {
                                        numericKeys.push(parseInt(key));
                                    }
                                }
                                numericKeys.sort((a, b) => a - b);
                                slotKeys = numericKeys.map(key => key.toString());
                            } catch (e) {
                                // If conversion fails, sort alphabetically
                                slotKeys = Object.keys(slots).sort();
                            }
                            
                            for (const slot of slotKeys) {
                                const value = slots[slot];
                                // Format: SLOT <number>
                                content += \`SLOT \${slot}\\n\${value}\\n--------------------\\n\`;
                            }
                            
                            // Create a download link
                            const blob = new Blob([content], { type: 'text/plain' });
                            const url = URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = \`file\${fileNumber}.txt\`;
                            a.click();
                            URL.revokeObjectURL(url);
                            
                            return \`Exported file \${fileNumber} to file\${fileNumber}.txt\`;
                        } catch (e) {
                            return \`Error exporting to text file: \${e.message}\`;
                        }
                    }
                    
                    saveToJSON(fileNumber) {
                        try {
                            if (fileNumber && !this.memorySlots[fileNumber]) {
                                return \`Error: File \${fileNumber} not found.\`;
                            }
                            
                            let jsonData;
                            let filename;
                            
                            if (fileNumber) {
                                jsonData = this.memorySlots[fileNumber];
                                filename = \`file\${fileNumber}.json\`;
                            } else {
                                jsonData = this.memorySlots;
                                filename = 'memory_slots.json';
                            }
                            
                            const jsonString = JSON.stringify(jsonData, null, 2);
                            const blob = new Blob([jsonString], { type: 'application/json' });
                            const url = URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = filename;
                            a.click();
                            URL.revokeObjectURL(url);
                            
                            return \`Memory slots saved to \${filename}\`;
                        } catch (e) {
                            return \`Error saving to JSON: \${e.message}\`;
                        }
                    }
                    
                    loadJSON(jsonData) {
                        try {
                            const content = JSON.parse(jsonData);
                            
                            if (typeof content === 'object' && content !== null) {
                                // Check if this is our expected format
                                let isFullStructure = false;
                                for (const file in content) {
                                    if (typeof content[file] === 'object' && content[file] !== null) {
                                        isFullStructure = true;
                                        break;
                                    }
                                }
                                
                                if (isFullStructure) {
                                    // Merge with existing memory slots
                                    for (const file in content) {
                                        if (!this.memorySlots[file]) {
                                            this.memorySlots[file] = {};
                                        }
                                        
                                        for (const slot in content[file]) {
                                            this.memorySlots[file][slot] = content[file][slot];
                                        }
                                    }
                                } else {
                                    // Assume it's a single file's slots
                                    const fileNumber = '1'; // Default file number
                                    if (!this.memorySlots[fileNumber]) {
                                        this.memorySlots[fileNumber] = {};
                                    }
                                    
                                    for (const slot in content) {
                                        this.memorySlots[fileNumber][slot] = content[slot];
                                    }
                                }
                                
                                return 'Successfully loaded JSON data.';
                            }
                            
                            return 'Error: Invalid JSON structure.';
                        } catch (e) {
                            return \`Error loading JSON: \${e.message}\`;
                        }
                    }
                    
                    // Save all memory slots as a ZIP file
                    saveAllAsZip() {
                        try {
                            // Create a direct download of all slots as JSON for simpler implementation
                            const jsonData = JSON.stringify(this.memorySlots, null, 2);
                            const blob = new Blob([jsonData], { type: 'application/json' });
                            const url = URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = 'all_memory_slots.json';
                            a.click();
                            URL.revokeObjectURL(url);
                            
                            return 'All memory slots saved to all_memory_slots.json';
                        } catch (e) {
                            return \`Error saving memory slots: \${e.message}\`;
                        }
                    }
                    
                    // Load memory slots from a JSON file (simplified without ZIP)
                    loadFromFile(file) {
                        return new Promise((resolve, reject) => {
                            const reader = new FileReader();
                            
                            reader.onload = (e) => {
                                try {
                                    const result = this.loadJSON(e.target.result);
                                    resolve(result);
                                } catch (error) {
                                    reject(\`Error parsing file: \${error.message}\`);
                                }
                            };
                            
                            reader.onerror = () => {
                                reject('Error reading file');
                            };
                            
                            reader.readAsText(file);
                        });
                    }
                    
                    generateCharSet() {
                        let chars =
                            "abcdefghijklmnopqrstuvwxyz" +
                            "ABCDEFGHIJKLMNOPQRSTUVWXYZ" +
                            "0123456789" +
                            "!@#$%^&*()-_=+[]{}|;:,.<>/?" +
                            " \\t\\n\\r" +
                            "~\`'\\"\\\\";
                        
                        // Ensure exactly 100 characters
                        if (chars.length > 100) {
                            chars = chars.substring(0, 100);
                        } else if (chars.length < 100) {
                            // Pad with additional characters if needed
                            while (chars.length < 100) {
                                chars += '?';
                            }
                        }
                        
                        return chars;
                    }
                    
                    async generateCombinations(chars, n, generateType, fileName, progressCallback) {
                        // The number of possible combinations is (k+1)^n
                        const k = chars.length - 1;
                        const nbrComb = Math.pow(k + 1, n);
                        
                        let fileContent = '';
                        
                        if (nbrComb > 1000000) {
                            progressCallback(0, "Warning: Generating a large number of combinations. This may take a while.");
                        }
                        
                        // Clear any existing memory slots that would be affected
                        if (generateType === 'singleFile') {
                            // Clear just the target file
                            this.memorySlots[fileName] = {};
                        }
                        
                        // To avoid blocking the UI for too long, break up the work
                        const batchSize = 10000; // Process in batches to keep UI responsive
                        const totalBatches = Math.ceil(nbrComb / batchSize);
                        
                        for (let batch = 0; batch < totalBatches; batch++) {
                            await new Promise(resolve => setTimeout(resolve, 0)); // Allow UI to update
                            
                            const startRow = batch * batchSize;
                            const endRow = Math.min((batch + 1) * batchSize, nbrComb);
                            
                            for (let row = startRow; row < endRow; row++) {
                                const id = row + 1;
                                let combination = '';
                                
                                for (let col = n - 1; col >= 0; col--) {
                                    const rdiv = Math.pow(k + 1, col);
                                    const cell = Math.floor(row / rdiv) % (k + 1);
                                    combination += chars[cell];
                                }
                                
                                // Handle different generation types
                                if (generateType === 'singleFile') {
                                    // Store all combinations in a single file with the given name
                                    const slotNumber = id.toString();
                                    this.memorySlots[fileName][slotNumber] = combination;
                                } 
                                else if (generateType === 'multiFile') {
                                    // Each combination gets its own file
                                    const fileNumber = id.toString();
                                    if (!this.memorySlots[fileNumber]) {
                                        this.memorySlots[fileNumber] = {};
                                    }
                                    // Always use slot 1 for each file
                                    this.memorySlots[fileNumber]['1'] = combination;
                                }
                                
                                // Add to file content for download
                                if (generateType === 'singleFile') {
                                    fileContent += \`SLOT \${id}\\n\${combination}\\n--------------------\\n\`;
                                } else {
                                    fileContent += \`FILE \${id}\\nSLOT 1\\n\${combination}\\n--------------------\\n\`;
                                }
                            }
                            
                            // Update progress approximately every 5%
                            if (batch % Math.max(1, Math.floor(totalBatches / 20)) === 0 || batch === totalBatches - 1) {
                                const progress = ((batch + 1) / totalBatches) * 100;
                                progressCallback(progress, \`Generated \${Math.min((batch + 1) * batchSize, nbrComb)} of \${nbrComb} combinations (\${progress.toFixed(1)}%)\`);
                            }
                        }
                        
                        // Format the complete output in a way that's ready for the application
                        let finalContent = \`GENERATED COMBINATIONS\\n\`;
                        finalContent += \`Generation Mode: \${generateType === 'singleFile' ? 'Single File' : 'One File Per Combination'}\\n\`;
                        finalContent += \`(k+1)^n = (\${k} + 1)^\${n} = \${nbrComb}\\n\`;
                        finalContent += \`=========================================\\n\`;
                        finalContent += fileContent;
                        finalContent += \`\\n\\nEnd. Total combinations: \${nbrComb}\`;
                        
                        return {
                            content: finalContent,
                            count: nbrComb,
                            type: generateType,
                            fileName: fileName
                        };
                    }
                    
                    // Import generated combinations from text based on generation type
                    importCombinationsFromText(text, type, fileName) {
                        try {
                            if (type === 'singleFile') {
                                // Parse single file format
                                const pattern = /SLOT (\\d+)\\n([\\s\\S]*?)(?=\\-{20}|\\Z)/g;
                                let match;
                                let count = 0;
                                
                                // Create or clear the target file
                                if (!this.memorySlots[fileName]) {
                                    this.memorySlots[fileName] = {};
                                } else {
                                    // Clear existing slots
                                    this.memorySlots[fileName] = {};
                                }
                                
                                while ((match = pattern.exec(text)) !== null) {
                                    const slotNumber = match[1];
                                    let value = match[2].trim();
                                    
                                    // Store in memory slots
                                    this.memorySlots[fileName][slotNumber] = value;
                                    count++;
                                }
                                
                                return \`Imported \${count} combinations into file "\${fileName}"\`;
                            } 
                            else if (type === 'multiFile') {
                                // Parse multi-file format
                                const filePattern = /FILE (\\d+)\\nSLOT (\\d+)\\n([\\s\\S]*?)(?=\\-{20}|\\Z)/g;
                                let fileMatch;
                                let count = 0;
                                
                                while ((fileMatch = filePattern.exec(text)) !== null) {
                                    const fileNumber = fileMatch[1];
                                    const slotNumber = fileMatch[2];
                                    let value = fileMatch[3].trim();
                                    
                                    // Create file if it doesn't exist
                                    if (!this.memorySlots[fileNumber]) {
                                        this.memorySlots[fileNumber] = {};
                                    }
                                    
                                    // Store in memory slots
                                    this.memorySlots[fileNumber][slotNumber] = value;
                                    count++;
                                }
                                
                                // Fallback for standard format without FILE headers
                                if (count === 0) {
                                    const pattern = /SLOT (\\d+)\\n([\\s\\S]*?)(?=\\-{20}|\\Z)/g;
                                    let match;
                                    let fileNumber = 1;
                                    
                                    while ((match = pattern.exec(text)) !== null) {
                                        const slotNumber = match[1];
                                        let value = match[2].trim();
                                        
                                        // Create file if it doesn't exist
                                        if (!this.memorySlots[fileNumber.toString()]) {
                                            this.memorySlots[fileNumber.toString()] = {};
                                        }
                                        
                                        // Store in memory slots
                                        this.memorySlots[fileNumber.toString()]['1'] = value;
                                        count++;
                                        fileNumber++;
                                    }
                                }
                                
                                return \`Imported \${count} combinations into separate files\`;
                            }
                            
                            return "Unknown generation type for import";
                        } catch (e) {
                            return \`Error importing combinations: \${e.message}\`;
                        }
                    }
                    
                    // Clear all memory slots
                    clearAll() {
                        this.memorySlots = {};
                        return 'All memory slots cleared';
                    }
                }
                
                // Proof by Contradiction Engine integration
                class ProofByContradictionEngine {
                    constructor() {
                        this.statementsFileId = "statements"; // File ID for storing statements in memory manager
                        this.char_set = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ+-*/=<>!@#$%^&()[]{},;:.?~\`|";
                        this.MAX_STATEMENT_LENGTH = 256;
                        this.NUM_CHARACTERS = this.char_set.length;
                        
                        // Initialize the statements file
                        if (!memoryManager.memorySlots[this.statementsFileId]) {
                            memoryManager.memorySlots[this.statementsFileId] = {};
                        }
                    }
                    
                    clearStatements() {
                        memoryManager.memorySlots[this.statementsFileId] = {};
                        return "All statements cleared.";
                    }
                    
                    addStatement(statement) {
                        // Get the next slot number
                        let slotNumber = 1;
                        const existingSlots = Object.keys(memoryManager.memorySlots[this.statementsFileId])
                            .map(key => parseInt(key))
                            .filter(num => !isNaN(num));
                        
                        if (existingSlots.length > 0) {
                            slotNumber = Math.max(...existingSlots) + 1;
                        }
                        
                        // Store the statement
                        memoryManager.memorySlots[this.statementsFileId][slotNumber] = statement;
                        return slotNumber;
                    }
                    
                    getStatements() {
                        const statements = [];
                        const slots = memoryManager.memorySlots[this.statementsFileId];
                        
                        const sortedKeys = Object.keys(slots)
                            .map(key => parseInt(key))
                            .filter(num => !isNaN(num))
                            .sort((a, b) => a - b);
                        
                        for (const key of sortedKeys) {
                            statements.push(slots[key]);
                        }
                        
                        return statements;
                    }
                    
                    generateStatement() {
                        const length = Math.floor(Math.random() * this.MAX_STATEMENT_LENGTH) + 1;
                        let statement = '';
                        
                        for (let i = 0; i < length; i++) {
                            statement += this.char_set[Math.floor(Math.random() * this.NUM_CHARACTERS)];
                        }
                        
                        return statement;
                    }
                    
                    generateStatements(numStatements) {
                        this.clearStatements();
                        
                        for (let i = 0; i < numStatements; i++) {
                            const statement = this.generateStatement();
                            this.addStatement(statement);
                        }
                        
                        return \`\${numStatements} statements generated.\`;
                    }
                    
                    checkContradiction() {
                        const statements = this.getStatements();
                        
                        // Implementation of rule_statement_not_statement
                        for (let i = 0; i < statements.length; i++) {
                            const statement = statements[i];
                            const notStatement = \`NOT \${statement}\`;
                            
                            for (let j = 0; j < statements.length; j++) {
                                if (i !== j && statements[j] === notStatement) {
                                    return {
                                        found: true,
                                        indices: [i, j],
                                        statements: [statement, notStatement]
                                    };
                                }
                            }
                        }
                        
                        // Implementation of rule_identical_statements
                        for (let i = 0; i < statements.length; i++) {
                            for (let j = i + 1; j < statements.length; j++) {
                                if (statements[i] === statements[j]) {
                                    return {
                                        found: true,
                                        indices: [i, j],
                                        statements: [statements[i], statements[j]],
                                        rule: "identical_statements"
                                    };
                                }
                            }
                        }
                        
                        return { found: false };
                    }
                    
                    processInstruction(instruction) {
                        const parts = instruction.split(' ');
                        const cmd = parts[0];
                        
                        switch (cmd) {
                            case 'ASSERT':
                                if (parts.length < 2) {
                                    return "Error: ASSERT requires a statement.";
                                }
                                const statement = parts.slice(1).join(' ');
                                const slotNumber = this.addStatement(statement);
                                return \`Added statement "\${statement}" at position \${slotNumber}.\`;
                            
                            case 'NOT':
                                if (parts.length < 2) {
                                    return "Error: NOT requires a statement.";
                                }
                                const notStatement = parts.slice(1).join(' ');
                                const notSlotNumber = this.addStatement(\`NOT \${notStatement}\`);
                                return \`Added statement "NOT \${notStatement}" at position \${notSlotNumber}.\`;
                            
                            case 'AND':
                                if (parts.length < 3) {
                                    return "Error: AND requires two statements.";
                                }
                                const andStatement1 = parts[1];
                                const andStatement2 = parts.slice(2).join(' ');
                                const andSlotNumber = this.addStatement(\`(\${andStatement1}) AND (\${andStatement2})\`);
                                return \`Added statement "(\${andStatement1}) AND (\${andStatement2})" at position \${andSlotNumber}.\`;
                            
                            case 'OR':
                                if (parts.length < 3) {
                                    return "Error: OR requires two statements.";
                                }
                                const orStatement1 = parts[1];
                                const orStatement2 = parts.slice(2).join(' ');
                                const orSlotNumber = this.addStatement(\`\${orStatement1} OR \${orStatement2}\`);
                                return \`Added statement "\${orStatement1} OR \${orStatement2}" at position \${orSlotNumber}.\`;
                            
                            case 'IMPLIES':
                                if (parts.length < 3) {
                                    return "Error: IMPLIES requires two statements.";
                                }
                                const impliesStatement1 = parts[1];
                                const impliesStatement2 = parts.slice(2).join(' ');
                                const impliesSlotNumber = this.addStatement(\`\${impliesStatement1} IMPLIES \${impliesStatement2}\`);
                                return \`Added statement "\${impliesStatement1} IMPLIES \${impliesStatement2}" at position \${impliesSlotNumber}.\`;
                            
                            case 'CONTRADICTION':
                                if (parts.length < 3) {
                                    return "Error: CONTRADICTION requires two statements.";
                                }
                                
                                const contradictionStatement1 = parts[1];
                                const contradictionStatement2 = parts.slice(2).join(' ');
                                
                                // Check if the statements exist in our framework
                                const statements = this.getStatements();
                                let found1 = false, found2 = false;
                                let index1 = -1, index2 = -1;
                                
                                for (let i = 0; i < statements.length; i++) {
                                    if (statements[i] === contradictionStatement1) {
                                        found1 = true;
                                        index1 = i;
                                    }
                                    if (statements[i] === contradictionStatement2) {
                                        found2 = true;
                                        index2 = i;
                                    }
                                }
                                
                                if (found1 && found2) {
                                    return \`Contradiction found between statements \${index1 + 1} and \${index2 + 1}:\\n  \${contradictionStatement1}\\n  \${contradictionStatement2}\`;
                                } else {
                                    return "No contradiction found between the specified statements.";
                                }
                            
                            default:
                                return \`Unknown instruction: \${cmd}\`;
                        }
                    }
                }

                // Initialize the applications
                const memoryManager = new MemorySlotManager();
                const logicEngine = new ProofByContradictionEngine();
                
                // DOM Elements
                const terminal = document.getElementById('terminal');
                const commandInput = document.getElementById('commandInput');
                const multilineInput = document.getElementById('multilineInput');
                const submitCommandBtn = document.getElementById('submitCommand');
                const submitMultilineBtn = document.getElementById('submitMultiline');
                const cancelMultilineBtn = document.getElementById('cancelMultiline');
                const memoryDisplay = document.getElementById('memoryDisplay');
                const systemTimeEl = document.getElementById('systemTime');
                
                const logicTerminal = document.getElementById('logicTerminal');
                const logicCommandInput = document.getElementById('logicCommandInput');
                const submitLogicCommandBtn = document.getElementById('submitLogicCommand');
                const checkContradictionsBtn = document.getElementById('checkContradictions');
                const clearStatementsBtn = document.getElementById('clearStatements');
                const generateStatementsBtn = document.getElementById('generateStatements');
                
                const generationModal = document.getElementById('generationModal');
                const generationProgress = document.getElementById('generationProgress');
                const generationStatus = document.getElementById('generationStatus');
                const downloadGeneratedBtn = document.getElementById('downloadGeneratedBtn');
                const importGeneratedBtn = document.getElementById('importGeneratedBtn');
                const startGenerationBtn = document.getElementById('startGenerationBtn');
                const fileNameInput = document.getElementById('fileNameInput');
                let generatedResults = null;
                
                // Set current time
                const now = new Date();
                systemTimeEl.textContent = \`SYSTEM INITIALIZED: \${now.toISOString().replace('T', ' ').substr(0, 19)}\`;
                
                // Add initial welcome message
                appendToTerminal('INTEGRATED MEMORY & LOGIC FRAMEWORK', 'system');
                appendToTerminal('Type "help" for a list of commands.', 'system');
                
                // Add initial welcome message to logic terminal
                appendToLogicTerminal('PROOF BY CONTRADICTION ENGINE INITIALIZED', 'system');
                appendToLogicTerminal('Type "help" for a list of instructions.', 'system');
                
                // Set up tab navigation
                document.querySelectorAll('.nav-tab').forEach(tab => {
                    tab.addEventListener('click', function() {
                        // Remove active class from all tabs
                        document.querySelectorAll('.nav-tab').forEach(t => {
                            t.classList.remove('active');
                        });
                        
                        // Add active class to clicked tab
                        this.classList.add('active');
                        
                        // Hide all tab content
                        document.querySelectorAll('.tab-content').forEach(content => {
                            content.classList.remove('active');
                        });
                        
                        // Show the selected tab content
                        const tabId = this.getAttribute('data-tab');
                        document.getElementById(\`\${tabId}Tab\`).classList.add('active');
                    });
                });
                
                // Event handler for generate type change
                document.querySelectorAll('input[name="generateType"]').forEach(radio => {
                    radio.addEventListener('change', function() {
                        const fileInputContainer = document.getElementById('fileInputContainer');
                        if (this.value === 'singleFile') {
                            fileInputContainer.style.display = 'block';
                        } else {
                            fileInputContainer.style.display = 'none';
                        }
                    });
                });
                
                // Start generation button handler
                startGenerationBtn.addEventListener('click', async () => {
                    const generateType = document.querySelector('input[name="generateType"]:checked').value;
                    let fileName = fileNameInput.value.trim();
                    
                    // Default to "combinations" if empty
                    if (generateType === 'singleFile' && !fileName) {
                        fileName = 'combinations';
                    }
                    
                    try {
                        startGenerationBtn.disabled = true;
                        downloadGeneratedBtn.disabled = true;
                        importGeneratedBtn.disabled = true;
                        generationProgress.style.width = '0%';
                        generationStatus.textContent = 'Starting generation...';
                        
                        // Get n value from stored data
                        const n = parseInt(generationModal.dataset.n);
                        const chars = generationModal.dataset.customChars || memoryManager.generateCharSet();
                        
                        generatedResults = await memoryManager.generateCombinations(
                            chars, 
                            n, 
                            generateType,
                            fileName,
                            (progress, status) => {
                                generationProgress.style.width = \`\${progress}%\`;
                                generationStatus.textContent = status;
                            }
                        );
                        
                        downloadGeneratedBtn.disabled = false;
                        importGeneratedBtn.disabled = false;
                        
                        let modeDesc = generateType === 'singleFile' ? 
                            \`single file "\${fileName}"\` : 
                            'separate files (one per combination)';
                        
                        generationStatus.textContent = \`Generation complete! \${generatedResults.count} combinations generated in \${modeDesc}.\`;
                        
                        // If the count is manageable, automatically import
                        if (generatedResults.count <= 1000) {
                            const result = memoryManager.importCombinationsFromText(
                                generatedResults.content, 
                                generatedResults.type,
                                generatedResults.fileName
                            );
                            appendToTerminal(result, 'system');
                            updateMemoryDisplay();
                        }
                    } catch (e) {
                        generationStatus.textContent = \`Error during generation: \${e.message}\`;
                        appendToTerminal(\`Error during generation: \${e.message}\`, 'system');
                    } finally {
                        startGenerationBtn.disabled = false;
                    }
                });
                
                // Generate statements button handler
                generateStatementsBtn.addEventListener('click', () => {
                    document.getElementById('statementsGenerationModal').style.display = 'block';
                });
                
                // Start statements generation button handler
                document.getElementById('startStatementsGenBtn').addEventListener('click', () => {
                    const numStatements = parseInt(document.getElementById('numStatementsInput').value);
                    if (isNaN(numStatements) || numStatements <= 0) {
                        appendToLogicTerminal('Error: Please enter a valid positive number.', 'system');
                        return;
                    }
                    
                    const result = logicEngine.generateStatements(numStatements);
                    appendToLogicTerminal(result, 'system');
                    document.getElementById('statementsGenerationModal').style.display = 'none';
                    
                    // Display the current statements
                    const statements = logicEngine.getStatements();
                    let output = 'Current statements in framework:';
                    for (let i = 0; i < statements.length; i++) {
                        output += \`\\n\${i + 1}. \${statements[i]}\`;
                    }
                    appendToLogicTerminal(output, 'system');
                });
                
                // Check contradictions button handler
                checkContradictionsBtn.addEventListener('click', () => {
                    const statements = logicEngine.getStatements();
                    
                    if (statements.length === 0) {
                        appendToLogicTerminal('No statements in framework.', 'system');
                        return;
                    }
                    
                    let output = 'Current statements in framework:';
                    for (let i = 0; i < statements.length; i++) {
                        output += \`\\n\${i + 1}. \${statements[i]}\`;
                    }
                    appendToLogicTerminal(output, 'system');
                    
                    const result = logicEngine.checkContradiction();
                    if (result.found) {
                        let contradictionMsg = \`Contradiction found between statements \${result.indices[0] + 1} and \${result.indices[1] + 1}:\\n\`;
                        contradictionMsg += \`  \${result.statements[0]}\\n  \${result.statements[1]}\\n\`;
                        
                        if (result.rule) {
                            contradictionMsg += \`(Detected by \${result.rule} rule)\`;
                        }
                        
                        appendToLogicTerminal(contradictionMsg, 'system');
                    } else {
                        appendToLogicTerminal('No contradictions found in the current framework.', 'system');
                    }
                });
                
                // Clear statements button handler
                clearStatementsBtn.addEventListener('click', () => {
                    const result = logicEngine.clearStatements();
                    appendToLogicTerminal(result, 'system');
                });
                
                // Enable tab key in the multiline input
                multilineInput.addEventListener('keydown', function(e) {
                    if (e.key === 'Tab') {
                        e.preventDefault();
                        
                        // Insert a tab at the current cursor position
                        const start = this.selectionStart;
                        const end = this.selectionEnd;
                        const value = this.value;
                        
                        // Insert the tab character
                        this.value = value.substring(0, start) + '\\t' + value.substring(end);
                        
                        // Move the cursor after the tab
                        this.selectionStart = this.selectionEnd = start + 1;
                    }
                });
                
                // Event listeners for memory manager
                commandInput.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter') {
                        const command = commandInput.value.trim();
                        submitCommand(command);
                    }
                });
                
                submitCommandBtn.addEventListener('click', () => {
                    const command = commandInput.value.trim();
                    submitCommand(command);
                });
                
                submitMultilineBtn.addEventListener('click', () => {
                    const multilineValue = multilineInput.value;
                    finishMultilineInput(multilineValue);
                });
                
                cancelMultilineBtn.addEventListener('click', () => {
                    // Reset the UI
                    resetToCommandMode();
                    appendToTerminal('Multi-line input canceled.', 'system');
                });
                
                // Event listeners for logic engine
                logicCommandInput.addEventListener('keydown', (e) => {
                    if (e.key === 'Enter') {
                        const command = logicCommandInput.value.trim();
                        submitLogicCommand(command);
                    }
                });
                
                submitLogicCommandBtn.addEventListener('click', () => {
                    const command = logicCommandInput.value.trim();
                    submitLogicCommand(command);
                });
                
                downloadGeneratedBtn.addEventListener('click', () => {
                    if (generatedResults) {
                        const blob = new Blob([generatedResults.content], { type: 'text/plain' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = 'GENERATED_COMBINATIONS.txt';
                        a.click();
                        URL.revokeObjectURL(url);
                    }
                });
                
                importGeneratedBtn.addEventListener('click', () => {
                    if (generatedResults) {
                        // Import the generated combinations into memory slots
                        const result = memoryManager.importCombinationsFromText(
                            generatedResults.content, 
                            generatedResults.type,
                            generatedResults.fileName
                        );
                        appendToTerminal(result, 'system');
                        updateMemoryDisplay();
                        document.getElementById('generationModal').style.display = 'none';
                    }
                });
                
                // Function to append text to the terminal
                function appendToTerminal(text, type = 'command') {
                    const entryDiv = document.createElement('div');
                    
                    if (type === 'input') {
                        entryDiv.className = 'terminal-input';
                        entryDiv.innerHTML = \`<span>></span> \${escapeHtml(text)}\`;
                    } else if (type === 'system') {
                        entryDiv.className = 'terminal-system';
                        entryDiv.textContent = text;
                    } else {
                        entryDiv.className = 'terminal-output';
                        entryDiv.innerHTML = text.replace(/\\n/g, '<br>');
                    }
                    
                    terminal.appendChild(entryDiv);
                    terminal.scrollTop = terminal.scrollHeight;
                }
                
                // Function to append text to the logic terminal
                function appendToLogicTerminal(text, type = 'command') {
                    const entryDiv = document.createElement('div');
                    
                    if (type === 'input') {
                        entryDiv.className = 'terminal-input';
                        entryDiv.innerHTML = \`<span>></span> \${escapeHtml(text)}\`;
                    } else if (type === 'system') {
                        entryDiv.className = 'terminal-system';
                        entryDiv.textContent = text;
                    } else {
                        entryDiv.className = 'terminal-output';
                        entryDiv.innerHTML = text.replace(/\\n/g, '<br>');
                    }
                    
                    logicTerminal.appendChild(entryDiv);
                    logicTerminal.scrollTop = logicTerminal.scrollHeight;
                }
                
                function escapeHtml(text) {
                    const div = document.createElement('div');
                    div.textContent = text;
                    return div.innerHTML;
                }
                
                // Clear the terminal
                function clearTerminal() {
                    terminal.innerHTML = '';
                    appendToTerminal('Terminal cleared.', 'system');
                }
                
                // Clear the logic terminal
                function clearLogicTerminal() {
                    logicTerminal.innerHTML = '';
                    appendToLogicTerminal('Terminal cleared.', 'system');
                }
                
                // Process a command for memory manager
                async function submitCommand(command) {
                    if (!command) return;
                    
                    appendToTerminal(command, 'input');
                    commandInput.value = '';
                    
                    const commandParts = command.split(' ');
                    const cmd = commandParts[0].toLowerCase();
                    
                    try {
                        switch (cmd) {
                            case 'help':
                            case '?':
                                document.getElementById('helpModal').style.display = 'block';
                                break;
                                
                            case 'assign':
                                if (commandParts.length < 3) {
                                    appendToTerminal('Error: Missing arguments for assign command.', 'system');
                                    break;
                                }
                                
                                const fileNumber = commandParts[1];
                                const slotNumber = commandParts[2];
                                
                                // Switch to multi-line input mode
                                switchToMultilineMode('assign', fileNumber, slotNumber);
                                break;
                                
                            case 'read':
                                if (commandParts.length < 3) {
                                    appendToTerminal('Error: Missing arguments for read command.', 'system');
                                    break;
                                }
                                
                                const readResult = memoryManager.readSlot(commandParts[1], commandParts[2]);
                                appendToTerminal(readResult, 'system');
                                break;
                                
                            case 'last_slot':
                                if (commandParts.length < 2) {
                                    appendToTerminal('Error: Missing file number for last_slot command.', 'system');
                                    break;
                                }
                                
                                const lastSlot = memoryManager.getLastSlotNumber(commandParts[1]);
                                if (lastSlot !== null) {
                                    appendToTerminal(\`Last slot number in file \${commandParts[1]} is \${lastSlot}.\`, 'system');
                                } else {
                                    appendToTerminal(\`No slots found in file \${commandParts[1]}.\`, 'system');
                                }
                                break;
                                
                            case 'search':
                                // Switch to multi-line input mode
                                switchToMultilineMode('search');
                                break;
                                
                            case 'call':
                                if (commandParts.length < 4) {
                                    appendToTerminal('Error: Missing arguments for call command.', 'system');
                                    break;
                                }
                                
                                try {
                                    const callFileNumber = commandParts[1];
                                    const startSlot = parseInt(commandParts[2]);
                                    const endSlot = parseInt(commandParts[3]);
                                    const callResult = memoryManager.callSlotRange(callFileNumber, startSlot, endSlot);
                                    appendToTerminal(callResult, 'system');
                                } catch (e) {
                                    appendToTerminal('Error: Slot numbers must be integers.', 'system');
                                }
                                break;
                                
                            case 'export':
                                if (commandParts.length < 2) {
                                    appendToTerminal('Error: Missing file number for export command.', 'system');
                                    break;
                                }
                                
                                const exportResult = memoryManager.exportToTextFile(commandParts[1]);
                                appendToTerminal(exportResult, 'system');
                                break;
                                
                            case 'generate':
                                if (commandParts.length < 2) {
                                    appendToTerminal('Error: Please specify the number of cells (n).', 'system');
                                    break;
                                }
                                
                                const n = parseInt(commandParts[1]);
                                if (n <= 0) {
                                    appendToTerminal('Error: n must be a positive integer.', 'system');
                                    break;
                                }
                                
                                if (n > 4) {
                                    appendToTerminal('Warning: Large values of n will generate very large outputs.', 'system');
                                    if (!confirm('Continue with generating a large number of combinations? n=' + n)) {
                                        appendToTerminal('Generation canceled.', 'system');
                                        break;
                                    }
                                }
                                
                                const charSet = memoryManager.generateCharSet();
                                appendToTerminal(\`Using standard character set (\${charSet.length} chars)\`, 'system');
                                
                                // Show the generation modal with options
                                generationModal.style.display = 'block';
                                generationProgress.style.width = '0%';
                                generationStatus.textContent = 'Select options and click "Start Generation"';
                                
                                // Set up initial state for the modal
                                document.querySelector('#generateSingleFile').checked = true;
                                document.getElementById('fileInputContainer').style.display = 'block';
                                fileNameInput.value = 'combinations';
                                downloadGeneratedBtn.disabled = true;
                                importGeneratedBtn.disabled = true;
                                startGenerationBtn.disabled = false;
                                
                                // Store n value for later use
                                generationModal.dataset.n = n;
                                generationModal.dataset.customChars = '';
                                
                                break;
                                
                            case 'custom_generate':
                                if (commandParts.length < 2) {
                                    appendToTerminal('Error: Please specify the number of cells (n).', 'system');
                                    break;
                                }
                                
                                const customN = parseInt(commandParts[1]);
                                if (customN <= 0) {
                                    appendToTerminal('Error: n must be a positive integer.', 'system');
                                    break;
                                }
                                
                                // Switch to multi-line input mode for custom character set
                                switchToMultilineMode('custom_generate', customN);
                                break;
                                
                            case 'display':
                            case 'show':
                                updateMemoryDisplay();
                                appendToTerminal('Memory display updated.', 'system');
                                break;
                                
                            case 'clear':
                                clearTerminal();
                                break;
                                
                            case 'save_json':
                                const saveFileNumber = commandParts.length > 1 ? commandParts[1] : null;
                                const saveResult = memoryManager.saveToJSON(saveFileNumber);
                                appendToTerminal(saveResult, 'system');
                                break;
                                
                            case 'save_all':
                                const saveAllResult = memoryManager.saveAllAsZip();
                                appendToTerminal(saveAllResult, 'system');
                                break;
                                
                            case 'load_json':
                                // Create a file input element
                                const fileInput = document.createElement('input');
                                fileInput.type = 'file';
                                fileInput.accept = '.json';
                                fileInput.style.display = 'none';
                                document.body.appendChild(fileInput);
                                
                                fileInput.onchange = function(e) {
                                    const file = e.target.files[0];
                                    if (!file) {
                                        appendToTerminal('No file selected.', 'system');
                                        return;
                                    }
                                    
                                    memoryManager.loadFromFile(file)
                                        .then(result => {
                                            appendToTerminal(result, 'system');
                                            updateMemoryDisplay();
                                        })
                                        .catch(error => {
                                            appendToTerminal(\`Error: \${error}\`, 'system');
                                        });
                                };
                                
                                fileInput.click();
                                document.body.removeChild(fileInput);
                                break;
                                
                            case 'load_all':
                                // Simplified version just using JSON
                                const zipInput = document.createElement('input');
                                zipInput.type = 'file';
                                zipInput.accept = '.json';
                                zipInput.style.display = 'none';
                                document.body.appendChild(zipInput);
                                
                                zipInput.onchange = function(e) {
                                    const file = e.target.files[0];
                                    if (!file) {
                                        appendToTerminal('No file selected.', 'system');
                                        return;
                                    }
                                    
                                    memoryManager.loadFromFile(file)
                                        .then(result => {
                                            appendToTerminal(result, 'system');
                                            updateMemoryDisplay();
                                        })
                                        .catch(error => {
                                            appendToTerminal(\`Error: \${error}\`, 'system');
                                        });
                                };
                                
                                zipInput.click();
                                document.body.removeChild(zipInput);
                                break;
                                
                            case 'exit':
                            case 'quit':
                                appendToTerminal('This is a web application. To exit, close the browser tab.', 'system');
                                break;
                                
                            default:
                                appendToTerminal(\`Unknown command: \${cmd}\`, 'system');
                                appendToTerminal("Type 'help' for available commands.", 'system');
                        }
                    } catch (error) {
                        appendToTerminal(\`Error executing command: \${error.message}\`, 'system');
                    }
                }
                
                // Process a command for logic engine
                function submitLogicCommand(command) {
                    if (!command) return;
                    
                    appendToLogicTerminal(command, 'input');
                    logicCommandInput.value = '';
                    
                    if (command.toLowerCase() === 'help') {
                        document.getElementById('logicHelpModal').style.display = 'block';
                        return;
                    }
                    
                    try {
                        const result = logicEngine.processInstruction(command);
                        appendToLogicTerminal(result, 'system');
                    } catch (error) {
                        appendToLogicTerminal(\`Error: \${error.message}\`, 'system');
                    }
                }
                
                // Switch to multi-line input mode
                function switchToMultilineMode(mode, ...args) {
                    // Hide command input and button
                    commandInput.style.display = 'none';
                    submitCommandBtn.style.display = 'none';
                    
                    // Show multi-line input, submit and cancel buttons
                    multilineInput.style.display = 'block';
                    submitMultilineBtn.style.display = 'inline-block';
                    cancelMultilineBtn.style.display = 'inline-block';
                    
                    // Clear the multi-line input
                    multilineInput.value = '';
                    
                    // Focus the multi-line input
                    multilineInput.focus();
                    
                    // Store the mode and arguments
                    multilineInput.dataset.mode = mode;
                    multilineInput.dataset.args = JSON.stringify(args);
                    
                    // Set appropriate placeholder text
                    if (mode === 'assign') {
                        multilineInput.placeholder = \`Enter value for file \${args[0]}, slot \${args[1]} (TAB key supported)\`;
                    } else if (mode === 'search') {
                        multilineInput.placeholder = 'Enter search value (TAB key supported)';
                    } else if (mode === 'custom_generate') {
                        multilineInput.placeholder = 'Enter custom character set for combination generation';
                    }
                    
                    appendToTerminal(\`Enter multi-line value for "\${mode}" (Submit when finished):\`, 'system');
                }
                
                // Finish multi-line input
                async function finishMultilineInput(value) {
                    const mode = multilineInput.dataset.mode;
                    const args = JSON.parse(multilineInput.dataset.args || '[]');
                    
                    resetToCommandMode();
                    
                    if (mode === 'assign') {
                        const [fileNumber, slotNumber] = args;
                        const result = memoryManager.assignSlot(fileNumber, slotNumber, value);
                        appendToTerminal(result, 'system');
                        updateMemoryDisplay();
                    } else if (mode === 'search') {
                        if (!value.trim()) {
                            appendToTerminal('Error: No search value provided.', 'system');
                            return;
                        }
                        
                        const searchResults = memoryManager.searchValue(value);
                        if (searchResults.length > 0) {
                            let resultOutput = 'Search Results:';
                            for (const result of searchResults) {
                                resultOutput += \`\\nFile: \${result.file}, Slot: \${result.slot}, Value:\\n\${result.value}\\n\`;
                            }
                            appendToTerminal(resultOutput, 'system');
                        } else {
                            appendToTerminal('No results found.', 'system');
                        }
                    } else if (mode === 'custom_generate') {
                        const customN = args[0];
                        const customCharSet = value.trim() || memoryManager.generateCharSet();
                        
                        appendToTerminal(\`Using \${value.trim() ? 'custom' : 'default'} character set (\${customCharSet.length} chars)\`, 'system');
                        
                        // Show the generation modal with options
                        generationModal.style.display = 'block';
                        generationProgress.style.width = '0%';
                        generationStatus.textContent = 'Select options and click "Start Generation"';
                        
                        // Set up initial state for the modal
                        document.querySelector('#generateSingleFile').checked = true;
                        document.getElementById('fileInputContainer').style.display = 'block';
                        fileNameInput.value = 'combinations';
                        downloadGeneratedBtn.disabled = true;
                        importGeneratedBtn.disabled = true;
                        startGenerationBtn.disabled = false;
                        
                        // Store data for later use
                        generationModal.dataset.n = customN;
                        generationModal.dataset.customChars = customCharSet;
                    }
                }
                
                // Reset to command mode
                function resetToCommandMode() {
                    multilineInput.style.display = 'none';
                    submitMultilineBtn.style.display = 'none';
                    cancelMultilineBtn.style.display = 'none';
                    
                    commandInput.style.display = 'block';
                    submitCommandBtn.style.display = 'inline-block';
                    
                    commandInput.focus();
                }
                
                // Update the memory display
                function updateMemoryDisplay() {
                    const memorySlots = memoryManager.memorySlots;
                    
                    if (Object.keys(memorySlots).length === 0) {
                        memoryDisplay.innerHTML = \`
                            <div style="text-align: center; color: #888; margin-top: 20px;">
                                No memory slots available.
                                <br><br>
                                Use the terminal to add memory slots.
                            </div>
                        \`;
                        return;
                    }
                    
                    let html = '';
                    
                    // Sort file numbers numerically if possible
                    const sortedFiles = Object.keys(memorySlots).sort((a, b) => {
                        if (/^\\d+$/.test(a) && /^\\d+$/.test(b)) {
                            return parseInt(a) - parseInt(b);
                        }
                        return a.localeCompare(b);
                    });
                    
                    for (const fileNumber of sortedFiles) {
                        const slots = memorySlots[fileNumber];
                        const slotCount = Object.keys(slots).length;
                        
                        // Skip displaying the statements file in memory display - it's shown in the logic terminal
                        if (fileNumber === logicEngine.statementsFileId) {
                            continue;
                        }
                        
                        html += \`<div class="memory-file">\`;
                        html += \`
                            <div class="memory-file-title">
                                FILE \${fileNumber} (\${slotCount} slots)
                                <div class="memory-file-actions">
                                    <button class="file-action" onclick="exportFile('\${fileNumber}')">Export</button>
                                    <button class="file-action" onclick="saveFileAsJson('\${fileNumber}')">Save JSON</button>
                                </div>
                            </div>
                        \`;
                        
                        // Sort slot numbers numerically if possible
                        const sortedSlots = Object.keys(slots).sort((a, b) => {
                            if (/^\\d+$/.test(a) && /^\\d+$/.test(b)) {
                                return parseInt(a) - parseInt(b);
                            }
                            return a.localeCompare(b);
                        });
                        
                        // Limit display to max 10 slots per file for readability
                        const displaySlots = sortedSlots.slice(0, 10);
                        const remainingSlots = sortedSlots.length - 10;
                        
                        for (const slotNumber of displaySlots) {
                            const value = slots[slotNumber];
                            
                            // Truncate long values for display
                            let displayValue = value;
                            if (displayValue.length > 100) {
                                displayValue = displayValue.substring(0, 97) + '...';
                            }
                            
                            html += \`<div class="memory-slot">\`;
                            html += \`<div class="memory-slot-title">Slot \${slotNumber}</div>\`;
                            html += \`<div class="memory-slot-value">\${escapeHtml(displayValue)}</div>\`;
                            html += \`</div>\`;
                        }
                        
                        if (remainingSlots > 0) {
                            html += \`<div style="font-style: italic; margin-top: 10px; text-align: center;">
                                ... and \${remainingSlots} more slots (not displayed)
                            </div>\`;
                        }
                        
                        html += \`</div>\`;
                    }
                    
                    if (html === '') {
                        memoryDisplay.innerHTML = \`
                            <div style="text-align: center; color: #888; margin-top: 20px;">
                                No memory slots available.
                                <br><br>
                                Use the terminal to add memory slots.
                            </div>
                        \`;
                    } else {
                        memoryDisplay.innerHTML = html;
                    }
                }
                
                // Export a file
                function exportFile(fileNumber) {
                    const result = memoryManager.exportToTextFile(fileNumber);
                    appendToTerminal(result, 'system');
                }
                
                // Save a file as JSON
                function saveFileAsJson(fileNumber) {
                    const result = memoryManager.saveToJSON(fileNumber);
                    appendToTerminal(result, 'system');
                }
                
                // Save all memory slots to a file
                function saveAllMemorySlots() {
                    const result = memoryManager.saveAllAsZip();
                    appendToTerminal(result, 'system');
                }
                
                // Load memory slots from a file
                async function loadMemorySlotsFromFile() {
                    // Create a file input element
                    const fileInput = document.createElement('input');
                    fileInput.type = 'file';
                    fileInput.accept = '.json';
                    fileInput.style.display = 'none';
                    document.body.appendChild(fileInput);
                    
                    fileInput.onchange = function(e) {
                        const file = e.target.files[0];
                        if (!file) {
                            appendToTerminal('No file selected.', 'system');
                            return;
                        }
                        
                        memoryManager.loadFromFile(file)
                            .then(result => {
                                appendToTerminal(result, 'system');
                                updateMemoryDisplay();
                            })
                            .catch(error => {
                                appendToTerminal(\`Error: \${error}\`, 'system');
                            });
                    };
                    
                    fileInput.click();
                    document.body.removeChild(fileInput);
                }
                
                // Clear all memory slots
                function clearAllMemorySlots() {
                    if (confirm('Are you sure you want to clear all memory slots? This cannot be undone.')) {
                        const result = memoryManager.clearAll();
                        appendToTerminal(result, 'system');
                        updateMemoryDisplay();
                    }
                }
                
                // Insert command to input field
                function insertCommand(command) {
                    commandInput.value = command;
                    commandInput.focus();
                }
                
                // Insert logic command to logic input field
                function insertLogicCommand(command) {
                    logicCommandInput.value = command;
                    logicCommandInput.focus();
                }
                
                // Make utility functions global for access from HTML
                window.exportFile = exportFile;
                window.saveFileAsJson = saveFileAsJson;
                window.saveAllMemorySlots = saveAllMemorySlots;
                window.loadMemorySlotsFromFile = loadMemorySlotsFromFile;
                window.clearAllMemorySlots = clearAllMemorySlots;
                window.clearTerminal = clearTerminal;
                window.clearLogicTerminal = clearLogicTerminal;
                window.updateMemoryDisplay = updateMemoryDisplay;
                window.insertCommand = insertCommand;
                window.insertLogicCommand = insertLogicCommand;
                window.submitCommand = submitCommand;
                
                // Check for parent frame communication
                if (window.parent !== window) {
                    try {
                        // Notify parent we're loaded
                        if (window.parent.postMessage) {
                            window.parent.postMessage({
                                action: 'iframe-loaded',
                                data: {
                                    message: 'Build System iframe loaded'
                                }
                            }, '*');
                        }
                        
                        // Check if parent provided an API
                        if (window.parentAPI) {
                            console.log('Parent API available');
                        }
                    } catch (e) {
                        console.warn('Error communicating with parent frame:', e);
                    }
                }
            </script>
        </body>
        </html>`;
    }
    
    /**
     * Access the memory manager
     * @returns {Object|null} Memory manager object
     */
    function getMemoryManager() {
        return _memoryManager;
    }
    
    /**
     * Access the logic engine
     * @returns {Object|null} Logic engine object
     */
    function getLogicEngine() {
        return _logicEngine;
    }
    
    /**
     * Access the iframe window
     * @returns {Window|null} Iframe window object
     */
    function getIframeWindow() {
        return _iframe ? _iframe.contentWindow : null;
    }
    
    /**
     * Execute a command in the memory manager
     * @param {string} command - Command to execute
     * @returns {Promise<any>} Command result
     */
    function executeMemoryCommand(command) {
        return executeCommand(command);
    }
    
    /**
     * Execute a command in the logic engine
     * @param {string} command - Command to execute
     * @returns {Promise<any>} Command result
     */
    function executeLogicCommand(command) {
        return new Promise((resolve, reject) => {
            if (!_iframe || !_iframe.contentWindow) {
                reject(new Error('Iframe not available'));
                return;
            }
            
            try {
                // Process the command
                const iframeWindow = _iframe.contentWindow;
                
                if (iframeWindow.submitLogicCommand) {
                    // For logic terminal commands
                    iframeWindow.submitLogicCommand(command);
                    resolve(true);
                } else {
                    reject(new Error('Logic command execution not available'));
                }
            } catch (error) {
                reject(error);
            }
        });
    }
    
    // Public API
    return {
        initialize,
        loadBuildSystem,
        showBuildSection,
        getMemoryManager,
        getLogicEngine,
        getIframeWindow,
        executeMemoryCommand,
        executeLogicCommand,
        onLoad
    };
})();

// Automatically initialize when the DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    // Look for the main container
    const mainElement = document.querySelector('main');
    if (mainElement) {
        OperatorFramework.Build.initialize({
            containerId: mainElement.id || 'main'
        });
        console.log('Build System initialized');
    } else {
        console.warn('Main element not found, Build System not automatically initialized');
    }
});