#!/usr/bin/env python3
"""
C700h.py (Python 3.14.2)

C700 Host utility: Acceptance → Deterministic Quantum/Classical Circuit Derivation.

Rewritten from the uploaded dimension-generator.py:
- Same acceptance rules (7-digit tokenization, perfect-square grid, color range, adjacency conflict).
- Same deterministic mapping into Qiskit circuits and optional classical "shadow".
- Adds a clean CLI with subcommands: accept, derive, menu.
- Still supports huge integer accepted-states (decimal) and binary "0b...".

Dependencies (for derive PNG output):
  pip install "qiskit[visualization]" matplotlib numpy pillow

Notes:
- Qiskit is imported lazily so `accept` works without Qiskit installed.
- Output defaults to ./out
"""

from __future__ import annotations

import argparse
import json
import math
import os
import re
import sys
from dataclasses import dataclass
from typing import Any, Iterable, List, Optional, Sequence, Tuple


# -----------------------------
# Constants
# -----------------------------

SEGMENT_LEN: int = 7
MAX_COLOR_INDEX: int = 16 ** 6  # 16777216

GATES: List[str] = ["x", "y", "z", "h", "s", "sdg", "t", "tdg", "rx", "ry", "rz", "cx"]


# -----------------------------
# Acceptance helpers
# -----------------------------

def is_perfect_square(n: int) -> bool:
    if n <= 0:
        return False
    r = math.isqrt(n)
    return r * r == n


def decode_id_to_color_indexes(id_string: str, segment_length: int = SEGMENT_LEN) -> List[int]:
    """
    Mirrors map.js behavior:
    - Split left-to-right into fixed segment_length chunks.
    - No padding.
    - Last segment may be shorter.
    - Non-integer segments are skipped.
    """
    out: List[int] = []
    for i in range(0, len(id_string), segment_length):
        seg = id_string[i : i + segment_length]
        try:
            out.append(int(seg, 10))
        except ValueError:
            # keep behavior: silently ignore invalid chunks
            pass
    return out


def are_valid_color_indexes(indexes: Sequence[int]) -> bool:
    return all(1 <= x <= MAX_COLOR_INDEX for x in indexes)


def has_adjacent_conflict(indexes: Sequence[int], wrap: bool = False) -> bool:
    """
    True if:
    - token count not perfect square, OR
    - any orthogonal neighbor pair in the grid is equal.
    Optional wrap-around adjacency on right and bottom edges.
    """
    if not is_perfect_square(len(indexes)):
        return True

    m = math.isqrt(len(indexes))

    def idx(r: int, c: int) -> int:
        return indexes[r * m + c]

    for r in range(m):
        for c in range(m):
            cur = idx(r, c)

            # right
            if c + 1 < m:
                if cur == idx(r, c + 1):
                    return True
            elif wrap and m > 1:
                if cur == idx(r, 0):
                    return True

            # down
            if r + 1 < m:
                if cur == idx(r + 1, c):
                    return True
            elif wrap and m > 1:
                if cur == idx(0, c):
                    return True

    return False


def color_index_to_hex(index: int) -> str:
    # 1 -> #000000, 16^6 -> #FFFFFF
    v = index - 1
    return "#" + format(v, "06x")


@dataclass(frozen=True)
class AcceptanceReport:
    ok: bool
    reason: str
    m: int
    indexes: List[int]
    hex_colors: List[str]

    def to_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "reason": self.reason,
            "m": self.m,
            "token_count": len(self.indexes),
            "indexes": self.indexes,
            "hex_colors": self.hex_colors,
        }


def verify_acceptance_from_decimal_string(id_decimal: str, wrap_adjacency: bool = False) -> AcceptanceReport:
    indexes = decode_id_to_color_indexes(id_decimal, segment_length=SEGMENT_LEN)

    if not is_perfect_square(len(indexes)):
        return AcceptanceReport(
            False,
            f"Token count {len(indexes)} is not a perfect square.",
            0,
            list(indexes),
            [],
        )

    m = math.isqrt(len(indexes))

    if not are_valid_color_indexes(indexes):
        return AcceptanceReport(
            False,
            "One or more tokens are outside [1..16^6].",
            m,
            list(indexes),
            [],
        )

    if has_adjacent_conflict(indexes, wrap=wrap_adjacency):
        return AcceptanceReport(
            False,
            "Adjacency conflict: at least one orthogonal neighbor pair is equal.",
            m,
            list(indexes),
            [],
        )

    hex_colors = [color_index_to_hex(x) for x in indexes]
    return AcceptanceReport(True, "Accepted.", m, list(indexes), hex_colors)


# -----------------------------
# Deterministic circuit derivation
# -----------------------------

def token_to_angle(token: int) -> float:
    # Deterministic discrete angle: multiples of pi/16 (never 0)
    k = (token % 32) + 1
    return k * (math.pi / 16.0)


def derive_quantum_and_classical_from_grid(
    indexes: Sequence[int],
    m: int,
    max_qubits: int = 8,
    max_layers: int = 16,
    reversible_only: bool = False,
):
    """
    Deterministic mapping:
    - Qubits = min(m, max_qubits)
    - Layers = min(m, max_layers)
    - Gate for (r,c) chosen by token % len(GATES)

    classical_shadow keeps:
    - x and cx when they occur (and in reversible_only mode)
    """
    # Lazy import so accept/help can run without qiskit installed
    from qiskit import QuantumCircuit  # type: ignore

    q = min(m, max_qubits)
    layers = min(m, max_layers)

    qc = QuantumCircuit(q, name="derived_quantum")
    cc = QuantumCircuit(q, name="classical_shadow")

    def grid_token(r: int, c: int) -> int:
        return indexes[r * m + c]

    for r in range(layers):
        for c in range(q):
            tok = grid_token(r, c)
            gate = GATES[tok % len(GATES)]

            if reversible_only:
                # force into exact classical correspondence
                gate = "cx" if (tok % 2 == 1 and q > 1) else "x"

            if gate in ("x", "y", "z", "h", "s", "sdg", "t", "tdg"):
                getattr(qc, gate)(c)
                if gate == "x":
                    cc.x(c)

            elif gate == "cx":
                if q == 1:
                    qc.x(c)
                    cc.x(c)
                else:
                    control = c
                    shift = 1 + (tok % (q - 1))
                    target = (c + shift) % q
                    qc.cx(control, target)
                    cc.cx(control, target)

            elif gate in ("rx", "ry", "rz"):
                ang = token_to_angle(tok)
                getattr(qc, gate)(ang, c)
                # no classical equivalent in shadow

        qc.barrier()

    return qc, cc


# -----------------------------
# Output helpers
# -----------------------------

def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def save_circuit_png(qc, path: str) -> None:
    from qiskit.visualization import circuit_drawer  # type: ignore
    circuit_drawer(qc, output="mpl", filename=path)


def combine_pngs_side_by_side(left_path: str, right_path: str, out_path: str) -> None:
    from PIL import Image  # type: ignore

    a = Image.open(left_path).convert("RGBA")
    b = Image.open(right_path).convert("RGBA")

    w = a.width + b.width
    h = max(a.height, b.height)
    out = Image.new("RGBA", (w, h), (20, 20, 20, 255))
    out.paste(a, (0, 0))
    out.paste(b, (a.width, 0))
    out.save(out_path)


def write_gate_sequence(qc, out_txt: str) -> None:
    """
    Qiskit 1.x compatible:
    - qc.data yields CircuitInstruction objects
    - Qubit index obtained via qc.find_bit(qubit).index
    """
    parts: List[str] = []

    for ci in qc.data:
        op = ci.operation
        if op.name == "barrier":
            continue

        qinds = [qc.find_bit(q).index for q in ci.qubits]

        if op.name in ("rx", "ry", "rz"):
            angle = op.params[0]
            parts.append(f"{op.name}({angle},{qinds[0]})")
        elif op.name == "cx":
            parts.append(f"cx({qinds[0]},{qinds[1]})")
        else:
            parts.append(f"{op.name}({qinds[0]})")

    with open(out_txt, "w", encoding="utf-8") as f:
        f.write(" ".join(parts) + "\n")


# -----------------------------
# Input parsing
# -----------------------------

_DEC_RE = re.compile(r"^[0-9]+$")


def parse_accepted_state_to_decimal_string(raw: str) -> str:
    """
    Accepts:
      - decimal integer string (possibly huge)
      - binary with 0b prefix
    Returns canonical decimal string (no leading zeros except "0").
    """
    s = raw.strip()
    if s.lower().startswith("0b"):
        n = int(s, 2)
        return str(n)

    if not _DEC_RE.fullmatch(s):
        raise ValueError("Not a valid decimal integer string (or 0b... binary).")

    # allow huge integers; normalize leading zeros
    s2 = s.lstrip("0")
    return s2 if s2 != "" else "0"


def read_text_file(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read().strip()


# -----------------------------
# Commands
# -----------------------------

def cmd_accept(args: argparse.Namespace) -> int:
    raw = read_text_file(args.infile) if args.infile else args.state
    if raw is None:
        print("No state provided. Use --state or --in.", file=sys.stderr)
        return 2

    try:
        dec_str = parse_accepted_state_to_decimal_string(raw)
    except ValueError as e:
        print(str(e), file=sys.stderr)
        return 2

    report = verify_acceptance_from_decimal_string(dec_str, wrap_adjacency=args.wrap)
    if args.json:
        print(json.dumps(report.to_dict(), indent=2))
    else:
        print(report.reason)
        if report.ok:
            print(f"Grid: {report.m} x {report.m} (tokens={len(report.indexes)})")
            if args.show_hex:
                print("Hex colors:")
                print(" ".join(report.hex_colors))
            if args.show_indexes:
                print("Indexes:")
                print(" ".join(str(x) for x in report.indexes))

    return 0 if report.ok else 1


def cmd_derive(args: argparse.Namespace) -> int:
    raw = read_text_file(args.infile) if args.infile else args.state
    if raw is None:
        print("No state provided. Use --state or --in.", file=sys.stderr)
        return 2

    try:
        dec_str = parse_accepted_state_to_decimal_string(raw)
    except ValueError as e:
        print(str(e), file=sys.stderr)
        return 2

    report = verify_acceptance_from_decimal_string(dec_str, wrap_adjacency=args.wrap)
    if not report.ok:
        print(f"Acceptance check: {report.reason}", file=sys.stderr)
        return 1

    print(f"Accepted. Grid: {report.m} x {report.m} (tokens={len(report.indexes)})")

    try:
        qc, cc = derive_quantum_and_classical_from_grid(
            indexes=report.indexes,
            m=report.m,
            max_qubits=args.max_qubits,
            max_layers=args.max_layers,
            reversible_only=args.reversible_only,
        )
    except ModuleNotFoundError:
        print(
            "Missing dependency: qiskit.\n"
            'Install with: pip install "qiskit[visualization]" matplotlib numpy pillow',
            file=sys.stderr,
        )
        return 2

    outdir = args.outdir
    ensure_dir(outdir)

    # Save text gate sequences
    q_txt = os.path.join(outdir, "source_quantum.txt")
    c_txt = os.path.join(outdir, "source_classical.txt")
    write_gate_sequence(qc, q_txt)
    write_gate_sequence(cc, c_txt)

    wrote: List[str] = [q_txt, c_txt]

    # Save PNGs (optional)
    if not args.no_png:
        try:
            q_png = os.path.join(outdir, "quantum.png")
            c_png = os.path.join(outdir, "classical.png")
            a_png = os.path.join(outdir, "assembly.png")

            save_circuit_png(qc, q_png)
            save_circuit_png(cc, c_png)
            wrote.extend([q_png, c_png])

            try:
                combine_pngs_side_by_side(q_png, c_png, a_png)
                wrote.append(a_png)
            except ModuleNotFoundError:
                # Pillow missing; keep individual PNGs
                pass

        except Exception as e:
            print(f"PNG render failed: {e}", file=sys.stderr)
            print("Tip: ensure matplotlib + pillow are installed.", file=sys.stderr)

    # Save a minimal manifest (handy for pipelines)
    manifest = {
        "accepted": True,
        "grid_m": report.m,
        "token_count": len(report.indexes),
        "wrap_adjacency": bool(args.wrap),
        "reversible_only": bool(args.reversible_only),
        "max_qubits": int(args.max_qubits),
        "max_layers": int(args.max_layers),
        "outputs": wrote,
    }
    mf = os.path.join(outdir, "manifest.json")
    with open(mf, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)
    wrote.append(mf)

    print("Wrote:")
    for p in wrote:
        print(f"  {p}")

    return 0


def cmd_menu(_: argparse.Namespace) -> int:
    # Simple interactive fallback (similar to original)
    print("\nC700h — Acceptance → Quantum/Classical Circuit Deriver\n")
    while True:
        try:
            mode = input("Enter 1=derive, 2=accept-only, 3=exit: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return 0

        if mode == "3":
            return 0

        if mode not in ("1", "2"):
            print("Unknown mode.\n")
            continue

        raw = input("Paste accepted state (decimal or 0b... binary): ").strip()
        wrap = input("Wrap-around adjacency? (y/n): ").strip().lower().startswith("y")

        try:
            dec_str = parse_accepted_state_to_decimal_string(raw)
        except ValueError as e:
            print(str(e) + "\n")
            continue

        report = verify_acceptance_from_decimal_string(dec_str, wrap_adjacency=wrap)
        print(f"\nAcceptance check: {report.reason}")
        if not report.ok:
            print("Not accepted.\n")
            continue

        print(f"Grid: {report.m} x {report.m} (tokens={len(report.indexes)})")

        if mode == "2":
            print()
            continue

        reversible_only = input("Reversible-only (exact classical correspondent)? (y/n): ").strip().lower().startswith("y")
        max_qubits = int(input("Max qubits (e.g. 8): ").strip() or "8")
        max_layers = int(input("Max layers (e.g. 16): ").strip() or "16")
        outdir = input("Output dir (default: out): ").strip() or "out"

        try:
            qc, cc = derive_quantum_and_classical_from_grid(
                indexes=report.indexes,
                m=report.m,
                max_qubits=max_qubits,
                max_layers=max_layers,
                reversible_only=reversible_only,
            )
        except ModuleNotFoundError:
            print(
                '\nMissing dependency. Install with:\n  pip install "qiskit[visualization]" matplotlib numpy pillow\n'
            )
            continue

        ensure_dir(outdir)
        write_gate_sequence(qc, os.path.join(outdir, "source_quantum.txt"))
        write_gate_sequence(cc, os.path.join(outdir, "source_classical.txt"))

        try:
            qpng = os.path.join(outdir, "quantum.png")
            cpng = os.path.join(outdir, "classical.png")
            apng = os.path.join(outdir, "assembly.png")
            save_circuit_png(qc, qpng)
            save_circuit_png(cc, cpng)
            try:
                combine_pngs_side_by_side(qpng, cpng, apng)
            except ModuleNotFoundError:
                pass

            print("\nWrote:")
            print(f"  {qpng}")
            print(f"  {cpng}")
            if os.path.exists(apng):
                print(f"  {apng}")
            print(f"  {os.path.join(outdir, 'source_quantum.txt')}")
            print(f"  {os.path.join(outdir, 'source_classical.txt')}\n")
        except Exception as e:
            print(f"\nRender failed: {e}\n")


# -----------------------------
# CLI wiring
# -----------------------------

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="C700h.py",
        description="C700 Host: acceptance + deterministic quantum/classical circuit derivation",
    )
    sub = p.add_subparsers(dest="cmd", required=False)

    # accept
    pa = sub.add_parser("accept", help="Run acceptance check only")
    pa.add_argument("--state", type=str, default=None, help="Accepted state as decimal or 0b... binary")
    pa.add_argument("--in", dest="infile", type=str, default=None, help="Read accepted state from a text file")
    pa.add_argument("--wrap", action="store_true", help="Enable wrap-around adjacency checks")
    pa.add_argument("--json", action="store_true", help="Emit JSON report")
    pa.add_argument("--show-indexes", action="store_true", help="Print decoded 7-digit token indexes")
    pa.add_argument("--show-hex", action="store_true", help="Print hex colors for each token")
    pa.set_defaults(func=cmd_accept)

    # derive
    pd = sub.add_parser("derive", help="Accept + derive circuits + write outputs")
    pd.add_argument("--state", type=str, default=None, help="Accepted state as decimal or 0b... binary")
    pd.add_argument("--in", dest="infile", type=str, default=None, help="Read accepted state from a text file")
    pd.add_argument("--wrap", action="store_true", help="Enable wrap-around adjacency checks")
    pd.add_argument("--reversible-only", action="store_true", help="Force reversible-only mapping (exact classical correspondent)")
    pd.add_argument("--max-qubits", type=int, default=8, help="Maximum qubits (default: 8)")
    pd.add_argument("--max-layers", type=int, default=16, help="Maximum layers (default: 16)")
    pd.add_argument("--outdir", type=str, default="out", help="Output directory (default: out)")
    pd.add_argument("--no-png", action="store_true", help="Skip PNG rendering (write text outputs only)")
    pd.set_defaults(func=cmd_derive)

    # menu
    pm = sub.add_parser("menu", help="Interactive menu mode (fallback)")
    pm.set_defaults(func=cmd_menu)

    return p


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    # If no subcommand provided, default to menu for convenience
    if not getattr(args, "cmd", None):
        return cmd_menu(args)

    # Require one of --state / --in for accept/derive
    if args.cmd in ("accept", "derive") and not args.state and not args.infile:
        parser.error("accept/derive require --state or --in")

    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
