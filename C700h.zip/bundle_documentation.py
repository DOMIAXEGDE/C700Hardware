#!/usr/bin/env python3
from __future__ import annotations

import os
from pathlib import Path
from typing import Dict, List, Union, Iterable, Tuple

# ---- CONFIG ----
EXTENSIONS = {
    ".css", ".cmd", ".js", ".php", ".hpp", ".cpp", ".md", ".py", ".txt", ".ps1", ".json", ".html"
}
SPECIAL_FILENAMES = {".env", ".gitignore"}  # extensionless-but-important

IGNORE_DIRS = {
    ".git", ".svn", ".hg",
    "node_modules", "vendor",
    "venv", ".venv", "__pycache__",
    "dist", "build",
    ".idea", ".vscode",
    "doc",  # prevent bundling the bundle
}

MAX_FILE_BYTES = 2_000_000  # 2MB cap; adjust if you like


# ---- HELPERS ----
def is_probably_binary(path: Path, sample_size: int = 4096) -> bool:
    try:
        with path.open("rb") as f:
            chunk = f.read(sample_size)
        return b"\x00" in chunk
    except Exception:
        return True


def included_file(path: Path) -> bool:
    if path.name in SPECIAL_FILENAMES:
        return True
    return path.suffix.lower() in EXTENSIONS


def iter_included_files(root: Path) -> Iterable[Path]:
    for dirpath, dirnames, filenames in os.walk(root):
        # prune ignored dirs
        dirnames[:] = [d for d in dirnames if d not in IGNORE_DIRS]

        for name in filenames:
            p = Path(dirpath) / name
            if p.is_file() and included_file(p):
                yield p


def read_text(path: Path) -> Tuple[str, str]:
    """
    Returns (content, note). note is "" when OK.
    """
    try:
        size = path.stat().st_size
        if size > MAX_FILE_BYTES:
            return "", f"Skipped (too large): {size} bytes > {MAX_FILE_BYTES}"
        if is_probably_binary(path):
            return "", "Skipped (binary detected)"
        return path.read_text(encoding="utf-8", errors="replace"), ""
    except Exception as e:
        return "", f"Error reading: {e}"


# ---- TREE BUILD + RENDER ----
TreeNode = Dict[str, Union["TreeNode", None]]  # None means leaf file


def build_tree(relpaths: List[Path]) -> TreeNode:
    root: TreeNode = {}
    for rp in relpaths:
        cur = root
        parts = rp.parts
        for i, part in enumerate(parts):
            is_last = (i == len(parts) - 1)
            if is_last:
                cur.setdefault(part, None)
            else:
                nxt = cur.get(part)
                if nxt is None:
                    cur[part] = {}
                cur = cur[part]  # type: ignore[assignment]
    return root


def render_tree(tree: TreeNode, prefix: str = "") -> List[str]:
    """
    ASCII tree with deterministic ordering:
    directories first, then files, each group alphabetically.
    """
    lines: List[str] = []
    items = list(tree.items())

    def is_dir(item):
        _, v = item
        return isinstance(v, dict)

    dirs = sorted([it for it in items if is_dir(it)], key=lambda x: x[0].lower())
    files = sorted([it for it in items if not is_dir(it)], key=lambda x: x[0].lower())
    ordered = dirs + files

    for idx, (name, node) in enumerate(ordered):
        last = (idx == len(ordered) - 1)
        branch = "└── " if last else "├── "
        lines.append(prefix + branch + name)

        if isinstance(node, dict):
            extension = "    " if last else "│   "
            lines.extend(render_tree(node, prefix + extension))

    return lines


# ---- MAIN OUTPUT ----
def create_doc_txt(root: Path) -> Path:
    files = sorted(iter_included_files(root), key=lambda p: p.relative_to(root).as_posix().lower())
    relpaths = [p.relative_to(root) for p in files]

    tree = build_tree(relpaths)
    tree_lines = [root.name or root.as_posix()] + render_tree(tree)

    outdir = root / "doc"
    outdir.mkdir(parents=True, exist_ok=True)
    outpath = outdir / "doc.txt"

    with outpath.open("w", encoding="utf-8") as out:
        # Header
        out.write("Documentation Bundle\n")
        out.write("====================\n\n")
        out.write(f"Root: {root}\n")
        out.write(f"Included files: {len(files)}\n")
        out.write(f"Max file bytes: {MAX_FILE_BYTES}\n\n")

        # Tree view
        out.write("Filesystem Tree (included paths)\n")
        out.write("-------------------------------\n")
        out.write("\n".join(tree_lines))
        out.write("\n\n")

        # Table of contents
        out.write("Table of Contents\n")
        out.write("-----------------\n")
        for i, rp in enumerate(relpaths, start=1):
            out.write(f"{i}. {rp.as_posix()}\n")
        out.write("\n\n")

        # File contents
        out.write("File Contents\n")
        out.write("-------------\n\n")
        for i, path in enumerate(files, start=1):
            rp = path.relative_to(root).as_posix()
            content, note = read_text(path)

            header = f"[{i}] {rp}"
            out.write(header + "\n")
            out.write("-" * len(header) + "\n")
            out.write(f"; bytes={path.stat().st_size}\n")
            if note:
                out.write(f"; NOTE: {note}\n")
            out.write("\n")
            out.write(content if content else "")
            if not content and note:
                out.write("")  # keep section present even if skipped
            out.write("\n\n")

    return outpath


if __name__ == "__main__":
    root = Path(__file__).resolve().parent
    outpath = create_doc_txt(root)
    print(f"Documentation updated: Created '{outpath.relative_to(root)}'")